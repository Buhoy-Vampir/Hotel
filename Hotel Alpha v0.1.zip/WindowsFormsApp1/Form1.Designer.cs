﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label код_клиентаLabel;
            System.Windows.Forms.Label код_сотрудникаLabel;
            System.Windows.Forms.Label номерLabel;
            System.Windows.Forms.Label код_пропускаLabel;
            System.Windows.Forms.Label дата_прибытияLabel;
            System.Windows.Forms.Label дата_отбытияLabel;
            System.Windows.Forms.Label стоимостьLabel;
            System.Windows.Forms.Label примечаниеLabel;
            System.Windows.Forms.Label код_услугиLabel;
            System.Windows.Forms.Label наименованиеLabel;
            System.Windows.Forms.Label стоимостьLabel1;
            System.Windows.Forms.Label примечаниеLabel1;
            System.Windows.Forms.Label код_клиентаLabel1;
            System.Windows.Forms.Label фИОLabel;
            System.Windows.Forms.Label полLabel;
            System.Windows.Forms.Label дата_рожденияLabel;
            System.Windows.Forms.Label адресLabel;
            System.Windows.Forms.Label телефонLabel;
            System.Windows.Forms.Label паспортLabel;
            System.Windows.Forms.Label примечаниеLabel2;
            System.Windows.Forms.Label номерLabel1;
            System.Windows.Forms.Label вид_номераLabel;
            System.Windows.Forms.Label стоимостьLabel2;
            System.Windows.Forms.Label примечаниеLabel3;
            System.Windows.Forms.Label код_услугиLabel1;
            System.Windows.Forms.Label код_клиентаLabel2;
            System.Windows.Forms.Label код_сотрудникаLabel1;
            System.Windows.Forms.Label примечаниеLabel4;
            System.Windows.Forms.Label код_пропускаLabel1;
            System.Windows.Forms.Label номерLabel2;
            System.Windows.Forms.Label примечаниеLabel5;
            System.Windows.Forms.Label код_сотрудникаLabel2;
            System.Windows.Forms.Label должностьLabel;
            System.Windows.Forms.Label фИОLabel1;
            System.Windows.Forms.Label полLabel1;
            System.Windows.Forms.Label дата_рожденияLabel1;
            System.Windows.Forms.Label адресLabel1;
            System.Windows.Forms.Label телефонLabel1;
            System.Windows.Forms.Label паспортLabel1;
            System.Windows.Forms.Label примечаниеLabel6;
            System.Windows.Forms.Label код_сотрудникаLabel3;
            System.Windows.Forms.Label номерLabel3;
            System.Windows.Forms.Label день_неделиLabel;
            System.Windows.Forms.Label время_начала_уборкиLabel;
            System.Windows.Forms.Label длительностьLabel;
            System.Windows.Forms.Label примечаниеLabel8;
            System.Windows.Forms.Label логинLabel;
            System.Windows.Forms.Label парольLabel;
            System.Windows.Forms.Label фИОLabel2;
            System.Windows.Forms.Label телефонLabel2;
            System.Windows.Forms.Label почтаLabel;
            System.Windows.Forms.Label примечаниеLabel9;
            System.Windows.Forms.Label код_клиентаLabel3;
            System.Windows.Forms.Label код_сотрудникаLabel4;
            System.Windows.Forms.Label номерLabel4;
            System.Windows.Forms.Label код_пропускаLabel2;
            System.Windows.Forms.Label дата_прибытияLabel1;
            System.Windows.Forms.Label дата_отбытияLabel1;
            System.Windows.Forms.Label стоимостьLabel3;
            System.Windows.Forms.Label примечаниеLabel10;
            System.Windows.Forms.Label код_услугиLabel2;
            System.Windows.Forms.Label наименованиеLabel2;
            System.Windows.Forms.Label стоимостьLabel4;
            System.Windows.Forms.Label примечаниеLabel11;
            System.Windows.Forms.Label номерLabel5;
            System.Windows.Forms.Label вид_номераLabel1;
            System.Windows.Forms.Label стоимостьLabel5;
            System.Windows.Forms.Label примечаниеLabel13;
            System.Windows.Forms.Label код_услугиLabel3;
            System.Windows.Forms.Label код_клиентаLabel5;
            System.Windows.Forms.Label код_сотрудникаLabel5;
            System.Windows.Forms.Label примечаниеLabel14;
            System.Windows.Forms.Label код_пропускаLabel3;
            System.Windows.Forms.Label номерLabel6;
            System.Windows.Forms.Label примечаниеLabel15;
            System.Windows.Forms.Label код_сотрудникаLabel7;
            System.Windows.Forms.Label номерLabel7;
            System.Windows.Forms.Label день_неделиLabel1;
            System.Windows.Forms.Label время_начала_уборкиLabel1;
            System.Windows.Forms.Label длительностьLabel1;
            System.Windows.Forms.Label примечаниеLabel18;
            System.Windows.Forms.Label логинLabel1;
            System.Windows.Forms.Label парольLabel1;
            System.Windows.Forms.Label фИОLabel5;
            System.Windows.Forms.Label телефонLabel5;
            System.Windows.Forms.Label почтаLabel1;
            System.Windows.Forms.Label примечаниеLabel19;
            System.Windows.Forms.Label рольLabel;
            System.Windows.Forms.Label рольLabel1;
            System.Windows.Forms.Label код_клиентаLabel4;
            System.Windows.Forms.Label фИОLabel3;
            System.Windows.Forms.Label полLabel2;
            System.Windows.Forms.Label дата_рожденияLabel2;
            System.Windows.Forms.Label адресLabel2;
            System.Windows.Forms.Label телефонLabel3;
            System.Windows.Forms.Label паспортLabel2;
            System.Windows.Forms.Label примечаниеLabel12;
            System.Windows.Forms.Label код_сотрудникаLabel6;
            System.Windows.Forms.Label должностьLabel2;
            System.Windows.Forms.Label фИОLabel4;
            System.Windows.Forms.Label полLabel3;
            System.Windows.Forms.Label дата_рожденияLabel3;
            System.Windows.Forms.Label адресLabel3;
            System.Windows.Forms.Label телефонLabel4;
            System.Windows.Forms.Label паспортLabel3;
            System.Windows.Forms.Label примечаниеLabel16;
            System.Windows.Forms.Label код_сотрудникаLabel8;
            System.Windows.Forms.Label код_сотрудникаLabel9;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button_data1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox10 = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox3 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox3 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox4 = new System.Windows.Forms.TextBox();
            this.дата_отбытияDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.номерTextBox4 = new System.Windows.Forms.TextBox();
            this.дата_прибытияDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.код_пропускаTextBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.примечаниеTextBox = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox = new System.Windows.Forms.TextBox();
            this.дата_отбытияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.дата_прибытияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.код_пропускаTextBox = new System.Windows.Forms.TextBox();
            this.номерTextBox = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.броньDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.броньBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hotelDataSet = new WindowsFormsApp1.HotelDataSet();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_data2 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox11 = new System.Windows.Forms.TextBox();
            this.код_услугиTextBox2 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox4 = new System.Windows.Forms.TextBox();
            this.наименованиеTextBox2 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.примечаниеTextBox1 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox1 = new System.Windows.Forms.TextBox();
            this.наименованиеTextBox = new System.Windows.Forms.TextBox();
            this.код_услугиTextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.доп_услугиDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.доп_услугиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button_data3 = new System.Windows.Forms.Button();
            this.клиентDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn75 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn76 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn77 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.код_клиентаTextBox4 = new System.Windows.Forms.TextBox();
            this.фИОTextBox3 = new System.Windows.Forms.TextBox();
            this.полTextBox2 = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.адресTextBox2 = new System.Windows.Forms.TextBox();
            this.телефонTextBox3 = new System.Windows.Forms.TextBox();
            this.паспортTextBox2 = new System.Windows.Forms.TextBox();
            this.примечаниеTextBox12 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox2 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.паспортTextBox = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.телефонTextBox = new System.Windows.Forms.TextBox();
            this.адресTextBox = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.полTextBox = new System.Windows.Forms.TextBox();
            this.фИОTextBox = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button_data4 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox13 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox5 = new System.Windows.Forms.TextBox();
            this.номерTextBox5 = new System.Windows.Forms.TextBox();
            this.вид_номераTextBox1 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox3 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.стоимостьTextBox2 = new System.Windows.Forms.TextBox();
            this.вид_номераTextBox = new System.Windows.Forms.TextBox();
            this.номерTextBox1 = new System.Windows.Forms.TextBox();
            this.номераDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номераBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button_data5 = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.код_услугиTextBox3 = new System.Windows.Forms.TextBox();
            this.примечаниеTextBox14 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox5 = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox5 = new System.Windows.Forms.TextBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox4 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.код_сотрудникаTextBox1 = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox2 = new System.Windows.Forms.TextBox();
            this.код_услугиTextBox1 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.оказанные_услугиDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.оказанные_услугиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button_data6 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox15 = new System.Windows.Forms.TextBox();
            this.код_пропускаTextBox3 = new System.Windows.Forms.TextBox();
            this.номерTextBox6 = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox5 = new System.Windows.Forms.TextBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.номерTextBox2 = new System.Windows.Forms.TextBox();
            this.код_пропускаTextBox1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.пропускDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пропускBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.button_data7 = new System.Windows.Forms.Button();
            this.сотрудникDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn20 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn21 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn33 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn34 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn35 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn36 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn37 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn38 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn39 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.сотрудникBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.код_сотрудникаTextBox6 = new System.Windows.Forms.TextBox();
            this.должностьTextBox2 = new System.Windows.Forms.TextBox();
            this.фИОTextBox4 = new System.Windows.Forms.TextBox();
            this.полTextBox3 = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker3 = new System.Windows.Forms.DateTimePicker();
            this.адресTextBox3 = new System.Windows.Forms.TextBox();
            this.телефонTextBox4 = new System.Windows.Forms.TextBox();
            this.паспортTextBox3 = new System.Windows.Forms.TextBox();
            this.примечаниеTextBox16 = new System.Windows.Forms.TextBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox6 = new System.Windows.Forms.TextBox();
            this.button24 = new System.Windows.Forms.Button();
            this.паспортTextBox1 = new System.Windows.Forms.TextBox();
            this.button25 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.телефонTextBox1 = new System.Windows.Forms.TextBox();
            this.адресTextBox1 = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.полTextBox1 = new System.Windows.Forms.TextBox();
            this.фИОTextBox1 = new System.Windows.Forms.TextBox();
            this.должностьTextBox = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox2 = new System.Windows.Forms.TextBox();
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button_data8 = new System.Windows.Forms.Button();
            this.уборкаDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.уборкаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox18 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox7 = new System.Windows.Forms.TextBox();
            this.длительностьTextBox1 = new System.Windows.Forms.TextBox();
            this.номерTextBox7 = new System.Windows.Forms.TextBox();
            this.время_начала_уборкиTextBox1 = new System.Windows.Forms.TextBox();
            this.день_неделиTextBox1 = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button29 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.примечаниеTextBox8 = new System.Windows.Forms.TextBox();
            this.длительностьTextBox = new System.Windows.Forms.TextBox();
            this.время_начала_уборкиTextBox = new System.Windows.Forms.TextBox();
            this.день_неделиTextBox = new System.Windows.Forms.TextBox();
            this.номерTextBox3 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox3 = new System.Windows.Forms.TextBox();
            this.tabPage10 = new System.Windows.Forms.TabPage();
            this.button_data9 = new System.Windows.Forms.Button();
            this.пользователиDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn40 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn41 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn52 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn53 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn54 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn55 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn56 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn57 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пользователиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox15 = new System.Windows.Forms.GroupBox();
            this.код_сотрудникаTextBox9 = new System.Windows.Forms.TextBox();
            this.рольTextBox1 = new System.Windows.Forms.TextBox();
            this.примечаниеTextBox19 = new System.Windows.Forms.TextBox();
            this.почтаTextBox1 = new System.Windows.Forms.TextBox();
            this.логинTextBox1 = new System.Windows.Forms.TextBox();
            this.телефонTextBox5 = new System.Windows.Forms.TextBox();
            this.парольTextBox1 = new System.Windows.Forms.TextBox();
            this.фИОTextBox5 = new System.Windows.Forms.TextBox();
            this.groupBox16 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox9 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox8 = new System.Windows.Forms.TextBox();
            this.button10 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.рольTextBox = new System.Windows.Forms.TextBox();
            this.button31 = new System.Windows.Forms.Button();
            this.почтаTextBox = new System.Windows.Forms.TextBox();
            this.логинTextBox = new System.Windows.Forms.TextBox();
            this.телефонTextBox2 = new System.Windows.Forms.TextBox();
            this.парольTextBox = new System.Windows.Forms.TextBox();
            this.фИОTextBox2 = new System.Windows.Forms.TextBox();
            this.tabPage11 = new System.Windows.Forms.TabPage();
            this.button32 = new System.Windows.Forms.Button();
            this.оказанные_услугиDataGridView1 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn72 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn73 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn74 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn78 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn79 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn80 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn81 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.оказанные_услугиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hotelDataSet1 = new WindowsFormsApp1.HotelDataSet1();
            this.номера_с_клиентамиDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn66 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn67 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn68 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn69 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn70 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn71 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номера_с_клиентамиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.бронь_номеровDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn59 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn60 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn61 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn62 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn63 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn64 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn65 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.бронь_номеровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.button8 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.lb_form_window = new System.Windows.Forms.Label();
            this.броньTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.БроньTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.HotelDataSetTableAdapters.TableAdapterManager();
            this.доп_услугиTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.Доп_услугиTableAdapter();
            this.клиентTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.КлиентTableAdapter();
            this.номераTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.НомераTableAdapter();
            this.оказанные_услугиTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.Оказанные_услугиTableAdapter();
            this.пропускTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.ПропускTableAdapter();
            this.сотрудникTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.СотрудникTableAdapter();
            this.уборкаTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.УборкаTableAdapter();
            this.пользователиTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.ПользователиTableAdapter();
            this.бронь_номеровTableAdapter = new WindowsFormsApp1.HotelDataSet1TableAdapters.Бронь_номеровTableAdapter();
            this.tableAdapterManager1 = new WindowsFormsApp1.HotelDataSet1TableAdapters.TableAdapterManager();
            this.номера_с_клиентамиTableAdapter = new WindowsFormsApp1.HotelDataSet1TableAdapters.Номера_с_клиентамиTableAdapter();
            this.оказанные_услугиTableAdapter1 = new WindowsFormsApp1.HotelDataSet1TableAdapters.Оказанные_услугиTableAdapter();
            код_клиентаLabel = new System.Windows.Forms.Label();
            код_сотрудникаLabel = new System.Windows.Forms.Label();
            номерLabel = new System.Windows.Forms.Label();
            код_пропускаLabel = new System.Windows.Forms.Label();
            дата_прибытияLabel = new System.Windows.Forms.Label();
            дата_отбытияLabel = new System.Windows.Forms.Label();
            стоимостьLabel = new System.Windows.Forms.Label();
            примечаниеLabel = new System.Windows.Forms.Label();
            код_услугиLabel = new System.Windows.Forms.Label();
            наименованиеLabel = new System.Windows.Forms.Label();
            стоимостьLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel1 = new System.Windows.Forms.Label();
            код_клиентаLabel1 = new System.Windows.Forms.Label();
            фИОLabel = new System.Windows.Forms.Label();
            полLabel = new System.Windows.Forms.Label();
            дата_рожденияLabel = new System.Windows.Forms.Label();
            адресLabel = new System.Windows.Forms.Label();
            телефонLabel = new System.Windows.Forms.Label();
            паспортLabel = new System.Windows.Forms.Label();
            примечаниеLabel2 = new System.Windows.Forms.Label();
            номерLabel1 = new System.Windows.Forms.Label();
            вид_номераLabel = new System.Windows.Forms.Label();
            стоимостьLabel2 = new System.Windows.Forms.Label();
            примечаниеLabel3 = new System.Windows.Forms.Label();
            код_услугиLabel1 = new System.Windows.Forms.Label();
            код_клиентаLabel2 = new System.Windows.Forms.Label();
            код_сотрудникаLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel4 = new System.Windows.Forms.Label();
            код_пропускаLabel1 = new System.Windows.Forms.Label();
            номерLabel2 = new System.Windows.Forms.Label();
            примечаниеLabel5 = new System.Windows.Forms.Label();
            код_сотрудникаLabel2 = new System.Windows.Forms.Label();
            должностьLabel = new System.Windows.Forms.Label();
            фИОLabel1 = new System.Windows.Forms.Label();
            полLabel1 = new System.Windows.Forms.Label();
            дата_рожденияLabel1 = new System.Windows.Forms.Label();
            адресLabel1 = new System.Windows.Forms.Label();
            телефонLabel1 = new System.Windows.Forms.Label();
            паспортLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel6 = new System.Windows.Forms.Label();
            код_сотрудникаLabel3 = new System.Windows.Forms.Label();
            номерLabel3 = new System.Windows.Forms.Label();
            день_неделиLabel = new System.Windows.Forms.Label();
            время_начала_уборкиLabel = new System.Windows.Forms.Label();
            длительностьLabel = new System.Windows.Forms.Label();
            примечаниеLabel8 = new System.Windows.Forms.Label();
            логинLabel = new System.Windows.Forms.Label();
            парольLabel = new System.Windows.Forms.Label();
            фИОLabel2 = new System.Windows.Forms.Label();
            телефонLabel2 = new System.Windows.Forms.Label();
            почтаLabel = new System.Windows.Forms.Label();
            примечаниеLabel9 = new System.Windows.Forms.Label();
            код_клиентаLabel3 = new System.Windows.Forms.Label();
            код_сотрудникаLabel4 = new System.Windows.Forms.Label();
            номерLabel4 = new System.Windows.Forms.Label();
            код_пропускаLabel2 = new System.Windows.Forms.Label();
            дата_прибытияLabel1 = new System.Windows.Forms.Label();
            дата_отбытияLabel1 = new System.Windows.Forms.Label();
            стоимостьLabel3 = new System.Windows.Forms.Label();
            примечаниеLabel10 = new System.Windows.Forms.Label();
            код_услугиLabel2 = new System.Windows.Forms.Label();
            наименованиеLabel2 = new System.Windows.Forms.Label();
            стоимостьLabel4 = new System.Windows.Forms.Label();
            примечаниеLabel11 = new System.Windows.Forms.Label();
            номерLabel5 = new System.Windows.Forms.Label();
            вид_номераLabel1 = new System.Windows.Forms.Label();
            стоимостьLabel5 = new System.Windows.Forms.Label();
            примечаниеLabel13 = new System.Windows.Forms.Label();
            код_услугиLabel3 = new System.Windows.Forms.Label();
            код_клиентаLabel5 = new System.Windows.Forms.Label();
            код_сотрудникаLabel5 = new System.Windows.Forms.Label();
            примечаниеLabel14 = new System.Windows.Forms.Label();
            код_пропускаLabel3 = new System.Windows.Forms.Label();
            номерLabel6 = new System.Windows.Forms.Label();
            примечаниеLabel15 = new System.Windows.Forms.Label();
            код_сотрудникаLabel7 = new System.Windows.Forms.Label();
            номерLabel7 = new System.Windows.Forms.Label();
            день_неделиLabel1 = new System.Windows.Forms.Label();
            время_начала_уборкиLabel1 = new System.Windows.Forms.Label();
            длительностьLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel18 = new System.Windows.Forms.Label();
            логинLabel1 = new System.Windows.Forms.Label();
            парольLabel1 = new System.Windows.Forms.Label();
            фИОLabel5 = new System.Windows.Forms.Label();
            телефонLabel5 = new System.Windows.Forms.Label();
            почтаLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel19 = new System.Windows.Forms.Label();
            рольLabel = new System.Windows.Forms.Label();
            рольLabel1 = new System.Windows.Forms.Label();
            код_клиентаLabel4 = new System.Windows.Forms.Label();
            фИОLabel3 = new System.Windows.Forms.Label();
            полLabel2 = new System.Windows.Forms.Label();
            дата_рожденияLabel2 = new System.Windows.Forms.Label();
            адресLabel2 = new System.Windows.Forms.Label();
            телефонLabel3 = new System.Windows.Forms.Label();
            паспортLabel2 = new System.Windows.Forms.Label();
            примечаниеLabel12 = new System.Windows.Forms.Label();
            код_сотрудникаLabel6 = new System.Windows.Forms.Label();
            должностьLabel2 = new System.Windows.Forms.Label();
            фИОLabel4 = new System.Windows.Forms.Label();
            полLabel3 = new System.Windows.Forms.Label();
            дата_рожденияLabel3 = new System.Windows.Forms.Label();
            адресLabel3 = new System.Windows.Forms.Label();
            телефонLabel4 = new System.Windows.Forms.Label();
            паспортLabel3 = new System.Windows.Forms.Label();
            примечаниеLabel16 = new System.Windows.Forms.Label();
            код_сотрудникаLabel8 = new System.Windows.Forms.Label();
            код_сотрудникаLabel9 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.броньDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.клиентDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.номераDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номераBindingSource)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пропускDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пропускBindingSource)).BeginInit();
            this.tabPage7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникBindingSource)).BeginInit();
            this.groupBox9.SuspendLayout();
            this.groupBox10.SuspendLayout();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.уборкаDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уборкаBindingSource)).BeginInit();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            this.tabPage10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).BeginInit();
            this.groupBox15.SuspendLayout();
            this.groupBox16.SuspendLayout();
            this.tabPage11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиDataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номера_с_клиентамиDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номера_с_клиентамиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.бронь_номеровDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.бронь_номеровBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // код_клиентаLabel
            // 
            код_клиентаLabel.AutoSize = true;
            код_клиентаLabel.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel.Name = "код_клиентаLabel";
            код_клиентаLabel.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel.TabIndex = 1;
            код_клиентаLabel.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel
            // 
            код_сотрудникаLabel.AutoSize = true;
            код_сотрудникаLabel.Location = new System.Drawing.Point(6, 53);
            код_сотрудникаLabel.Name = "код_сотрудникаLabel";
            код_сотрудникаLabel.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel.TabIndex = 3;
            код_сотрудникаLabel.Text = "Код сотрудника:";
            // 
            // номерLabel
            // 
            номерLabel.AutoSize = true;
            номерLabel.Location = new System.Drawing.Point(6, 79);
            номерLabel.Name = "номерLabel";
            номерLabel.Size = new System.Drawing.Size(44, 13);
            номерLabel.TabIndex = 5;
            номерLabel.Text = "Номер:";
            // 
            // код_пропускаLabel
            // 
            код_пропускаLabel.AutoSize = true;
            код_пропускаLabel.Location = new System.Drawing.Point(6, 105);
            код_пропускаLabel.Name = "код_пропускаLabel";
            код_пропускаLabel.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel.TabIndex = 9;
            код_пропускаLabel.Text = "Код пропуска:";
            // 
            // дата_прибытияLabel
            // 
            дата_прибытияLabel.AutoSize = true;
            дата_прибытияLabel.Location = new System.Drawing.Point(6, 132);
            дата_прибытияLabel.Name = "дата_прибытияLabel";
            дата_прибытияLabel.Size = new System.Drawing.Size(88, 13);
            дата_прибытияLabel.TabIndex = 11;
            дата_прибытияLabel.Text = "Дата прибытия:";
            // 
            // дата_отбытияLabel
            // 
            дата_отбытияLabel.AutoSize = true;
            дата_отбытияLabel.Location = new System.Drawing.Point(6, 158);
            дата_отбытияLabel.Name = "дата_отбытияLabel";
            дата_отбытияLabel.Size = new System.Drawing.Size(81, 13);
            дата_отбытияLabel.TabIndex = 13;
            дата_отбытияLabel.Text = "Дата отбытия:";
            // 
            // стоимостьLabel
            // 
            стоимостьLabel.AutoSize = true;
            стоимостьLabel.Location = new System.Drawing.Point(6, 183);
            стоимостьLabel.Name = "стоимостьLabel";
            стоимостьLabel.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel.TabIndex = 15;
            стоимостьLabel.Text = "Стоимость:";
            // 
            // примечаниеLabel
            // 
            примечаниеLabel.AutoSize = true;
            примечаниеLabel.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel.Name = "примечаниеLabel";
            примечаниеLabel.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel.TabIndex = 17;
            примечаниеLabel.Text = "Примечание:";
            // 
            // код_услугиLabel
            // 
            код_услугиLabel.AutoSize = true;
            код_услугиLabel.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel.Name = "код_услугиLabel";
            код_услугиLabel.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel.TabIndex = 1;
            код_услугиLabel.Text = "Код услуги:";
            // 
            // наименованиеLabel
            // 
            наименованиеLabel.AutoSize = true;
            наименованиеLabel.Location = new System.Drawing.Point(6, 53);
            наименованиеLabel.Name = "наименованиеLabel";
            наименованиеLabel.Size = new System.Drawing.Size(86, 13);
            наименованиеLabel.TabIndex = 3;
            наименованиеLabel.Text = "Наименование:";
            // 
            // стоимостьLabel1
            // 
            стоимостьLabel1.AutoSize = true;
            стоимостьLabel1.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel1.Name = "стоимостьLabel1";
            стоимостьLabel1.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel1.TabIndex = 5;
            стоимостьLabel1.Text = "Стоимость:";
            // 
            // примечаниеLabel1
            // 
            примечаниеLabel1.AutoSize = true;
            примечаниеLabel1.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel1.Name = "примечаниеLabel1";
            примечаниеLabel1.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel1.TabIndex = 7;
            примечаниеLabel1.Text = "Примечание:";
            // 
            // код_клиентаLabel1
            // 
            код_клиентаLabel1.AutoSize = true;
            код_клиентаLabel1.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel1.Name = "код_клиентаLabel1";
            код_клиентаLabel1.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel1.TabIndex = 1;
            код_клиентаLabel1.Text = "Код клиента:";
            // 
            // фИОLabel
            // 
            фИОLabel.AutoSize = true;
            фИОLabel.Location = new System.Drawing.Point(6, 53);
            фИОLabel.Name = "фИОLabel";
            фИОLabel.Size = new System.Drawing.Size(37, 13);
            фИОLabel.TabIndex = 3;
            фИОLabel.Text = "ФИО:";
            // 
            // полLabel
            // 
            полLabel.AutoSize = true;
            полLabel.Location = new System.Drawing.Point(6, 79);
            полLabel.Name = "полLabel";
            полLabel.Size = new System.Drawing.Size(30, 13);
            полLabel.TabIndex = 5;
            полLabel.Text = "Пол:";
            // 
            // дата_рожденияLabel
            // 
            дата_рожденияLabel.AutoSize = true;
            дата_рожденияLabel.Location = new System.Drawing.Point(6, 106);
            дата_рожденияLabel.Name = "дата_рожденияLabel";
            дата_рожденияLabel.Size = new System.Drawing.Size(89, 13);
            дата_рожденияLabel.TabIndex = 7;
            дата_рожденияLabel.Text = "Дата рождения:";
            // 
            // адресLabel
            // 
            адресLabel.AutoSize = true;
            адресLabel.Location = new System.Drawing.Point(6, 131);
            адресLabel.Name = "адресLabel";
            адресLabel.Size = new System.Drawing.Size(41, 13);
            адресLabel.TabIndex = 9;
            адресLabel.Text = "Адрес:";
            // 
            // телефонLabel
            // 
            телефонLabel.AutoSize = true;
            телефонLabel.Location = new System.Drawing.Point(6, 157);
            телефонLabel.Name = "телефонLabel";
            телефонLabel.Size = new System.Drawing.Size(55, 13);
            телефонLabel.TabIndex = 11;
            телефонLabel.Text = "Телефон:";
            // 
            // паспортLabel
            // 
            паспортLabel.AutoSize = true;
            паспортLabel.Location = new System.Drawing.Point(6, 183);
            паспортLabel.Name = "паспортLabel";
            паспортLabel.Size = new System.Drawing.Size(53, 13);
            паспортLabel.TabIndex = 13;
            паспортLabel.Text = "Паспорт:";
            // 
            // примечаниеLabel2
            // 
            примечаниеLabel2.AutoSize = true;
            примечаниеLabel2.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel2.Name = "примечаниеLabel2";
            примечаниеLabel2.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel2.TabIndex = 15;
            примечаниеLabel2.Text = "Примечание:";
            // 
            // номерLabel1
            // 
            номерLabel1.AutoSize = true;
            номерLabel1.Location = new System.Drawing.Point(6, 27);
            номерLabel1.Name = "номерLabel1";
            номерLabel1.Size = new System.Drawing.Size(44, 13);
            номерLabel1.TabIndex = 1;
            номерLabel1.Text = "Номер:";
            // 
            // вид_номераLabel
            // 
            вид_номераLabel.AutoSize = true;
            вид_номераLabel.Location = new System.Drawing.Point(6, 53);
            вид_номераLabel.Name = "вид_номераLabel";
            вид_номераLabel.Size = new System.Drawing.Size(70, 13);
            вид_номераLabel.TabIndex = 3;
            вид_номераLabel.Text = "Вид номера:";
            // 
            // стоимостьLabel2
            // 
            стоимостьLabel2.AutoSize = true;
            стоимостьLabel2.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel2.Name = "стоимостьLabel2";
            стоимостьLabel2.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel2.TabIndex = 5;
            стоимостьLabel2.Text = "Стоимость:";
            // 
            // примечаниеLabel3
            // 
            примечаниеLabel3.AutoSize = true;
            примечаниеLabel3.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel3.Name = "примечаниеLabel3";
            примечаниеLabel3.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel3.TabIndex = 7;
            примечаниеLabel3.Text = "Примечание:";
            // 
            // код_услугиLabel1
            // 
            код_услугиLabel1.AutoSize = true;
            код_услугиLabel1.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel1.Name = "код_услугиLabel1";
            код_услугиLabel1.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel1.TabIndex = 1;
            код_услугиLabel1.Text = "Код услуги:";
            // 
            // код_клиентаLabel2
            // 
            код_клиентаLabel2.AutoSize = true;
            код_клиентаLabel2.Location = new System.Drawing.Point(6, 53);
            код_клиентаLabel2.Name = "код_клиентаLabel2";
            код_клиентаLabel2.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel2.TabIndex = 3;
            код_клиентаLabel2.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel1
            // 
            код_сотрудникаLabel1.AutoSize = true;
            код_сотрудникаLabel1.Location = new System.Drawing.Point(6, 79);
            код_сотрудникаLabel1.Name = "код_сотрудникаLabel1";
            код_сотрудникаLabel1.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel1.TabIndex = 5;
            код_сотрудникаLabel1.Text = "Код сотрудника:";
            // 
            // примечаниеLabel4
            // 
            примечаниеLabel4.AutoSize = true;
            примечаниеLabel4.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel4.Name = "примечаниеLabel4";
            примечаниеLabel4.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel4.TabIndex = 7;
            примечаниеLabel4.Text = "Примечание:";
            // 
            // код_пропускаLabel1
            // 
            код_пропускаLabel1.AutoSize = true;
            код_пропускаLabel1.Location = new System.Drawing.Point(6, 27);
            код_пропускаLabel1.Name = "код_пропускаLabel1";
            код_пропускаLabel1.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel1.TabIndex = 1;
            код_пропускаLabel1.Text = "Код пропуска:";
            // 
            // номерLabel2
            // 
            номерLabel2.AutoSize = true;
            номерLabel2.Location = new System.Drawing.Point(6, 53);
            номерLabel2.Name = "номерLabel2";
            номерLabel2.Size = new System.Drawing.Size(44, 13);
            номерLabel2.TabIndex = 3;
            номерLabel2.Text = "Номер:";
            // 
            // примечаниеLabel5
            // 
            примечаниеLabel5.AutoSize = true;
            примечаниеLabel5.Location = new System.Drawing.Point(6, 79);
            примечаниеLabel5.Name = "примечаниеLabel5";
            примечаниеLabel5.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel5.TabIndex = 5;
            примечаниеLabel5.Text = "Примечание:";
            // 
            // код_сотрудникаLabel2
            // 
            код_сотрудникаLabel2.AutoSize = true;
            код_сотрудникаLabel2.Location = new System.Drawing.Point(6, 27);
            код_сотрудникаLabel2.Name = "код_сотрудникаLabel2";
            код_сотрудникаLabel2.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel2.TabIndex = 1;
            код_сотрудникаLabel2.Text = "Код сотрудника:";
            // 
            // должностьLabel
            // 
            должностьLabel.AutoSize = true;
            должностьLabel.Location = new System.Drawing.Point(6, 53);
            должностьLabel.Name = "должностьLabel";
            должностьLabel.Size = new System.Drawing.Size(68, 13);
            должностьLabel.TabIndex = 3;
            должностьLabel.Text = "Должность:";
            // 
            // фИОLabel1
            // 
            фИОLabel1.AutoSize = true;
            фИОLabel1.Location = new System.Drawing.Point(6, 79);
            фИОLabel1.Name = "фИОLabel1";
            фИОLabel1.Size = new System.Drawing.Size(37, 13);
            фИОLabel1.TabIndex = 5;
            фИОLabel1.Text = "ФИО:";
            // 
            // полLabel1
            // 
            полLabel1.AutoSize = true;
            полLabel1.Location = new System.Drawing.Point(6, 105);
            полLabel1.Name = "полLabel1";
            полLabel1.Size = new System.Drawing.Size(30, 13);
            полLabel1.TabIndex = 7;
            полLabel1.Text = "Пол:";
            // 
            // дата_рожденияLabel1
            // 
            дата_рожденияLabel1.AutoSize = true;
            дата_рожденияLabel1.Location = new System.Drawing.Point(6, 132);
            дата_рожденияLabel1.Name = "дата_рожденияLabel1";
            дата_рожденияLabel1.Size = new System.Drawing.Size(89, 13);
            дата_рожденияLabel1.TabIndex = 9;
            дата_рожденияLabel1.Text = "Дата рождения:";
            // 
            // адресLabel1
            // 
            адресLabel1.AutoSize = true;
            адресLabel1.Location = new System.Drawing.Point(6, 157);
            адресLabel1.Name = "адресLabel1";
            адресLabel1.Size = new System.Drawing.Size(41, 13);
            адресLabel1.TabIndex = 11;
            адресLabel1.Text = "Адрес:";
            // 
            // телефонLabel1
            // 
            телефонLabel1.AutoSize = true;
            телефонLabel1.Location = new System.Drawing.Point(6, 183);
            телефонLabel1.Name = "телефонLabel1";
            телефонLabel1.Size = new System.Drawing.Size(55, 13);
            телефонLabel1.TabIndex = 13;
            телефонLabel1.Text = "Телефон:";
            // 
            // паспортLabel1
            // 
            паспортLabel1.AutoSize = true;
            паспортLabel1.Location = new System.Drawing.Point(6, 209);
            паспортLabel1.Name = "паспортLabel1";
            паспортLabel1.Size = new System.Drawing.Size(53, 13);
            паспортLabel1.TabIndex = 15;
            паспортLabel1.Text = "Паспорт:";
            // 
            // примечаниеLabel6
            // 
            примечаниеLabel6.AutoSize = true;
            примечаниеLabel6.Location = new System.Drawing.Point(6, 235);
            примечаниеLabel6.Name = "примечаниеLabel6";
            примечаниеLabel6.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel6.TabIndex = 17;
            примечаниеLabel6.Text = "Примечание:";
            // 
            // код_сотрудникаLabel3
            // 
            код_сотрудникаLabel3.AutoSize = true;
            код_сотрудникаLabel3.Location = new System.Drawing.Point(6, 27);
            код_сотрудникаLabel3.Name = "код_сотрудникаLabel3";
            код_сотрудникаLabel3.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel3.TabIndex = 1;
            код_сотрудникаLabel3.Text = "Код сотрудника:";
            // 
            // номерLabel3
            // 
            номерLabel3.AutoSize = true;
            номерLabel3.Location = new System.Drawing.Point(6, 53);
            номерLabel3.Name = "номерLabel3";
            номерLabel3.Size = new System.Drawing.Size(44, 13);
            номерLabel3.TabIndex = 3;
            номерLabel3.Text = "Номер:";
            // 
            // день_неделиLabel
            // 
            день_неделиLabel.AutoSize = true;
            день_неделиLabel.Location = new System.Drawing.Point(6, 79);
            день_неделиLabel.Name = "день_неделиLabel";
            день_неделиLabel.Size = new System.Drawing.Size(76, 13);
            день_неделиLabel.TabIndex = 5;
            день_неделиLabel.Text = "День недели:";
            // 
            // время_начала_уборкиLabel
            // 
            время_начала_уборкиLabel.AutoSize = true;
            время_начала_уборкиLabel.Location = new System.Drawing.Point(6, 105);
            время_начала_уборкиLabel.Name = "время_начала_уборкиLabel";
            время_начала_уборкиLabel.Size = new System.Drawing.Size(119, 13);
            время_начала_уборкиLabel.TabIndex = 7;
            время_начала_уборкиLabel.Text = "Время начала уборки:";
            // 
            // длительностьLabel
            // 
            длительностьLabel.AutoSize = true;
            длительностьLabel.Location = new System.Drawing.Point(6, 131);
            длительностьLabel.Name = "длительностьLabel";
            длительностьLabel.Size = new System.Drawing.Size(83, 13);
            длительностьLabel.TabIndex = 9;
            длительностьLabel.Text = "Длительность:";
            // 
            // примечаниеLabel8
            // 
            примечаниеLabel8.AutoSize = true;
            примечаниеLabel8.Location = new System.Drawing.Point(6, 157);
            примечаниеLabel8.Name = "примечаниеLabel8";
            примечаниеLabel8.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel8.TabIndex = 11;
            примечаниеLabel8.Text = "Примечание:";
            // 
            // логинLabel
            // 
            логинLabel.AutoSize = true;
            логинLabel.Location = new System.Drawing.Point(3, 27);
            логинLabel.Name = "логинLabel";
            логинLabel.Size = new System.Drawing.Size(41, 13);
            логинLabel.TabIndex = 14;
            логинLabel.Text = "Логин:";
            // 
            // парольLabel
            // 
            парольLabel.AutoSize = true;
            парольLabel.Location = new System.Drawing.Point(3, 53);
            парольLabel.Name = "парольLabel";
            парольLabel.Size = new System.Drawing.Size(48, 13);
            парольLabel.TabIndex = 16;
            парольLabel.Text = "Пароль:";
            // 
            // фИОLabel2
            // 
            фИОLabel2.AutoSize = true;
            фИОLabel2.Location = new System.Drawing.Point(3, 131);
            фИОLabel2.Name = "фИОLabel2";
            фИОLabel2.Size = new System.Drawing.Size(37, 13);
            фИОLabel2.TabIndex = 20;
            фИОLabel2.Text = "ФИО:";
            // 
            // телефонLabel2
            // 
            телефонLabel2.AutoSize = true;
            телефонLabel2.Location = new System.Drawing.Point(3, 157);
            телефонLabel2.Name = "телефонLabel2";
            телефонLabel2.Size = new System.Drawing.Size(55, 13);
            телефонLabel2.TabIndex = 22;
            телефонLabel2.Text = "Телефон:";
            // 
            // почтаLabel
            // 
            почтаLabel.AutoSize = true;
            почтаLabel.Location = new System.Drawing.Point(3, 183);
            почтаLabel.Name = "почтаLabel";
            почтаLabel.Size = new System.Drawing.Size(40, 13);
            почтаLabel.TabIndex = 24;
            почтаLabel.Text = "Почта:";
            // 
            // примечаниеLabel9
            // 
            примечаниеLabel9.AutoSize = true;
            примечаниеLabel9.Location = new System.Drawing.Point(3, 209);
            примечаниеLabel9.Name = "примечаниеLabel9";
            примечаниеLabel9.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel9.TabIndex = 26;
            примечаниеLabel9.Text = "Примечание:";
            // 
            // код_клиентаLabel3
            // 
            код_клиентаLabel3.AutoSize = true;
            код_клиентаLabel3.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel3.Name = "код_клиентаLabel3";
            код_клиентаLabel3.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel3.TabIndex = 20;
            код_клиентаLabel3.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel4
            // 
            код_сотрудникаLabel4.AutoSize = true;
            код_сотрудникаLabel4.Location = new System.Drawing.Point(6, 53);
            код_сотрудникаLabel4.Name = "код_сотрудникаLabel4";
            код_сотрудникаLabel4.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel4.TabIndex = 22;
            код_сотрудникаLabel4.Text = "Код сотрудника:";
            // 
            // номерLabel4
            // 
            номерLabel4.AutoSize = true;
            номерLabel4.Location = new System.Drawing.Point(6, 79);
            номерLabel4.Name = "номерLabel4";
            номерLabel4.Size = new System.Drawing.Size(44, 13);
            номерLabel4.TabIndex = 24;
            номерLabel4.Text = "Номер:";
            // 
            // код_пропускаLabel2
            // 
            код_пропускаLabel2.AutoSize = true;
            код_пропускаLabel2.Location = new System.Drawing.Point(6, 105);
            код_пропускаLabel2.Name = "код_пропускаLabel2";
            код_пропускаLabel2.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel2.TabIndex = 28;
            код_пропускаLabel2.Text = "Код пропуска:";
            // 
            // дата_прибытияLabel1
            // 
            дата_прибытияLabel1.AutoSize = true;
            дата_прибытияLabel1.Location = new System.Drawing.Point(6, 132);
            дата_прибытияLabel1.Name = "дата_прибытияLabel1";
            дата_прибытияLabel1.Size = new System.Drawing.Size(88, 13);
            дата_прибытияLabel1.TabIndex = 30;
            дата_прибытияLabel1.Text = "Дата прибытия:";
            // 
            // дата_отбытияLabel1
            // 
            дата_отбытияLabel1.AutoSize = true;
            дата_отбытияLabel1.Location = new System.Drawing.Point(6, 158);
            дата_отбытияLabel1.Name = "дата_отбытияLabel1";
            дата_отбытияLabel1.Size = new System.Drawing.Size(81, 13);
            дата_отбытияLabel1.TabIndex = 32;
            дата_отбытияLabel1.Text = "Дата отбытия:";
            // 
            // стоимостьLabel3
            // 
            стоимостьLabel3.AutoSize = true;
            стоимостьLabel3.Location = new System.Drawing.Point(6, 183);
            стоимостьLabel3.Name = "стоимостьLabel3";
            стоимостьLabel3.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel3.TabIndex = 34;
            стоимостьLabel3.Text = "Стоимость:";
            // 
            // примечаниеLabel10
            // 
            примечаниеLabel10.AutoSize = true;
            примечаниеLabel10.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel10.Name = "примечаниеLabel10";
            примечаниеLabel10.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel10.TabIndex = 36;
            примечаниеLabel10.Text = "Примечание:";
            // 
            // код_услугиLabel2
            // 
            код_услугиLabel2.AutoSize = true;
            код_услугиLabel2.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel2.Name = "код_услугиLabel2";
            код_услугиLabel2.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel2.TabIndex = 10;
            код_услугиLabel2.Text = "Код услуги:";
            // 
            // наименованиеLabel2
            // 
            наименованиеLabel2.AutoSize = true;
            наименованиеLabel2.Location = new System.Drawing.Point(6, 53);
            наименованиеLabel2.Name = "наименованиеLabel2";
            наименованиеLabel2.Size = new System.Drawing.Size(86, 13);
            наименованиеLabel2.TabIndex = 12;
            наименованиеLabel2.Text = "Наименование:";
            // 
            // стоимостьLabel4
            // 
            стоимостьLabel4.AutoSize = true;
            стоимостьLabel4.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel4.Name = "стоимостьLabel4";
            стоимостьLabel4.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel4.TabIndex = 14;
            стоимостьLabel4.Text = "Стоимость:";
            // 
            // примечаниеLabel11
            // 
            примечаниеLabel11.AutoSize = true;
            примечаниеLabel11.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel11.Name = "примечаниеLabel11";
            примечаниеLabel11.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel11.TabIndex = 16;
            примечаниеLabel11.Text = "Примечание:";
            // 
            // номерLabel5
            // 
            номерLabel5.AutoSize = true;
            номерLabel5.Location = new System.Drawing.Point(6, 27);
            номерLabel5.Name = "номерLabel5";
            номерLabel5.Size = new System.Drawing.Size(44, 13);
            номерLabel5.TabIndex = 10;
            номерLabel5.Text = "Номер:";
            // 
            // вид_номераLabel1
            // 
            вид_номераLabel1.AutoSize = true;
            вид_номераLabel1.Location = new System.Drawing.Point(6, 53);
            вид_номераLabel1.Name = "вид_номераLabel1";
            вид_номераLabel1.Size = new System.Drawing.Size(70, 13);
            вид_номераLabel1.TabIndex = 12;
            вид_номераLabel1.Text = "Вид номера:";
            // 
            // стоимостьLabel5
            // 
            стоимостьLabel5.AutoSize = true;
            стоимостьLabel5.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel5.Name = "стоимостьLabel5";
            стоимостьLabel5.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel5.TabIndex = 14;
            стоимостьLabel5.Text = "Стоимость:";
            // 
            // примечаниеLabel13
            // 
            примечаниеLabel13.AutoSize = true;
            примечаниеLabel13.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel13.Name = "примечаниеLabel13";
            примечаниеLabel13.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel13.TabIndex = 16;
            примечаниеLabel13.Text = "Примечание:";
            // 
            // код_услугиLabel3
            // 
            код_услугиLabel3.AutoSize = true;
            код_услугиLabel3.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel3.Name = "код_услугиLabel3";
            код_услугиLabel3.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel3.TabIndex = 10;
            код_услугиLabel3.Text = "Код услуги:";
            // 
            // код_клиентаLabel5
            // 
            код_клиентаLabel5.AutoSize = true;
            код_клиентаLabel5.Location = new System.Drawing.Point(6, 53);
            код_клиентаLabel5.Name = "код_клиентаLabel5";
            код_клиентаLabel5.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel5.TabIndex = 12;
            код_клиентаLabel5.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel5
            // 
            код_сотрудникаLabel5.AutoSize = true;
            код_сотрудникаLabel5.Location = new System.Drawing.Point(6, 79);
            код_сотрудникаLabel5.Name = "код_сотрудникаLabel5";
            код_сотрудникаLabel5.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel5.TabIndex = 14;
            код_сотрудникаLabel5.Text = "Код сотрудника:";
            // 
            // примечаниеLabel14
            // 
            примечаниеLabel14.AutoSize = true;
            примечаниеLabel14.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel14.Name = "примечаниеLabel14";
            примечаниеLabel14.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel14.TabIndex = 16;
            примечаниеLabel14.Text = "Примечание:";
            // 
            // код_пропускаLabel3
            // 
            код_пропускаLabel3.AutoSize = true;
            код_пропускаLabel3.Location = new System.Drawing.Point(6, 27);
            код_пропускаLabel3.Name = "код_пропускаLabel3";
            код_пропускаLabel3.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel3.TabIndex = 8;
            код_пропускаLabel3.Text = "Код пропуска:";
            // 
            // номерLabel6
            // 
            номерLabel6.AutoSize = true;
            номерLabel6.Location = new System.Drawing.Point(6, 53);
            номерLabel6.Name = "номерLabel6";
            номерLabel6.Size = new System.Drawing.Size(44, 13);
            номерLabel6.TabIndex = 10;
            номерLabel6.Text = "Номер:";
            // 
            // примечаниеLabel15
            // 
            примечаниеLabel15.AutoSize = true;
            примечаниеLabel15.Location = new System.Drawing.Point(6, 79);
            примечаниеLabel15.Name = "примечаниеLabel15";
            примечаниеLabel15.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel15.TabIndex = 12;
            примечаниеLabel15.Text = "Примечание:";
            // 
            // код_сотрудникаLabel7
            // 
            код_сотрудникаLabel7.AutoSize = true;
            код_сотрудникаLabel7.Location = new System.Drawing.Point(6, 27);
            код_сотрудникаLabel7.Name = "код_сотрудникаLabel7";
            код_сотрудникаLabel7.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel7.TabIndex = 14;
            код_сотрудникаLabel7.Text = "Код сотрудника:";
            // 
            // номерLabel7
            // 
            номерLabel7.AutoSize = true;
            номерLabel7.Location = new System.Drawing.Point(6, 53);
            номерLabel7.Name = "номерLabel7";
            номерLabel7.Size = new System.Drawing.Size(44, 13);
            номерLabel7.TabIndex = 16;
            номерLabel7.Text = "Номер:";
            // 
            // день_неделиLabel1
            // 
            день_неделиLabel1.AutoSize = true;
            день_неделиLabel1.Location = new System.Drawing.Point(6, 79);
            день_неделиLabel1.Name = "день_неделиLabel1";
            день_неделиLabel1.Size = new System.Drawing.Size(76, 13);
            день_неделиLabel1.TabIndex = 18;
            день_неделиLabel1.Text = "День недели:";
            // 
            // время_начала_уборкиLabel1
            // 
            время_начала_уборкиLabel1.AutoSize = true;
            время_начала_уборкиLabel1.Location = new System.Drawing.Point(6, 105);
            время_начала_уборкиLabel1.Name = "время_начала_уборкиLabel1";
            время_начала_уборкиLabel1.Size = new System.Drawing.Size(119, 13);
            время_начала_уборкиLabel1.TabIndex = 20;
            время_начала_уборкиLabel1.Text = "Время начала уборки:";
            // 
            // длительностьLabel1
            // 
            длительностьLabel1.AutoSize = true;
            длительностьLabel1.Location = new System.Drawing.Point(6, 131);
            длительностьLabel1.Name = "длительностьLabel1";
            длительностьLabel1.Size = new System.Drawing.Size(83, 13);
            длительностьLabel1.TabIndex = 22;
            длительностьLabel1.Text = "Длительность:";
            // 
            // примечаниеLabel18
            // 
            примечаниеLabel18.AutoSize = true;
            примечаниеLabel18.Location = new System.Drawing.Point(6, 157);
            примечаниеLabel18.Name = "примечаниеLabel18";
            примечаниеLabel18.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel18.TabIndex = 24;
            примечаниеLabel18.Text = "Примечание:";
            // 
            // логинLabel1
            // 
            логинLabel1.AutoSize = true;
            логинLabel1.Location = new System.Drawing.Point(22, 27);
            логинLabel1.Name = "логинLabel1";
            логинLabel1.Size = new System.Drawing.Size(41, 13);
            логинLabel1.TabIndex = 27;
            логинLabel1.Text = "Логин:";
            // 
            // парольLabel1
            // 
            парольLabel1.AutoSize = true;
            парольLabel1.Location = new System.Drawing.Point(22, 53);
            парольLabel1.Name = "парольLabel1";
            парольLabel1.Size = new System.Drawing.Size(48, 13);
            парольLabel1.TabIndex = 29;
            парольLabel1.Text = "Пароль:";
            // 
            // фИОLabel5
            // 
            фИОLabel5.AutoSize = true;
            фИОLabel5.Location = new System.Drawing.Point(22, 131);
            фИОLabel5.Name = "фИОLabel5";
            фИОLabel5.Size = new System.Drawing.Size(37, 13);
            фИОLabel5.TabIndex = 33;
            фИОLabel5.Text = "ФИО:";
            // 
            // телефонLabel5
            // 
            телефонLabel5.AutoSize = true;
            телефонLabel5.Location = new System.Drawing.Point(22, 157);
            телефонLabel5.Name = "телефонLabel5";
            телефонLabel5.Size = new System.Drawing.Size(55, 13);
            телефонLabel5.TabIndex = 35;
            телефонLabel5.Text = "Телефон:";
            // 
            // почтаLabel1
            // 
            почтаLabel1.AutoSize = true;
            почтаLabel1.Location = new System.Drawing.Point(22, 183);
            почтаLabel1.Name = "почтаLabel1";
            почтаLabel1.Size = new System.Drawing.Size(40, 13);
            почтаLabel1.TabIndex = 37;
            почтаLabel1.Text = "Почта:";
            // 
            // примечаниеLabel19
            // 
            примечаниеLabel19.AutoSize = true;
            примечаниеLabel19.Location = new System.Drawing.Point(22, 209);
            примечаниеLabel19.Name = "примечаниеLabel19";
            примечаниеLabel19.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel19.TabIndex = 39;
            примечаниеLabel19.Text = "Примечание:";
            // 
            // рольLabel
            // 
            рольLabel.AutoSize = true;
            рольLabel.Location = new System.Drawing.Point(3, 79);
            рольLabel.Name = "рольLabel";
            рольLabel.Size = new System.Drawing.Size(35, 13);
            рольLabel.TabIndex = 42;
            рольLabel.Text = "Роль:";
            // 
            // рольLabel1
            // 
            рольLabel1.AutoSize = true;
            рольLabel1.Location = new System.Drawing.Point(22, 79);
            рольLabel1.Name = "рольLabel1";
            рольLabel1.Size = new System.Drawing.Size(35, 13);
            рольLabel1.TabIndex = 40;
            рольLabel1.Text = "Роль:";
            // 
            // код_клиентаLabel4
            // 
            код_клиентаLabel4.AutoSize = true;
            код_клиентаLabel4.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel4.Name = "код_клиентаLabel4";
            код_клиентаLabel4.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel4.TabIndex = 0;
            код_клиентаLabel4.Text = "Код клиента:";
            // 
            // фИОLabel3
            // 
            фИОLabel3.AutoSize = true;
            фИОLabel3.Location = new System.Drawing.Point(6, 53);
            фИОLabel3.Name = "фИОLabel3";
            фИОLabel3.Size = new System.Drawing.Size(37, 13);
            фИОLabel3.TabIndex = 2;
            фИОLabel3.Text = "ФИО:";
            // 
            // полLabel2
            // 
            полLabel2.AutoSize = true;
            полLabel2.Location = new System.Drawing.Point(6, 79);
            полLabel2.Name = "полLabel2";
            полLabel2.Size = new System.Drawing.Size(30, 13);
            полLabel2.TabIndex = 4;
            полLabel2.Text = "Пол:";
            // 
            // дата_рожденияLabel2
            // 
            дата_рожденияLabel2.AutoSize = true;
            дата_рожденияLabel2.Location = new System.Drawing.Point(6, 106);
            дата_рожденияLabel2.Name = "дата_рожденияLabel2";
            дата_рожденияLabel2.Size = new System.Drawing.Size(89, 13);
            дата_рожденияLabel2.TabIndex = 6;
            дата_рожденияLabel2.Text = "Дата рождения:";
            // 
            // адресLabel2
            // 
            адресLabel2.AutoSize = true;
            адресLabel2.Location = new System.Drawing.Point(6, 131);
            адресLabel2.Name = "адресLabel2";
            адресLabel2.Size = new System.Drawing.Size(41, 13);
            адресLabel2.TabIndex = 8;
            адресLabel2.Text = "Адрес:";
            // 
            // телефонLabel3
            // 
            телефонLabel3.AutoSize = true;
            телефонLabel3.Location = new System.Drawing.Point(6, 157);
            телефонLabel3.Name = "телефонLabel3";
            телефонLabel3.Size = new System.Drawing.Size(55, 13);
            телефонLabel3.TabIndex = 10;
            телефонLabel3.Text = "Телефон:";
            // 
            // паспортLabel2
            // 
            паспортLabel2.AutoSize = true;
            паспортLabel2.Location = new System.Drawing.Point(6, 183);
            паспортLabel2.Name = "паспортLabel2";
            паспортLabel2.Size = new System.Drawing.Size(53, 13);
            паспортLabel2.TabIndex = 12;
            паспортLabel2.Text = "Паспорт:";
            // 
            // примечаниеLabel12
            // 
            примечаниеLabel12.AutoSize = true;
            примечаниеLabel12.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel12.Name = "примечаниеLabel12";
            примечаниеLabel12.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel12.TabIndex = 14;
            примечаниеLabel12.Text = "Примечание:";
            // 
            // код_сотрудникаLabel6
            // 
            код_сотрудникаLabel6.AutoSize = true;
            код_сотрудникаLabel6.Location = new System.Drawing.Point(6, 27);
            код_сотрудникаLabel6.Name = "код_сотрудникаLabel6";
            код_сотрудникаLabel6.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel6.TabIndex = 0;
            код_сотрудникаLabel6.Text = "Код сотрудника:";
            // 
            // должностьLabel2
            // 
            должностьLabel2.AutoSize = true;
            должностьLabel2.Location = new System.Drawing.Point(6, 53);
            должностьLabel2.Name = "должностьLabel2";
            должностьLabel2.Size = new System.Drawing.Size(68, 13);
            должностьLabel2.TabIndex = 2;
            должностьLabel2.Text = "Должность:";
            // 
            // фИОLabel4
            // 
            фИОLabel4.AutoSize = true;
            фИОLabel4.Location = new System.Drawing.Point(6, 79);
            фИОLabel4.Name = "фИОLabel4";
            фИОLabel4.Size = new System.Drawing.Size(37, 13);
            фИОLabel4.TabIndex = 4;
            фИОLabel4.Text = "ФИО:";
            // 
            // полLabel3
            // 
            полLabel3.AutoSize = true;
            полLabel3.Location = new System.Drawing.Point(6, 105);
            полLabel3.Name = "полLabel3";
            полLabel3.Size = new System.Drawing.Size(30, 13);
            полLabel3.TabIndex = 6;
            полLabel3.Text = "Пол:";
            // 
            // дата_рожденияLabel3
            // 
            дата_рожденияLabel3.AutoSize = true;
            дата_рожденияLabel3.Location = new System.Drawing.Point(6, 132);
            дата_рожденияLabel3.Name = "дата_рожденияLabel3";
            дата_рожденияLabel3.Size = new System.Drawing.Size(89, 13);
            дата_рожденияLabel3.TabIndex = 8;
            дата_рожденияLabel3.Text = "Дата рождения:";
            // 
            // адресLabel3
            // 
            адресLabel3.AutoSize = true;
            адресLabel3.Location = new System.Drawing.Point(6, 157);
            адресLabel3.Name = "адресLabel3";
            адресLabel3.Size = new System.Drawing.Size(41, 13);
            адресLabel3.TabIndex = 10;
            адресLabel3.Text = "Адрес:";
            // 
            // телефонLabel4
            // 
            телефонLabel4.AutoSize = true;
            телефонLabel4.Location = new System.Drawing.Point(6, 183);
            телефонLabel4.Name = "телефонLabel4";
            телефонLabel4.Size = new System.Drawing.Size(55, 13);
            телефонLabel4.TabIndex = 12;
            телефонLabel4.Text = "Телефон:";
            // 
            // паспортLabel3
            // 
            паспортLabel3.AutoSize = true;
            паспортLabel3.Location = new System.Drawing.Point(6, 209);
            паспортLabel3.Name = "паспортLabel3";
            паспортLabel3.Size = new System.Drawing.Size(53, 13);
            паспортLabel3.TabIndex = 14;
            паспортLabel3.Text = "Паспорт:";
            // 
            // примечаниеLabel16
            // 
            примечаниеLabel16.AutoSize = true;
            примечаниеLabel16.Location = new System.Drawing.Point(6, 235);
            примечаниеLabel16.Name = "примечаниеLabel16";
            примечаниеLabel16.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel16.TabIndex = 16;
            примечаниеLabel16.Text = "Примечание:";
            // 
            // код_сотрудникаLabel8
            // 
            код_сотрудникаLabel8.AutoSize = true;
            код_сотрудникаLabel8.Location = new System.Drawing.Point(3, 105);
            код_сотрудникаLabel8.Name = "код_сотрудникаLabel8";
            код_сотрудникаLabel8.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel8.TabIndex = 43;
            код_сотрудникаLabel8.Text = "Код сотрудника:";
            // 
            // код_сотрудникаLabel9
            // 
            код_сотрудникаLabel9.AutoSize = true;
            код_сотрудникаLabel9.Location = new System.Drawing.Point(22, 105);
            код_сотрудникаLabel9.Name = "код_сотрудникаLabel9";
            код_сотрудникаLabel9.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel9.TabIndex = 41;
            код_сотрудникаLabel9.Text = "Код сотрудника:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage7);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Controls.Add(this.tabPage10);
            this.tabControl1.Controls.Add(this.tabPage11);
            this.tabControl1.Location = new System.Drawing.Point(4, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(963, 554);
            this.tabControl1.TabIndex = 0;
            this.tabControl1.Tag = "4";
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.button_data1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.броньDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(955, 528);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Бронь";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button_data1
            // 
            this.button_data1.Location = new System.Drawing.Point(535, 28);
            this.button_data1.Name = "button_data1";
            this.button_data1.Size = new System.Drawing.Size(95, 23);
            this.button_data1.TabIndex = 38;
            this.button_data1.Tag = "1";
            this.button_data1.Text = "<<Перенести<<";
            this.button_data1.UseVisualStyleBackColor = true;
            this.button_data1.Click += new System.EventHandler(this.DataTransfer);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(код_клиентаLabel3);
            this.groupBox2.Controls.Add(this.примечаниеTextBox10);
            this.groupBox2.Controls.Add(this.код_клиентаTextBox3);
            this.groupBox2.Controls.Add(примечаниеLabel10);
            this.groupBox2.Controls.Add(код_сотрудникаLabel4);
            this.groupBox2.Controls.Add(this.стоимостьTextBox3);
            this.groupBox2.Controls.Add(this.код_сотрудникаTextBox4);
            this.groupBox2.Controls.Add(стоимостьLabel3);
            this.groupBox2.Controls.Add(номерLabel4);
            this.groupBox2.Controls.Add(this.дата_отбытияDateTimePicker1);
            this.groupBox2.Controls.Add(this.номерTextBox4);
            this.groupBox2.Controls.Add(дата_отбытияLabel1);
            this.groupBox2.Controls.Add(this.дата_прибытияDateTimePicker1);
            this.groupBox2.Controls.Add(дата_прибытияLabel1);
            this.groupBox2.Controls.Add(код_пропускаLabel2);
            this.groupBox2.Controls.Add(this.код_пропускаTextBox2);
            this.groupBox2.Location = new System.Drawing.Point(636, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(313, 266);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox10
            // 
            this.примечаниеTextBox10.Location = new System.Drawing.Point(102, 206);
            this.примечаниеTextBox10.Name = "примечаниеTextBox10";
            this.примечаниеTextBox10.ReadOnly = true;
            this.примечаниеTextBox10.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox10.TabIndex = 37;
            // 
            // код_клиентаTextBox3
            // 
            this.код_клиентаTextBox3.Location = new System.Drawing.Point(102, 24);
            this.код_клиентаTextBox3.Name = "код_клиентаTextBox3";
            this.код_клиентаTextBox3.ReadOnly = true;
            this.код_клиентаTextBox3.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox3.TabIndex = 21;
            // 
            // стоимостьTextBox3
            // 
            this.стоимостьTextBox3.Location = new System.Drawing.Point(102, 180);
            this.стоимостьTextBox3.Name = "стоимостьTextBox3";
            this.стоимостьTextBox3.ReadOnly = true;
            this.стоимостьTextBox3.Size = new System.Drawing.Size(200, 20);
            this.стоимостьTextBox3.TabIndex = 35;
            // 
            // код_сотрудникаTextBox4
            // 
            this.код_сотрудникаTextBox4.Location = new System.Drawing.Point(102, 50);
            this.код_сотрудникаTextBox4.Name = "код_сотрудникаTextBox4";
            this.код_сотрудникаTextBox4.ReadOnly = true;
            this.код_сотрудникаTextBox4.Size = new System.Drawing.Size(200, 20);
            this.код_сотрудникаTextBox4.TabIndex = 23;
            // 
            // дата_отбытияDateTimePicker1
            // 
            this.дата_отбытияDateTimePicker1.Location = new System.Drawing.Point(102, 154);
            this.дата_отбытияDateTimePicker1.Name = "дата_отбытияDateTimePicker1";
            this.дата_отбытияDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.дата_отбытияDateTimePicker1.TabIndex = 33;
            // 
            // номерTextBox4
            // 
            this.номерTextBox4.Location = new System.Drawing.Point(102, 76);
            this.номерTextBox4.Name = "номерTextBox4";
            this.номерTextBox4.ReadOnly = true;
            this.номерTextBox4.Size = new System.Drawing.Size(200, 20);
            this.номерTextBox4.TabIndex = 25;
            // 
            // дата_прибытияDateTimePicker1
            // 
            this.дата_прибытияDateTimePicker1.Location = new System.Drawing.Point(102, 128);
            this.дата_прибытияDateTimePicker1.Name = "дата_прибытияDateTimePicker1";
            this.дата_прибытияDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.дата_прибытияDateTimePicker1.TabIndex = 31;
            // 
            // код_пропускаTextBox2
            // 
            this.код_пропускаTextBox2.Location = new System.Drawing.Point(102, 102);
            this.код_пропускаTextBox2.Name = "код_пропускаTextBox2";
            this.код_пропускаTextBox2.ReadOnly = true;
            this.код_пропускаTextBox2.Size = new System.Drawing.Size(200, 20);
            this.код_пропускаTextBox2.TabIndex = 29;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button13);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(код_клиентаLabel);
            this.groupBox1.Controls.Add(this.примечаниеTextBox);
            this.groupBox1.Controls.Add(примечаниеLabel);
            this.groupBox1.Controls.Add(this.стоимостьTextBox);
            this.groupBox1.Controls.Add(стоимостьLabel);
            this.groupBox1.Controls.Add(this.дата_отбытияDateTimePicker);
            this.groupBox1.Controls.Add(дата_отбытияLabel);
            this.groupBox1.Controls.Add(this.дата_прибытияDateTimePicker);
            this.groupBox1.Controls.Add(дата_прибытияLabel);
            this.groupBox1.Controls.Add(this.код_пропускаTextBox);
            this.groupBox1.Controls.Add(код_пропускаLabel);
            this.groupBox1.Controls.Add(this.номерTextBox);
            this.groupBox1.Controls.Add(номерLabel);
            this.groupBox1.Controls.Add(this.код_сотрудникаTextBox);
            this.groupBox1.Controls.Add(код_сотрудникаLabel);
            this.groupBox1.Controls.Add(this.код_клиентаTextBox);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 266);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Окно ввода данных";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(322, 85);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(120, 23);
            this.button13.TabIndex = 21;
            this.button13.Text = "Удалить строку";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.delete_line);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(322, 56);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(120, 23);
            this.button12.TabIndex = 20;
            this.button12.Text = "Изменить строку";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.update_line);
            // 
            // примечаниеTextBox
            // 
            this.примечаниеTextBox.Location = new System.Drawing.Point(102, 206);
            this.примечаниеTextBox.Name = "примечаниеTextBox";
            this.примечаниеTextBox.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox.TabIndex = 18;
            // 
            // стоимостьTextBox
            // 
            this.стоимостьTextBox.Location = new System.Drawing.Point(102, 180);
            this.стоимостьTextBox.Name = "стоимостьTextBox";
            this.стоимостьTextBox.Size = new System.Drawing.Size(200, 20);
            this.стоимостьTextBox.TabIndex = 16;
            // 
            // дата_отбытияDateTimePicker
            // 
            this.дата_отбытияDateTimePicker.Location = new System.Drawing.Point(102, 154);
            this.дата_отбытияDateTimePicker.Name = "дата_отбытияDateTimePicker";
            this.дата_отбытияDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_отбытияDateTimePicker.TabIndex = 14;
            // 
            // дата_прибытияDateTimePicker
            // 
            this.дата_прибытияDateTimePicker.Location = new System.Drawing.Point(102, 128);
            this.дата_прибытияDateTimePicker.Name = "дата_прибытияDateTimePicker";
            this.дата_прибытияDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_прибытияDateTimePicker.TabIndex = 12;
            // 
            // код_пропускаTextBox
            // 
            this.код_пропускаTextBox.Location = new System.Drawing.Point(102, 102);
            this.код_пропускаTextBox.Name = "код_пропускаTextBox";
            this.код_пропускаTextBox.Size = new System.Drawing.Size(200, 20);
            this.код_пропускаTextBox.TabIndex = 10;
            // 
            // номерTextBox
            // 
            this.номерTextBox.Location = new System.Drawing.Point(102, 76);
            this.номерTextBox.Name = "номерTextBox";
            this.номерTextBox.Size = new System.Drawing.Size(200, 20);
            this.номерTextBox.TabIndex = 6;
            // 
            // код_сотрудникаTextBox
            // 
            this.код_сотрудникаTextBox.Location = new System.Drawing.Point(102, 50);
            this.код_сотрудникаTextBox.Name = "код_сотрудникаTextBox";
            this.код_сотрудникаTextBox.Size = new System.Drawing.Size(200, 20);
            this.код_сотрудникаTextBox.TabIndex = 4;
            // 
            // код_клиентаTextBox
            // 
            this.код_клиентаTextBox.Location = new System.Drawing.Point(102, 24);
            this.код_клиентаTextBox.Name = "код_клиентаTextBox";
            this.код_клиентаTextBox.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(322, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Добавить строку";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.insert_line);
            // 
            // броньDataGridView
            // 
            this.броньDataGridView.AutoGenerateColumns = false;
            this.броньDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.броньDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.броньDataGridView.DataSource = this.броньBindingSource;
            this.броньDataGridView.Location = new System.Drawing.Point(3, 278);
            this.броньDataGridView.Name = "броньDataGridView";
            this.броньDataGridView.Size = new System.Drawing.Size(949, 246);
            this.броньDataGridView.TabIndex = 0;
            this.броньDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.броньDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код клиента";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код клиента";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn2.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn3.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Код пропуска";
            this.dataGridViewTextBoxColumn5.HeaderText = "Код пропуска";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Дата прибытия";
            this.dataGridViewTextBoxColumn6.HeaderText = "Дата прибытия";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Дата отбытия";
            this.dataGridViewTextBoxColumn7.HeaderText = "Дата отбытия";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn8.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn9.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // броньBindingSource
            // 
            this.броньBindingSource.DataMember = "Бронь";
            this.броньBindingSource.DataSource = this.hotelDataSet;
            // 
            // hotelDataSet
            // 
            this.hotelDataSet.DataSetName = "HotelDataSet";
            this.hotelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.button_data2);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.доп_услугиDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(955, 528);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_data2
            // 
            this.button_data2.Location = new System.Drawing.Point(607, 28);
            this.button_data2.Name = "button_data2";
            this.button_data2.Size = new System.Drawing.Size(95, 23);
            this.button_data2.TabIndex = 39;
            this.button_data2.Tag = "2";
            this.button_data2.Text = "<<Перенести<<";
            this.button_data2.UseVisualStyleBackColor = true;
            this.button_data2.Click += new System.EventHandler(this.DataTransfer);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(код_услугиLabel2);
            this.groupBox4.Controls.Add(this.примечаниеTextBox11);
            this.groupBox4.Controls.Add(this.код_услугиTextBox2);
            this.groupBox4.Controls.Add(примечаниеLabel11);
            this.groupBox4.Controls.Add(this.стоимостьTextBox4);
            this.groupBox4.Controls.Add(наименованиеLabel2);
            this.groupBox4.Controls.Add(стоимостьLabel4);
            this.groupBox4.Controls.Add(this.наименованиеTextBox2);
            this.groupBox4.Location = new System.Drawing.Point(708, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(241, 266);
            this.groupBox4.TabIndex = 25;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox11
            // 
            this.примечаниеTextBox11.Location = new System.Drawing.Point(98, 102);
            this.примечаниеTextBox11.Name = "примечаниеTextBox11";
            this.примечаниеTextBox11.ReadOnly = true;
            this.примечаниеTextBox11.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox11.TabIndex = 17;
            // 
            // код_услугиTextBox2
            // 
            this.код_услугиTextBox2.Location = new System.Drawing.Point(98, 24);
            this.код_услугиTextBox2.Name = "код_услугиTextBox2";
            this.код_услугиTextBox2.ReadOnly = true;
            this.код_услугиTextBox2.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox2.TabIndex = 11;
            // 
            // стоимостьTextBox4
            // 
            this.стоимостьTextBox4.Location = new System.Drawing.Point(98, 76);
            this.стоимостьTextBox4.Name = "стоимостьTextBox4";
            this.стоимостьTextBox4.ReadOnly = true;
            this.стоимостьTextBox4.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox4.TabIndex = 15;
            // 
            // наименованиеTextBox2
            // 
            this.наименованиеTextBox2.Location = new System.Drawing.Point(98, 50);
            this.наименованиеTextBox2.Name = "наименованиеTextBox2";
            this.наименованиеTextBox2.ReadOnly = true;
            this.наименованиеTextBox2.Size = new System.Drawing.Size(126, 20);
            this.наименованиеTextBox2.TabIndex = 13;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(код_услугиLabel);
            this.groupBox3.Controls.Add(this.button14);
            this.groupBox3.Controls.Add(this.button15);
            this.groupBox3.Controls.Add(this.примечаниеTextBox1);
            this.groupBox3.Controls.Add(примечаниеLabel1);
            this.groupBox3.Controls.Add(this.стоимостьTextBox1);
            this.groupBox3.Controls.Add(стоимостьLabel1);
            this.groupBox3.Controls.Add(this.наименованиеTextBox);
            this.groupBox3.Controls.Add(наименованиеLabel);
            this.groupBox3.Controls.Add(this.код_услугиTextBox);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(394, 266);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Окно ввода данных";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(265, 85);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(120, 23);
            this.button14.TabIndex = 23;
            this.button14.Text = "Удалить строку";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.delete_line);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(265, 56);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(120, 23);
            this.button15.TabIndex = 22;
            this.button15.Text = "Изменить строку";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.update_line);
            // 
            // примечаниеTextBox1
            // 
            this.примечаниеTextBox1.Location = new System.Drawing.Point(98, 102);
            this.примечаниеTextBox1.Name = "примечаниеTextBox1";
            this.примечаниеTextBox1.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox1.TabIndex = 8;
            // 
            // стоимостьTextBox1
            // 
            this.стоимостьTextBox1.Location = new System.Drawing.Point(98, 76);
            this.стоимостьTextBox1.Name = "стоимостьTextBox1";
            this.стоимостьTextBox1.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox1.TabIndex = 6;
            // 
            // наименованиеTextBox
            // 
            this.наименованиеTextBox.Location = new System.Drawing.Point(98, 50);
            this.наименованиеTextBox.Name = "наименованиеTextBox";
            this.наименованиеTextBox.Size = new System.Drawing.Size(126, 20);
            this.наименованиеTextBox.TabIndex = 4;
            // 
            // код_услугиTextBox
            // 
            this.код_услугиTextBox.Location = new System.Drawing.Point(98, 24);
            this.код_услугиTextBox.Name = "код_услугиTextBox";
            this.код_услугиTextBox.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(265, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Добавить строку";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.insert_line);
            // 
            // доп_услугиDataGridView
            // 
            this.доп_услугиDataGridView.AutoGenerateColumns = false;
            this.доп_услугиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.доп_услугиDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13});
            this.доп_услугиDataGridView.DataSource = this.доп_услугиBindingSource;
            this.доп_услугиDataGridView.Location = new System.Drawing.Point(3, 278);
            this.доп_услугиDataGridView.Name = "доп_услугиDataGridView";
            this.доп_услугиDataGridView.Size = new System.Drawing.Size(949, 246);
            this.доп_услугиDataGridView.TabIndex = 0;
            this.доп_услугиDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.доп_услугиDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Код услуги";
            this.dataGridViewTextBoxColumn10.HeaderText = "Код услуги";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Наименование";
            this.dataGridViewTextBoxColumn11.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn12.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn13.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // доп_услугиBindingSource
            // 
            this.доп_услугиBindingSource.DataMember = "Доп_услуги";
            this.доп_услугиBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.button_data3);
            this.tabPage3.Controls.Add(this.клиентDataGridView);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(955, 528);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button_data3
            // 
            this.button_data3.Location = new System.Drawing.Point(535, 28);
            this.button_data3.Name = "button_data3";
            this.button_data3.Size = new System.Drawing.Size(95, 23);
            this.button_data3.TabIndex = 39;
            this.button_data3.Tag = "3";
            this.button_data3.Text = "<<Перенести<<";
            this.button_data3.UseVisualStyleBackColor = true;
            this.button_data3.Click += new System.EventHandler(this.DataTransfer);
            // 
            // клиентDataGridView
            // 
            this.клиентDataGridView.AutoGenerateColumns = false;
            this.клиентDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.клиентDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn75,
            this.dataGridViewTextBoxColumn76,
            this.dataGridViewTextBoxColumn77});
            this.клиентDataGridView.DataSource = this.клиентBindingSource;
            this.клиентDataGridView.Location = new System.Drawing.Point(3, 278);
            this.клиентDataGridView.Name = "клиентDataGridView";
            this.клиентDataGridView.Size = new System.Drawing.Size(949, 246);
            this.клиентDataGridView.TabIndex = 37;
            this.клиентDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.клиентDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Код_клиента";
            this.dataGridViewTextBoxColumn47.HeaderText = "Код_клиента";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "ФИО";
            this.dataGridViewTextBoxColumn48.HeaderText = "ФИО";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Пол";
            this.dataGridViewTextBoxColumn49.HeaderText = "Пол";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Дата рождения";
            this.dataGridViewTextBoxColumn50.HeaderText = "Дата рождения";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "Адрес";
            this.dataGridViewTextBoxColumn51.HeaderText = "Адрес";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            // 
            // dataGridViewTextBoxColumn75
            // 
            this.dataGridViewTextBoxColumn75.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn75.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn75.Name = "dataGridViewTextBoxColumn75";
            // 
            // dataGridViewTextBoxColumn76
            // 
            this.dataGridViewTextBoxColumn76.DataPropertyName = "Паспорт";
            this.dataGridViewTextBoxColumn76.HeaderText = "Паспорт";
            this.dataGridViewTextBoxColumn76.Name = "dataGridViewTextBoxColumn76";
            // 
            // dataGridViewTextBoxColumn77
            // 
            this.dataGridViewTextBoxColumn77.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn77.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn77.Name = "dataGridViewTextBoxColumn77";
            // 
            // клиентBindingSource
            // 
            this.клиентBindingSource.DataMember = "Клиент";
            this.клиентBindingSource.DataSource = this.hotelDataSet;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(код_клиентаLabel4);
            this.groupBox6.Controls.Add(this.код_клиентаTextBox4);
            this.groupBox6.Controls.Add(фИОLabel3);
            this.groupBox6.Controls.Add(this.фИОTextBox3);
            this.groupBox6.Controls.Add(полLabel2);
            this.groupBox6.Controls.Add(this.полTextBox2);
            this.groupBox6.Controls.Add(дата_рожденияLabel2);
            this.groupBox6.Controls.Add(this.дата_рожденияDateTimePicker2);
            this.groupBox6.Controls.Add(адресLabel2);
            this.groupBox6.Controls.Add(this.адресTextBox2);
            this.groupBox6.Controls.Add(телефонLabel3);
            this.groupBox6.Controls.Add(this.телефонTextBox3);
            this.groupBox6.Controls.Add(паспортLabel2);
            this.groupBox6.Controls.Add(this.паспортTextBox2);
            this.groupBox6.Controls.Add(примечаниеLabel12);
            this.groupBox6.Controls.Add(this.примечаниеTextBox12);
            this.groupBox6.Location = new System.Drawing.Point(636, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(313, 266);
            this.groupBox6.TabIndex = 37;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Окно вывода данных";
            // 
            // код_клиентаTextBox4
            // 
            this.код_клиентаTextBox4.Location = new System.Drawing.Point(101, 24);
            this.код_клиентаTextBox4.Name = "код_клиентаTextBox4";
            this.код_клиентаTextBox4.ReadOnly = true;
            this.код_клиентаTextBox4.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox4.TabIndex = 1;
            // 
            // фИОTextBox3
            // 
            this.фИОTextBox3.Location = new System.Drawing.Point(101, 50);
            this.фИОTextBox3.Name = "фИОTextBox3";
            this.фИОTextBox3.ReadOnly = true;
            this.фИОTextBox3.Size = new System.Drawing.Size(200, 20);
            this.фИОTextBox3.TabIndex = 3;
            // 
            // полTextBox2
            // 
            this.полTextBox2.Location = new System.Drawing.Point(101, 76);
            this.полTextBox2.Name = "полTextBox2";
            this.полTextBox2.ReadOnly = true;
            this.полTextBox2.Size = new System.Drawing.Size(200, 20);
            this.полTextBox2.TabIndex = 5;
            // 
            // дата_рожденияDateTimePicker2
            // 
            this.дата_рожденияDateTimePicker2.Location = new System.Drawing.Point(101, 102);
            this.дата_рожденияDateTimePicker2.Name = "дата_рожденияDateTimePicker2";
            this.дата_рожденияDateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.дата_рожденияDateTimePicker2.TabIndex = 7;
            // 
            // адресTextBox2
            // 
            this.адресTextBox2.Location = new System.Drawing.Point(101, 128);
            this.адресTextBox2.Name = "адресTextBox2";
            this.адресTextBox2.ReadOnly = true;
            this.адресTextBox2.Size = new System.Drawing.Size(200, 20);
            this.адресTextBox2.TabIndex = 9;
            // 
            // телефонTextBox3
            // 
            this.телефонTextBox3.Location = new System.Drawing.Point(101, 154);
            this.телефонTextBox3.Name = "телефонTextBox3";
            this.телефонTextBox3.ReadOnly = true;
            this.телефонTextBox3.Size = new System.Drawing.Size(200, 20);
            this.телефонTextBox3.TabIndex = 11;
            // 
            // паспортTextBox2
            // 
            this.паспортTextBox2.Location = new System.Drawing.Point(101, 180);
            this.паспортTextBox2.Name = "паспортTextBox2";
            this.паспортTextBox2.ReadOnly = true;
            this.паспортTextBox2.Size = new System.Drawing.Size(200, 20);
            this.паспортTextBox2.TabIndex = 13;
            // 
            // примечаниеTextBox12
            // 
            this.примечаниеTextBox12.Location = new System.Drawing.Point(101, 206);
            this.примечаниеTextBox12.Name = "примечаниеTextBox12";
            this.примечаниеTextBox12.ReadOnly = true;
            this.примечаниеTextBox12.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox12.TabIndex = 15;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(код_клиентаLabel1);
            this.groupBox5.Controls.Add(this.примечаниеTextBox2);
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Controls.Add(примечаниеLabel2);
            this.groupBox5.Controls.Add(this.паспортTextBox);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(паспортLabel);
            this.groupBox5.Controls.Add(this.телефонTextBox);
            this.groupBox5.Controls.Add(телефонLabel);
            this.groupBox5.Controls.Add(this.адресTextBox);
            this.groupBox5.Controls.Add(адресLabel);
            this.groupBox5.Controls.Add(this.дата_рожденияDateTimePicker);
            this.groupBox5.Controls.Add(дата_рожденияLabel);
            this.groupBox5.Controls.Add(this.полTextBox);
            this.groupBox5.Controls.Add(полLabel);
            this.groupBox5.Controls.Add(this.фИОTextBox);
            this.groupBox5.Controls.Add(фИОLabel);
            this.groupBox5.Controls.Add(this.код_клиентаTextBox1);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(451, 266);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox2
            // 
            this.примечаниеTextBox2.Location = new System.Drawing.Point(101, 206);
            this.примечаниеTextBox2.Name = "примечаниеTextBox2";
            this.примечаниеTextBox2.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox2.TabIndex = 16;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(322, 85);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(120, 23);
            this.button16.TabIndex = 35;
            this.button16.Text = "Удалить строку";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.delete_line);
            // 
            // паспортTextBox
            // 
            this.паспортTextBox.Location = new System.Drawing.Point(101, 180);
            this.паспортTextBox.Name = "паспортTextBox";
            this.паспортTextBox.Size = new System.Drawing.Size(200, 20);
            this.паспортTextBox.TabIndex = 14;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(322, 56);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(120, 23);
            this.button17.TabIndex = 34;
            this.button17.Text = "Изменить строку";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.update_line);
            // 
            // телефонTextBox
            // 
            this.телефонTextBox.Location = new System.Drawing.Point(101, 154);
            this.телефонTextBox.Name = "телефонTextBox";
            this.телефонTextBox.Size = new System.Drawing.Size(200, 20);
            this.телефонTextBox.TabIndex = 12;
            // 
            // адресTextBox
            // 
            this.адресTextBox.Location = new System.Drawing.Point(101, 128);
            this.адресTextBox.Name = "адресTextBox";
            this.адресTextBox.Size = new System.Drawing.Size(200, 20);
            this.адресTextBox.TabIndex = 10;
            // 
            // дата_рожденияDateTimePicker
            // 
            this.дата_рожденияDateTimePicker.Location = new System.Drawing.Point(101, 102);
            this.дата_рожденияDateTimePicker.Name = "дата_рожденияDateTimePicker";
            this.дата_рожденияDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_рожденияDateTimePicker.TabIndex = 8;
            // 
            // полTextBox
            // 
            this.полTextBox.Location = new System.Drawing.Point(101, 76);
            this.полTextBox.Name = "полTextBox";
            this.полTextBox.Size = new System.Drawing.Size(200, 20);
            this.полTextBox.TabIndex = 6;
            // 
            // фИОTextBox
            // 
            this.фИОTextBox.Location = new System.Drawing.Point(101, 50);
            this.фИОTextBox.Name = "фИОTextBox";
            this.фИОTextBox.Size = new System.Drawing.Size(200, 20);
            this.фИОTextBox.TabIndex = 4;
            // 
            // код_клиентаTextBox1
            // 
            this.код_клиентаTextBox1.Location = new System.Drawing.Point(101, 24);
            this.код_клиентаTextBox1.Name = "код_клиентаTextBox1";
            this.код_клиентаTextBox1.ReadOnly = true;
            this.код_клиентаTextBox1.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox1.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(322, 27);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "Добавить строку";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.insert_line);
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.Controls.Add(this.button_data4);
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Controls.Add(this.groupBox8);
            this.tabPage4.Controls.Add(this.номераDataGridView);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(955, 528);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button_data4
            // 
            this.button_data4.Location = new System.Drawing.Point(627, 28);
            this.button_data4.Name = "button_data4";
            this.button_data4.Size = new System.Drawing.Size(95, 23);
            this.button_data4.TabIndex = 40;
            this.button_data4.Text = "<<Перенести<<";
            this.button_data4.UseVisualStyleBackColor = true;
            this.button_data4.Click += new System.EventHandler(this.DataTransfer);
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(номерLabel5);
            this.groupBox7.Controls.Add(this.примечаниеTextBox13);
            this.groupBox7.Controls.Add(примечаниеLabel13);
            this.groupBox7.Controls.Add(this.стоимостьTextBox5);
            this.groupBox7.Controls.Add(стоимостьLabel5);
            this.groupBox7.Controls.Add(this.номерTextBox5);
            this.groupBox7.Controls.Add(this.вид_номераTextBox1);
            this.groupBox7.Controls.Add(вид_номераLabel1);
            this.groupBox7.Location = new System.Drawing.Point(728, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(221, 266);
            this.groupBox7.TabIndex = 39;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox13
            // 
            this.примечаниеTextBox13.Location = new System.Drawing.Point(85, 102);
            this.примечаниеTextBox13.Name = "примечаниеTextBox13";
            this.примечаниеTextBox13.ReadOnly = true;
            this.примечаниеTextBox13.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox13.TabIndex = 17;
            // 
            // стоимостьTextBox5
            // 
            this.стоимостьTextBox5.Location = new System.Drawing.Point(85, 76);
            this.стоимостьTextBox5.Name = "стоимостьTextBox5";
            this.стоимостьTextBox5.ReadOnly = true;
            this.стоимостьTextBox5.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox5.TabIndex = 15;
            // 
            // номерTextBox5
            // 
            this.номерTextBox5.Location = new System.Drawing.Point(85, 24);
            this.номерTextBox5.Name = "номерTextBox5";
            this.номерTextBox5.ReadOnly = true;
            this.номерTextBox5.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox5.TabIndex = 11;
            // 
            // вид_номераTextBox1
            // 
            this.вид_номераTextBox1.Location = new System.Drawing.Point(85, 50);
            this.вид_номераTextBox1.Name = "вид_номераTextBox1";
            this.вид_номераTextBox1.ReadOnly = true;
            this.вид_номераTextBox1.Size = new System.Drawing.Size(126, 20);
            this.вид_номераTextBox1.TabIndex = 13;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(номерLabel1);
            this.groupBox8.Controls.Add(this.примечаниеTextBox3);
            this.groupBox8.Controls.Add(this.button18);
            this.groupBox8.Controls.Add(примечаниеLabel3);
            this.groupBox8.Controls.Add(this.button19);
            this.groupBox8.Controls.Add(this.button4);
            this.groupBox8.Controls.Add(this.стоимостьTextBox2);
            this.groupBox8.Controls.Add(стоимостьLabel2);
            this.groupBox8.Controls.Add(this.вид_номераTextBox);
            this.groupBox8.Controls.Add(вид_номераLabel);
            this.groupBox8.Controls.Add(this.номерTextBox1);
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(395, 266);
            this.groupBox8.TabIndex = 38;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox3
            // 
            this.примечаниеTextBox3.Location = new System.Drawing.Point(85, 102);
            this.примечаниеTextBox3.Name = "примечаниеTextBox3";
            this.примечаниеTextBox3.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox3.TabIndex = 8;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(260, 85);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(120, 23);
            this.button18.TabIndex = 23;
            this.button18.Text = "Удалить строку";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.delete_line);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(260, 56);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(120, 23);
            this.button19.TabIndex = 22;
            this.button19.Text = "Изменить строку";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.update_line);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(260, 27);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Добавить строку";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.insert_line);
            // 
            // стоимостьTextBox2
            // 
            this.стоимостьTextBox2.Location = new System.Drawing.Point(85, 76);
            this.стоимостьTextBox2.Name = "стоимостьTextBox2";
            this.стоимостьTextBox2.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox2.TabIndex = 6;
            // 
            // вид_номераTextBox
            // 
            this.вид_номераTextBox.Location = new System.Drawing.Point(85, 50);
            this.вид_номераTextBox.Name = "вид_номераTextBox";
            this.вид_номераTextBox.Size = new System.Drawing.Size(126, 20);
            this.вид_номераTextBox.TabIndex = 4;
            // 
            // номерTextBox1
            // 
            this.номерTextBox1.Location = new System.Drawing.Point(85, 24);
            this.номерTextBox1.Name = "номерTextBox1";
            this.номерTextBox1.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox1.TabIndex = 2;
            // 
            // номераDataGridView
            // 
            this.номераDataGridView.AutoGenerateColumns = false;
            this.номераDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.номераDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.номераDataGridView.DataSource = this.номераBindingSource;
            this.номераDataGridView.Location = new System.Drawing.Point(3, 278);
            this.номераDataGridView.Name = "номераDataGridView";
            this.номераDataGridView.Size = new System.Drawing.Size(949, 246);
            this.номераDataGridView.TabIndex = 0;
            this.номераDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.номераDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn22.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Вид номера";
            this.dataGridViewTextBoxColumn23.HeaderText = "Вид номера";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn24.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn25.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // номераBindingSource
            // 
            this.номераBindingSource.DataMember = "Номера";
            this.номераBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage5
            // 
            this.tabPage5.AutoScroll = true;
            this.tabPage5.Controls.Add(this.button_data5);
            this.tabPage5.Controls.Add(this.groupBox19);
            this.tabPage5.Controls.Add(this.groupBox20);
            this.tabPage5.Controls.Add(this.оказанные_услугиDataGridView);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(955, 528);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button_data5
            // 
            this.button_data5.Location = new System.Drawing.Point(606, 28);
            this.button_data5.Name = "button_data5";
            this.button_data5.Size = new System.Drawing.Size(95, 23);
            this.button_data5.TabIndex = 47;
            this.button_data5.Tag = "5";
            this.button_data5.Text = "<<Перенести<<";
            this.button_data5.UseVisualStyleBackColor = true;
            this.button_data5.Click += new System.EventHandler(this.DataTransfer);
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.код_услугиTextBox3);
            this.groupBox19.Controls.Add(this.примечаниеTextBox14);
            this.groupBox19.Controls.Add(примечаниеLabel14);
            this.groupBox19.Controls.Add(код_услугиLabel3);
            this.groupBox19.Controls.Add(this.код_сотрудникаTextBox5);
            this.groupBox19.Controls.Add(код_сотрудникаLabel5);
            this.groupBox19.Controls.Add(код_клиентаLabel5);
            this.groupBox19.Controls.Add(this.код_клиентаTextBox5);
            this.groupBox19.Location = new System.Drawing.Point(707, 6);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(242, 266);
            this.groupBox19.TabIndex = 46;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Окно вывода данных";
            // 
            // код_услугиTextBox3
            // 
            this.код_услугиTextBox3.Location = new System.Drawing.Point(102, 24);
            this.код_услугиTextBox3.Name = "код_услугиTextBox3";
            this.код_услугиTextBox3.ReadOnly = true;
            this.код_услугиTextBox3.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox3.TabIndex = 11;
            // 
            // примечаниеTextBox14
            // 
            this.примечаниеTextBox14.Location = new System.Drawing.Point(102, 102);
            this.примечаниеTextBox14.Name = "примечаниеTextBox14";
            this.примечаниеTextBox14.ReadOnly = true;
            this.примечаниеTextBox14.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox14.TabIndex = 17;
            // 
            // код_сотрудникаTextBox5
            // 
            this.код_сотрудникаTextBox5.Location = new System.Drawing.Point(102, 76);
            this.код_сотрудникаTextBox5.Name = "код_сотрудникаTextBox5";
            this.код_сотрудникаTextBox5.ReadOnly = true;
            this.код_сотрудникаTextBox5.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox5.TabIndex = 15;
            // 
            // код_клиентаTextBox5
            // 
            this.код_клиентаTextBox5.Location = new System.Drawing.Point(102, 50);
            this.код_клиентаTextBox5.Name = "код_клиентаTextBox5";
            this.код_клиентаTextBox5.ReadOnly = true;
            this.код_клиентаTextBox5.Size = new System.Drawing.Size(126, 20);
            this.код_клиентаTextBox5.TabIndex = 13;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(код_услугиLabel1);
            this.groupBox20.Controls.Add(this.примечаниеTextBox4);
            this.groupBox20.Controls.Add(this.button20);
            this.groupBox20.Controls.Add(примечаниеLabel4);
            this.groupBox20.Controls.Add(this.button21);
            this.groupBox20.Controls.Add(this.код_сотрудникаTextBox1);
            this.groupBox20.Controls.Add(код_сотрудникаLabel1);
            this.groupBox20.Controls.Add(this.код_клиентаTextBox2);
            this.groupBox20.Controls.Add(код_клиентаLabel2);
            this.groupBox20.Controls.Add(this.код_услугиTextBox1);
            this.groupBox20.Controls.Add(this.button5);
            this.groupBox20.Location = new System.Drawing.Point(6, 6);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(402, 266);
            this.groupBox20.TabIndex = 45;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox4
            // 
            this.примечаниеTextBox4.Location = new System.Drawing.Point(102, 102);
            this.примечаниеTextBox4.Name = "примечаниеTextBox4";
            this.примечаниеTextBox4.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox4.TabIndex = 8;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(270, 85);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(120, 23);
            this.button20.TabIndex = 23;
            this.button20.Text = "Удалить строку";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.delete_line);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(270, 56);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(120, 23);
            this.button21.TabIndex = 22;
            this.button21.Text = "Изменить строку";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.update_line);
            // 
            // код_сотрудникаTextBox1
            // 
            this.код_сотрудникаTextBox1.Location = new System.Drawing.Point(102, 76);
            this.код_сотрудникаTextBox1.Name = "код_сотрудникаTextBox1";
            this.код_сотрудникаTextBox1.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox1.TabIndex = 6;
            // 
            // код_клиентаTextBox2
            // 
            this.код_клиентаTextBox2.Location = new System.Drawing.Point(102, 50);
            this.код_клиентаTextBox2.Name = "код_клиентаTextBox2";
            this.код_клиентаTextBox2.Size = new System.Drawing.Size(126, 20);
            this.код_клиентаTextBox2.TabIndex = 4;
            // 
            // код_услугиTextBox1
            // 
            this.код_услугиTextBox1.Location = new System.Drawing.Point(102, 24);
            this.код_услугиTextBox1.Name = "код_услугиTextBox1";
            this.код_услугиTextBox1.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox1.TabIndex = 2;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(270, 27);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "Добавить строку";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.insert_line);
            // 
            // оказанные_услугиDataGridView
            // 
            this.оказанные_услугиDataGridView.AutoGenerateColumns = false;
            this.оказанные_услугиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.оказанные_услугиDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29});
            this.оказанные_услугиDataGridView.DataSource = this.оказанные_услугиBindingSource;
            this.оказанные_услугиDataGridView.Location = new System.Drawing.Point(3, 278);
            this.оказанные_услугиDataGridView.Name = "оказанные_услугиDataGridView";
            this.оказанные_услугиDataGridView.Size = new System.Drawing.Size(949, 246);
            this.оказанные_услугиDataGridView.TabIndex = 17;
            this.оказанные_услугиDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.оказанные_услугиDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Код услуги";
            this.dataGridViewTextBoxColumn26.HeaderText = "Код услуги";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Код клиента";
            this.dataGridViewTextBoxColumn27.HeaderText = "Код клиента";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn28.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn29.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // оказанные_услугиBindingSource
            // 
            this.оказанные_услугиBindingSource.DataMember = "Оказанные_услуги";
            this.оказанные_услугиBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage6
            // 
            this.tabPage6.AutoScroll = true;
            this.tabPage6.Controls.Add(this.button_data6);
            this.tabPage6.Controls.Add(this.groupBox17);
            this.tabPage6.Controls.Add(this.groupBox18);
            this.tabPage6.Controls.Add(this.пропускDataGridView);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(955, 528);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button_data6
            // 
            this.button_data6.Location = new System.Drawing.Point(617, 28);
            this.button_data6.Name = "button_data6";
            this.button_data6.Size = new System.Drawing.Size(95, 23);
            this.button_data6.TabIndex = 47;
            this.button_data6.Tag = "6";
            this.button_data6.Text = "<<Перенести<<";
            this.button_data6.UseVisualStyleBackColor = true;
            this.button_data6.Click += new System.EventHandler(this.DataTransfer);
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(код_пропускаLabel3);
            this.groupBox17.Controls.Add(this.примечаниеTextBox15);
            this.groupBox17.Controls.Add(примечаниеLabel15);
            this.groupBox17.Controls.Add(this.код_пропускаTextBox3);
            this.groupBox17.Controls.Add(this.номерTextBox6);
            this.groupBox17.Controls.Add(номерLabel6);
            this.groupBox17.Location = new System.Drawing.Point(718, 6);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(231, 266);
            this.groupBox17.TabIndex = 46;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox15
            // 
            this.примечаниеTextBox15.Location = new System.Drawing.Point(91, 76);
            this.примечаниеTextBox15.Name = "примечаниеTextBox15";
            this.примечаниеTextBox15.ReadOnly = true;
            this.примечаниеTextBox15.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox15.TabIndex = 13;
            // 
            // код_пропускаTextBox3
            // 
            this.код_пропускаTextBox3.Location = new System.Drawing.Point(91, 24);
            this.код_пропускаTextBox3.Name = "код_пропускаTextBox3";
            this.код_пропускаTextBox3.ReadOnly = true;
            this.код_пропускаTextBox3.Size = new System.Drawing.Size(126, 20);
            this.код_пропускаTextBox3.TabIndex = 9;
            // 
            // номерTextBox6
            // 
            this.номерTextBox6.Location = new System.Drawing.Point(91, 50);
            this.номерTextBox6.Name = "номерTextBox6";
            this.номерTextBox6.ReadOnly = true;
            this.номерTextBox6.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox6.TabIndex = 11;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(код_пропускаLabel1);
            this.groupBox18.Controls.Add(this.примечаниеTextBox5);
            this.groupBox18.Controls.Add(this.button22);
            this.groupBox18.Controls.Add(this.button23);
            this.groupBox18.Controls.Add(примечаниеLabel5);
            this.groupBox18.Controls.Add(this.номерTextBox2);
            this.groupBox18.Controls.Add(номерLabel2);
            this.groupBox18.Controls.Add(this.код_пропускаTextBox1);
            this.groupBox18.Controls.Add(this.button6);
            this.groupBox18.Location = new System.Drawing.Point(6, 6);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(377, 266);
            this.groupBox18.TabIndex = 45;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox5
            // 
            this.примечаниеTextBox5.Location = new System.Drawing.Point(91, 76);
            this.примечаниеTextBox5.Name = "примечаниеTextBox5";
            this.примечаниеTextBox5.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox5.TabIndex = 6;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(242, 85);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(120, 23);
            this.button22.TabIndex = 23;
            this.button22.Text = "Удалить строку";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.delete_line);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(242, 56);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(120, 23);
            this.button23.TabIndex = 22;
            this.button23.Text = "Изменить строку";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.update_line);
            // 
            // номерTextBox2
            // 
            this.номерTextBox2.Location = new System.Drawing.Point(91, 50);
            this.номерTextBox2.Name = "номерTextBox2";
            this.номерTextBox2.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox2.TabIndex = 4;
            // 
            // код_пропускаTextBox1
            // 
            this.код_пропускаTextBox1.Location = new System.Drawing.Point(91, 24);
            this.код_пропускаTextBox1.Name = "код_пропускаTextBox1";
            this.код_пропускаTextBox1.Size = new System.Drawing.Size(126, 20);
            this.код_пропускаTextBox1.TabIndex = 2;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(242, 27);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "Добавить строку";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.insert_line);
            // 
            // пропускDataGridView
            // 
            this.пропускDataGridView.AutoGenerateColumns = false;
            this.пропускDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.пропускDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32});
            this.пропускDataGridView.DataSource = this.пропускBindingSource;
            this.пропускDataGridView.Location = new System.Drawing.Point(3, 278);
            this.пропускDataGridView.Name = "пропускDataGridView";
            this.пропускDataGridView.Size = new System.Drawing.Size(949, 246);
            this.пропускDataGridView.TabIndex = 0;
            this.пропускDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.пропускDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Код пропуска";
            this.dataGridViewTextBoxColumn30.HeaderText = "Код пропуска";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn31.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn32.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // пропускBindingSource
            // 
            this.пропускBindingSource.DataMember = "Пропуск";
            this.пропускBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage7
            // 
            this.tabPage7.AutoScroll = true;
            this.tabPage7.Controls.Add(this.button_data7);
            this.tabPage7.Controls.Add(this.сотрудникDataGridView);
            this.tabPage7.Controls.Add(this.groupBox9);
            this.tabPage7.Controls.Add(this.groupBox10);
            this.tabPage7.Location = new System.Drawing.Point(4, 22);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage7.Size = new System.Drawing.Size(955, 528);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "tabPage7";
            this.tabPage7.UseVisualStyleBackColor = true;
            // 
            // button_data7
            // 
            this.button_data7.Location = new System.Drawing.Point(535, 28);
            this.button_data7.Name = "button_data7";
            this.button_data7.Size = new System.Drawing.Size(95, 23);
            this.button_data7.TabIndex = 42;
            this.button_data7.Tag = "7";
            this.button_data7.Text = "<<Перенести<<";
            this.button_data7.UseVisualStyleBackColor = true;
            this.button_data7.Click += new System.EventHandler(this.DataTransfer);
            // 
            // сотрудникDataGridView
            // 
            this.сотрудникDataGridView.AutoGenerateColumns = false;
            this.сотрудникDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.сотрудникDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn20,
            this.dataGridViewTextBoxColumn21,
            this.dataGridViewTextBoxColumn33,
            this.dataGridViewTextBoxColumn34,
            this.dataGridViewTextBoxColumn35,
            this.dataGridViewTextBoxColumn36,
            this.dataGridViewTextBoxColumn37,
            this.dataGridViewTextBoxColumn38,
            this.dataGridViewTextBoxColumn39});
            this.сотрудникDataGridView.DataSource = this.сотрудникBindingSource;
            this.сотрудникDataGridView.Location = new System.Drawing.Point(3, 278);
            this.сотрудникDataGridView.Name = "сотрудникDataGridView";
            this.сотрудникDataGridView.Size = new System.Drawing.Size(949, 246);
            this.сотрудникDataGridView.TabIndex = 41;
            this.сотрудникDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.сотрудникDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn20
            // 
            this.dataGridViewTextBoxColumn20.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn20.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn20.Name = "dataGridViewTextBoxColumn20";
            // 
            // dataGridViewTextBoxColumn21
            // 
            this.dataGridViewTextBoxColumn21.DataPropertyName = "Должность";
            this.dataGridViewTextBoxColumn21.HeaderText = "Должность";
            this.dataGridViewTextBoxColumn21.Name = "dataGridViewTextBoxColumn21";
            // 
            // dataGridViewTextBoxColumn33
            // 
            this.dataGridViewTextBoxColumn33.DataPropertyName = "ФИО";
            this.dataGridViewTextBoxColumn33.HeaderText = "ФИО";
            this.dataGridViewTextBoxColumn33.Name = "dataGridViewTextBoxColumn33";
            // 
            // dataGridViewTextBoxColumn34
            // 
            this.dataGridViewTextBoxColumn34.DataPropertyName = "Пол";
            this.dataGridViewTextBoxColumn34.HeaderText = "Пол";
            this.dataGridViewTextBoxColumn34.Name = "dataGridViewTextBoxColumn34";
            // 
            // dataGridViewTextBoxColumn35
            // 
            this.dataGridViewTextBoxColumn35.DataPropertyName = "Дата рождения";
            this.dataGridViewTextBoxColumn35.HeaderText = "Дата рождения";
            this.dataGridViewTextBoxColumn35.Name = "dataGridViewTextBoxColumn35";
            // 
            // dataGridViewTextBoxColumn36
            // 
            this.dataGridViewTextBoxColumn36.DataPropertyName = "Адрес";
            this.dataGridViewTextBoxColumn36.HeaderText = "Адрес";
            this.dataGridViewTextBoxColumn36.Name = "dataGridViewTextBoxColumn36";
            // 
            // dataGridViewTextBoxColumn37
            // 
            this.dataGridViewTextBoxColumn37.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn37.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn37.Name = "dataGridViewTextBoxColumn37";
            // 
            // dataGridViewTextBoxColumn38
            // 
            this.dataGridViewTextBoxColumn38.DataPropertyName = "Паспорт";
            this.dataGridViewTextBoxColumn38.HeaderText = "Паспорт";
            this.dataGridViewTextBoxColumn38.Name = "dataGridViewTextBoxColumn38";
            // 
            // dataGridViewTextBoxColumn39
            // 
            this.dataGridViewTextBoxColumn39.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn39.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn39.Name = "dataGridViewTextBoxColumn39";
            // 
            // сотрудникBindingSource
            // 
            this.сотрудникBindingSource.DataMember = "Сотрудник";
            this.сотрудникBindingSource.DataSource = this.hotelDataSet;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(код_сотрудникаLabel6);
            this.groupBox9.Controls.Add(this.код_сотрудникаTextBox6);
            this.groupBox9.Controls.Add(должностьLabel2);
            this.groupBox9.Controls.Add(this.должностьTextBox2);
            this.groupBox9.Controls.Add(фИОLabel4);
            this.groupBox9.Controls.Add(this.фИОTextBox4);
            this.groupBox9.Controls.Add(полLabel3);
            this.groupBox9.Controls.Add(this.полTextBox3);
            this.groupBox9.Controls.Add(дата_рожденияLabel3);
            this.groupBox9.Controls.Add(this.дата_рожденияDateTimePicker3);
            this.groupBox9.Controls.Add(адресLabel3);
            this.groupBox9.Controls.Add(this.адресTextBox3);
            this.groupBox9.Controls.Add(телефонLabel4);
            this.groupBox9.Controls.Add(this.телефонTextBox4);
            this.groupBox9.Controls.Add(паспортLabel3);
            this.groupBox9.Controls.Add(this.паспортTextBox3);
            this.groupBox9.Controls.Add(примечаниеLabel16);
            this.groupBox9.Controls.Add(this.примечаниеTextBox16);
            this.groupBox9.Location = new System.Drawing.Point(636, 6);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(313, 266);
            this.groupBox9.TabIndex = 41;
            this.groupBox9.TabStop = false;
            this.groupBox9.Text = "Окно вывода данных";
            // 
            // код_сотрудникаTextBox6
            // 
            this.код_сотрудникаTextBox6.Location = new System.Drawing.Point(102, 24);
            this.код_сотрудникаTextBox6.Name = "код_сотрудникаTextBox6";
            this.код_сотрудникаTextBox6.ReadOnly = true;
            this.код_сотрудникаTextBox6.Size = new System.Drawing.Size(200, 20);
            this.код_сотрудникаTextBox6.TabIndex = 1;
            // 
            // должностьTextBox2
            // 
            this.должностьTextBox2.Location = new System.Drawing.Point(102, 50);
            this.должностьTextBox2.Name = "должностьTextBox2";
            this.должностьTextBox2.ReadOnly = true;
            this.должностьTextBox2.Size = new System.Drawing.Size(200, 20);
            this.должностьTextBox2.TabIndex = 3;
            // 
            // фИОTextBox4
            // 
            this.фИОTextBox4.Location = new System.Drawing.Point(102, 76);
            this.фИОTextBox4.Name = "фИОTextBox4";
            this.фИОTextBox4.ReadOnly = true;
            this.фИОTextBox4.Size = new System.Drawing.Size(200, 20);
            this.фИОTextBox4.TabIndex = 5;
            // 
            // полTextBox3
            // 
            this.полTextBox3.Location = new System.Drawing.Point(102, 102);
            this.полTextBox3.Name = "полTextBox3";
            this.полTextBox3.ReadOnly = true;
            this.полTextBox3.Size = new System.Drawing.Size(200, 20);
            this.полTextBox3.TabIndex = 7;
            // 
            // дата_рожденияDateTimePicker3
            // 
            this.дата_рожденияDateTimePicker3.Location = new System.Drawing.Point(102, 128);
            this.дата_рожденияDateTimePicker3.Name = "дата_рожденияDateTimePicker3";
            this.дата_рожденияDateTimePicker3.Size = new System.Drawing.Size(200, 20);
            this.дата_рожденияDateTimePicker3.TabIndex = 9;
            // 
            // адресTextBox3
            // 
            this.адресTextBox3.Location = new System.Drawing.Point(102, 154);
            this.адресTextBox3.Name = "адресTextBox3";
            this.адресTextBox3.ReadOnly = true;
            this.адресTextBox3.Size = new System.Drawing.Size(200, 20);
            this.адресTextBox3.TabIndex = 11;
            // 
            // телефонTextBox4
            // 
            this.телефонTextBox4.Location = new System.Drawing.Point(102, 180);
            this.телефонTextBox4.Name = "телефонTextBox4";
            this.телефонTextBox4.ReadOnly = true;
            this.телефонTextBox4.Size = new System.Drawing.Size(200, 20);
            this.телефонTextBox4.TabIndex = 13;
            // 
            // паспортTextBox3
            // 
            this.паспортTextBox3.Location = new System.Drawing.Point(102, 206);
            this.паспортTextBox3.Name = "паспортTextBox3";
            this.паспортTextBox3.ReadOnly = true;
            this.паспортTextBox3.Size = new System.Drawing.Size(200, 20);
            this.паспортTextBox3.TabIndex = 15;
            // 
            // примечаниеTextBox16
            // 
            this.примечаниеTextBox16.Location = new System.Drawing.Point(102, 232);
            this.примечаниеTextBox16.Name = "примечаниеTextBox16";
            this.примечаниеTextBox16.ReadOnly = true;
            this.примечаниеTextBox16.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox16.TabIndex = 17;
            // 
            // groupBox10
            // 
            this.groupBox10.Controls.Add(код_сотрудникаLabel2);
            this.groupBox10.Controls.Add(this.примечаниеTextBox6);
            this.groupBox10.Controls.Add(this.button24);
            this.groupBox10.Controls.Add(примечаниеLabel6);
            this.groupBox10.Controls.Add(this.паспортTextBox1);
            this.groupBox10.Controls.Add(this.button25);
            this.groupBox10.Controls.Add(паспортLabel1);
            this.groupBox10.Controls.Add(this.button7);
            this.groupBox10.Controls.Add(this.телефонTextBox1);
            this.groupBox10.Controls.Add(телефонLabel1);
            this.groupBox10.Controls.Add(this.адресTextBox1);
            this.groupBox10.Controls.Add(адресLabel1);
            this.groupBox10.Controls.Add(this.дата_рожденияDateTimePicker1);
            this.groupBox10.Controls.Add(дата_рожденияLabel1);
            this.groupBox10.Controls.Add(this.полTextBox1);
            this.groupBox10.Controls.Add(полLabel1);
            this.groupBox10.Controls.Add(this.фИОTextBox1);
            this.groupBox10.Controls.Add(фИОLabel1);
            this.groupBox10.Controls.Add(this.должностьTextBox);
            this.groupBox10.Controls.Add(должностьLabel);
            this.groupBox10.Controls.Add(this.код_сотрудникаTextBox2);
            this.groupBox10.Location = new System.Drawing.Point(6, 6);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(470, 266);
            this.groupBox10.TabIndex = 40;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "groupBox10";
            // 
            // примечаниеTextBox6
            // 
            this.примечаниеTextBox6.Location = new System.Drawing.Point(102, 232);
            this.примечаниеTextBox6.Name = "примечаниеTextBox6";
            this.примечаниеTextBox6.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox6.TabIndex = 18;
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(344, 85);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(120, 23);
            this.button24.TabIndex = 39;
            this.button24.Text = "Удалить строку";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.delete_line);
            // 
            // паспортTextBox1
            // 
            this.паспортTextBox1.Location = new System.Drawing.Point(102, 206);
            this.паспортTextBox1.Name = "паспортTextBox1";
            this.паспортTextBox1.Size = new System.Drawing.Size(200, 20);
            this.паспортTextBox1.TabIndex = 16;
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(344, 56);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(120, 23);
            this.button25.TabIndex = 38;
            this.button25.Text = "Изменить строку";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.update_line);
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(344, 27);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(120, 23);
            this.button7.TabIndex = 19;
            this.button7.Text = "Добавить строку";
            this.button7.UseVisualStyleBackColor = true;
            this.button7.Click += new System.EventHandler(this.insert_line);
            // 
            // телефонTextBox1
            // 
            this.телефонTextBox1.Location = new System.Drawing.Point(102, 180);
            this.телефонTextBox1.Name = "телефонTextBox1";
            this.телефонTextBox1.Size = new System.Drawing.Size(200, 20);
            this.телефонTextBox1.TabIndex = 14;
            // 
            // адресTextBox1
            // 
            this.адресTextBox1.Location = new System.Drawing.Point(102, 154);
            this.адресTextBox1.Name = "адресTextBox1";
            this.адресTextBox1.Size = new System.Drawing.Size(200, 20);
            this.адресTextBox1.TabIndex = 12;
            // 
            // дата_рожденияDateTimePicker1
            // 
            this.дата_рожденияDateTimePicker1.Location = new System.Drawing.Point(102, 128);
            this.дата_рожденияDateTimePicker1.Name = "дата_рожденияDateTimePicker1";
            this.дата_рожденияDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.дата_рожденияDateTimePicker1.TabIndex = 10;
            // 
            // полTextBox1
            // 
            this.полTextBox1.Location = new System.Drawing.Point(102, 102);
            this.полTextBox1.Name = "полTextBox1";
            this.полTextBox1.Size = new System.Drawing.Size(200, 20);
            this.полTextBox1.TabIndex = 8;
            // 
            // фИОTextBox1
            // 
            this.фИОTextBox1.Location = new System.Drawing.Point(102, 76);
            this.фИОTextBox1.Name = "фИОTextBox1";
            this.фИОTextBox1.Size = new System.Drawing.Size(200, 20);
            this.фИОTextBox1.TabIndex = 6;
            // 
            // должностьTextBox
            // 
            this.должностьTextBox.Location = new System.Drawing.Point(102, 50);
            this.должностьTextBox.Name = "должностьTextBox";
            this.должностьTextBox.Size = new System.Drawing.Size(200, 20);
            this.должностьTextBox.TabIndex = 4;
            // 
            // код_сотрудникаTextBox2
            // 
            this.код_сотрудникаTextBox2.Location = new System.Drawing.Point(102, 24);
            this.код_сотрудникаTextBox2.Name = "код_сотрудникаTextBox2";
            this.код_сотрудникаTextBox2.ReadOnly = true;
            this.код_сотрудникаTextBox2.Size = new System.Drawing.Size(200, 20);
            this.код_сотрудникаTextBox2.TabIndex = 2;
            // 
            // tabPage9
            // 
            this.tabPage9.AutoScroll = true;
            this.tabPage9.Controls.Add(this.button_data8);
            this.tabPage9.Controls.Add(this.уборкаDataGridView);
            this.tabPage9.Controls.Add(this.groupBox13);
            this.tabPage9.Controls.Add(this.groupBox14);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(955, 528);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "tabPage9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // button_data8
            // 
            this.button_data8.Location = new System.Drawing.Point(580, 28);
            this.button_data8.Name = "button_data8";
            this.button_data8.Size = new System.Drawing.Size(95, 23);
            this.button_data8.TabIndex = 40;
            this.button_data8.Tag = "8";
            this.button_data8.Text = "<<Перенести<<";
            this.button_data8.UseVisualStyleBackColor = true;
            this.button_data8.Click += new System.EventHandler(this.DataTransfer);
            // 
            // уборкаDataGridView
            // 
            this.уборкаDataGridView.AutoGenerateColumns = false;
            this.уборкаDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.уборкаDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19});
            this.уборкаDataGridView.DataSource = this.уборкаBindingSource;
            this.уборкаDataGridView.Location = new System.Drawing.Point(3, 278);
            this.уборкаDataGridView.Name = "уборкаDataGridView";
            this.уборкаDataGridView.Size = new System.Drawing.Size(949, 246);
            this.уборкаDataGridView.TabIndex = 39;
            this.уборкаDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.уборкаDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn14.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn15.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "День недели";
            this.dataGridViewTextBoxColumn16.HeaderText = "День недели";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Время начала уборки";
            this.dataGridViewTextBoxColumn17.HeaderText = "Время начала уборки";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Длительность";
            this.dataGridViewTextBoxColumn18.HeaderText = "Длительность";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn19.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // уборкаBindingSource
            // 
            this.уборкаBindingSource.DataMember = "Уборка";
            this.уборкаBindingSource.DataSource = this.hotelDataSet;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(код_сотрудникаLabel7);
            this.groupBox13.Controls.Add(this.примечаниеTextBox18);
            this.groupBox13.Controls.Add(this.код_сотрудникаTextBox7);
            this.groupBox13.Controls.Add(примечаниеLabel18);
            this.groupBox13.Controls.Add(номерLabel7);
            this.groupBox13.Controls.Add(this.длительностьTextBox1);
            this.groupBox13.Controls.Add(this.номерTextBox7);
            this.groupBox13.Controls.Add(длительностьLabel1);
            this.groupBox13.Controls.Add(день_неделиLabel1);
            this.groupBox13.Controls.Add(this.время_начала_уборкиTextBox1);
            this.groupBox13.Controls.Add(this.день_неделиTextBox1);
            this.groupBox13.Controls.Add(время_начала_уборкиLabel1);
            this.groupBox13.Location = new System.Drawing.Point(681, 6);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(268, 266);
            this.groupBox13.TabIndex = 39;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox18
            // 
            this.примечаниеTextBox18.Location = new System.Drawing.Point(131, 154);
            this.примечаниеTextBox18.Name = "примечаниеTextBox18";
            this.примечаниеTextBox18.ReadOnly = true;
            this.примечаниеTextBox18.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox18.TabIndex = 25;
            // 
            // код_сотрудникаTextBox7
            // 
            this.код_сотрудникаTextBox7.Location = new System.Drawing.Point(131, 24);
            this.код_сотрудникаTextBox7.Name = "код_сотрудникаTextBox7";
            this.код_сотрудникаTextBox7.ReadOnly = true;
            this.код_сотрудникаTextBox7.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox7.TabIndex = 15;
            // 
            // длительностьTextBox1
            // 
            this.длительностьTextBox1.Location = new System.Drawing.Point(131, 128);
            this.длительностьTextBox1.Name = "длительностьTextBox1";
            this.длительностьTextBox1.ReadOnly = true;
            this.длительностьTextBox1.Size = new System.Drawing.Size(126, 20);
            this.длительностьTextBox1.TabIndex = 23;
            // 
            // номерTextBox7
            // 
            this.номерTextBox7.Location = new System.Drawing.Point(131, 50);
            this.номерTextBox7.Name = "номерTextBox7";
            this.номерTextBox7.ReadOnly = true;
            this.номерTextBox7.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox7.TabIndex = 17;
            // 
            // время_начала_уборкиTextBox1
            // 
            this.время_начала_уборкиTextBox1.Location = new System.Drawing.Point(131, 102);
            this.время_начала_уборкиTextBox1.Name = "время_начала_уборкиTextBox1";
            this.время_начала_уборкиTextBox1.ReadOnly = true;
            this.время_начала_уборкиTextBox1.Size = new System.Drawing.Size(126, 20);
            this.время_начала_уборкиTextBox1.TabIndex = 21;
            // 
            // день_неделиTextBox1
            // 
            this.день_неделиTextBox1.Location = new System.Drawing.Point(131, 76);
            this.день_неделиTextBox1.Name = "день_неделиTextBox1";
            this.день_неделиTextBox1.ReadOnly = true;
            this.день_неделиTextBox1.Size = new System.Drawing.Size(126, 20);
            this.день_неделиTextBox1.TabIndex = 19;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button29);
            this.groupBox14.Controls.Add(this.button9);
            this.groupBox14.Controls.Add(this.button28);
            this.groupBox14.Controls.Add(код_сотрудникаLabel3);
            this.groupBox14.Controls.Add(this.примечаниеTextBox8);
            this.groupBox14.Controls.Add(примечаниеLabel8);
            this.groupBox14.Controls.Add(this.длительностьTextBox);
            this.groupBox14.Controls.Add(длительностьLabel);
            this.groupBox14.Controls.Add(this.время_начала_уборкиTextBox);
            this.groupBox14.Controls.Add(время_начала_уборкиLabel);
            this.groupBox14.Controls.Add(this.день_неделиTextBox);
            this.groupBox14.Controls.Add(день_неделиLabel);
            this.groupBox14.Controls.Add(this.номерTextBox3);
            this.groupBox14.Controls.Add(номерLabel3);
            this.groupBox14.Controls.Add(this.код_сотрудникаTextBox3);
            this.groupBox14.Location = new System.Drawing.Point(6, 6);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(440, 266);
            this.groupBox14.TabIndex = 38;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Окно ввода данных";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(303, 56);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(120, 23);
            this.button29.TabIndex = 26;
            this.button29.Text = "Изменить строку";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.update_line);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(303, 27);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(120, 23);
            this.button9.TabIndex = 13;
            this.button9.Text = "Добавить строку";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.insert_line);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(303, 85);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(120, 23);
            this.button28.TabIndex = 27;
            this.button28.Text = "Удалить строку";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.delete_line);
            // 
            // примечаниеTextBox8
            // 
            this.примечаниеTextBox8.Location = new System.Drawing.Point(131, 154);
            this.примечаниеTextBox8.Name = "примечаниеTextBox8";
            this.примечаниеTextBox8.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox8.TabIndex = 12;
            // 
            // длительностьTextBox
            // 
            this.длительностьTextBox.Location = new System.Drawing.Point(131, 128);
            this.длительностьTextBox.Name = "длительностьTextBox";
            this.длительностьTextBox.Size = new System.Drawing.Size(126, 20);
            this.длительностьTextBox.TabIndex = 10;
            // 
            // время_начала_уборкиTextBox
            // 
            this.время_начала_уборкиTextBox.Location = new System.Drawing.Point(131, 102);
            this.время_начала_уборкиTextBox.Name = "время_начала_уборкиTextBox";
            this.время_начала_уборкиTextBox.Size = new System.Drawing.Size(126, 20);
            this.время_начала_уборкиTextBox.TabIndex = 8;
            // 
            // день_неделиTextBox
            // 
            this.день_неделиTextBox.Location = new System.Drawing.Point(131, 76);
            this.день_неделиTextBox.Name = "день_неделиTextBox";
            this.день_неделиTextBox.Size = new System.Drawing.Size(126, 20);
            this.день_неделиTextBox.TabIndex = 6;
            // 
            // номерTextBox3
            // 
            this.номерTextBox3.Location = new System.Drawing.Point(131, 50);
            this.номерTextBox3.Name = "номерTextBox3";
            this.номерTextBox3.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox3.TabIndex = 4;
            // 
            // код_сотрудникаTextBox3
            // 
            this.код_сотрудникаTextBox3.Location = new System.Drawing.Point(131, 24);
            this.код_сотрудникаTextBox3.Name = "код_сотрудникаTextBox3";
            this.код_сотрудникаTextBox3.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox3.TabIndex = 2;
            // 
            // tabPage10
            // 
            this.tabPage10.AutoScroll = true;
            this.tabPage10.Controls.Add(this.button_data9);
            this.tabPage10.Controls.Add(this.пользователиDataGridView);
            this.tabPage10.Controls.Add(this.groupBox15);
            this.tabPage10.Controls.Add(this.groupBox16);
            this.tabPage10.Location = new System.Drawing.Point(4, 22);
            this.tabPage10.Name = "tabPage10";
            this.tabPage10.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage10.Size = new System.Drawing.Size(955, 528);
            this.tabPage10.TabIndex = 9;
            this.tabPage10.Text = "tabPage10";
            this.tabPage10.UseVisualStyleBackColor = true;
            // 
            // button_data9
            // 
            this.button_data9.Location = new System.Drawing.Point(599, 28);
            this.button_data9.Name = "button_data9";
            this.button_data9.Size = new System.Drawing.Size(95, 23);
            this.button_data9.TabIndex = 45;
            this.button_data9.Tag = "9";
            this.button_data9.Text = "<<Перенести<<";
            this.button_data9.UseVisualStyleBackColor = true;
            this.button_data9.Click += new System.EventHandler(this.DataTransfer);
            // 
            // пользователиDataGridView
            // 
            this.пользователиDataGridView.AutoGenerateColumns = false;
            this.пользователиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.пользователиDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn40,
            this.dataGridViewTextBoxColumn41,
            this.dataGridViewTextBoxColumn52,
            this.dataGridViewTextBoxColumn53,
            this.dataGridViewTextBoxColumn54,
            this.dataGridViewTextBoxColumn55,
            this.dataGridViewTextBoxColumn56,
            this.dataGridViewTextBoxColumn57});
            this.пользователиDataGridView.DataSource = this.пользователиBindingSource;
            this.пользователиDataGridView.Location = new System.Drawing.Point(3, 278);
            this.пользователиDataGridView.Name = "пользователиDataGridView";
            this.пользователиDataGridView.Size = new System.Drawing.Size(949, 246);
            this.пользователиDataGridView.TabIndex = 44;
            this.пользователиDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.пользователиDataGridView_CellClick);
            // 
            // dataGridViewTextBoxColumn40
            // 
            this.dataGridViewTextBoxColumn40.DataPropertyName = "Логин";
            this.dataGridViewTextBoxColumn40.HeaderText = "Логин";
            this.dataGridViewTextBoxColumn40.Name = "dataGridViewTextBoxColumn40";
            // 
            // dataGridViewTextBoxColumn41
            // 
            this.dataGridViewTextBoxColumn41.DataPropertyName = "Пароль";
            this.dataGridViewTextBoxColumn41.HeaderText = "Пароль";
            this.dataGridViewTextBoxColumn41.Name = "dataGridViewTextBoxColumn41";
            // 
            // dataGridViewTextBoxColumn52
            // 
            this.dataGridViewTextBoxColumn52.DataPropertyName = "Роль";
            this.dataGridViewTextBoxColumn52.HeaderText = "Роль";
            this.dataGridViewTextBoxColumn52.Name = "dataGridViewTextBoxColumn52";
            // 
            // dataGridViewTextBoxColumn53
            // 
            this.dataGridViewTextBoxColumn53.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn53.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn53.Name = "dataGridViewTextBoxColumn53";
            // 
            // dataGridViewTextBoxColumn54
            // 
            this.dataGridViewTextBoxColumn54.DataPropertyName = "ФИО";
            this.dataGridViewTextBoxColumn54.HeaderText = "ФИО";
            this.dataGridViewTextBoxColumn54.Name = "dataGridViewTextBoxColumn54";
            // 
            // dataGridViewTextBoxColumn55
            // 
            this.dataGridViewTextBoxColumn55.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn55.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn55.Name = "dataGridViewTextBoxColumn55";
            // 
            // dataGridViewTextBoxColumn56
            // 
            this.dataGridViewTextBoxColumn56.DataPropertyName = "Почта";
            this.dataGridViewTextBoxColumn56.HeaderText = "Почта";
            this.dataGridViewTextBoxColumn56.Name = "dataGridViewTextBoxColumn56";
            // 
            // dataGridViewTextBoxColumn57
            // 
            this.dataGridViewTextBoxColumn57.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn57.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn57.Name = "dataGridViewTextBoxColumn57";
            // 
            // пользователиBindingSource
            // 
            this.пользователиBindingSource.DataMember = "Пользователи";
            this.пользователиBindingSource.DataSource = this.hotelDataSet;
            // 
            // groupBox15
            // 
            this.groupBox15.Controls.Add(код_сотрудникаLabel9);
            this.groupBox15.Controls.Add(this.код_сотрудникаTextBox9);
            this.groupBox15.Controls.Add(рольLabel1);
            this.groupBox15.Controls.Add(this.рольTextBox1);
            this.groupBox15.Controls.Add(логинLabel1);
            this.groupBox15.Controls.Add(this.примечаниеTextBox19);
            this.groupBox15.Controls.Add(примечаниеLabel19);
            this.groupBox15.Controls.Add(this.почтаTextBox1);
            this.groupBox15.Controls.Add(почтаLabel1);
            this.groupBox15.Controls.Add(this.логинTextBox1);
            this.groupBox15.Controls.Add(this.телефонTextBox5);
            this.groupBox15.Controls.Add(парольLabel1);
            this.groupBox15.Controls.Add(телефонLabel5);
            this.groupBox15.Controls.Add(this.парольTextBox1);
            this.groupBox15.Controls.Add(this.фИОTextBox5);
            this.groupBox15.Controls.Add(фИОLabel5);
            this.groupBox15.Location = new System.Drawing.Point(700, 6);
            this.groupBox15.Name = "groupBox15";
            this.groupBox15.Size = new System.Drawing.Size(250, 266);
            this.groupBox15.TabIndex = 44;
            this.groupBox15.TabStop = false;
            this.groupBox15.Text = "Окно вывода данных";
            // 
            // код_сотрудникаTextBox9
            // 
            this.код_сотрудникаTextBox9.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.пользователиBindingSource, "Код сотрудника", true));
            this.код_сотрудникаTextBox9.Location = new System.Drawing.Point(118, 102);
            this.код_сотрудникаTextBox9.Name = "код_сотрудникаTextBox9";
            this.код_сотрудникаTextBox9.ReadOnly = true;
            this.код_сотрудникаTextBox9.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox9.TabIndex = 42;
            // 
            // рольTextBox1
            // 
            this.рольTextBox1.Location = new System.Drawing.Point(118, 76);
            this.рольTextBox1.Name = "рольTextBox1";
            this.рольTextBox1.ReadOnly = true;
            this.рольTextBox1.Size = new System.Drawing.Size(126, 20);
            this.рольTextBox1.TabIndex = 41;
            // 
            // примечаниеTextBox19
            // 
            this.примечаниеTextBox19.Location = new System.Drawing.Point(118, 206);
            this.примечаниеTextBox19.Name = "примечаниеTextBox19";
            this.примечаниеTextBox19.ReadOnly = true;
            this.примечаниеTextBox19.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox19.TabIndex = 40;
            // 
            // почтаTextBox1
            // 
            this.почтаTextBox1.Location = new System.Drawing.Point(118, 180);
            this.почтаTextBox1.Name = "почтаTextBox1";
            this.почтаTextBox1.ReadOnly = true;
            this.почтаTextBox1.Size = new System.Drawing.Size(126, 20);
            this.почтаTextBox1.TabIndex = 38;
            // 
            // логинTextBox1
            // 
            this.логинTextBox1.Location = new System.Drawing.Point(118, 24);
            this.логинTextBox1.Name = "логинTextBox1";
            this.логинTextBox1.ReadOnly = true;
            this.логинTextBox1.Size = new System.Drawing.Size(126, 20);
            this.логинTextBox1.TabIndex = 28;
            // 
            // телефонTextBox5
            // 
            this.телефонTextBox5.Location = new System.Drawing.Point(118, 154);
            this.телефонTextBox5.Name = "телефонTextBox5";
            this.телефонTextBox5.ReadOnly = true;
            this.телефонTextBox5.Size = new System.Drawing.Size(126, 20);
            this.телефонTextBox5.TabIndex = 36;
            // 
            // парольTextBox1
            // 
            this.парольTextBox1.Location = new System.Drawing.Point(118, 50);
            this.парольTextBox1.Name = "парольTextBox1";
            this.парольTextBox1.ReadOnly = true;
            this.парольTextBox1.Size = new System.Drawing.Size(126, 20);
            this.парольTextBox1.TabIndex = 30;
            // 
            // фИОTextBox5
            // 
            this.фИОTextBox5.Location = new System.Drawing.Point(118, 128);
            this.фИОTextBox5.Name = "фИОTextBox5";
            this.фИОTextBox5.ReadOnly = true;
            this.фИОTextBox5.Size = new System.Drawing.Size(126, 20);
            this.фИОTextBox5.TabIndex = 34;
            // 
            // groupBox16
            // 
            this.groupBox16.Controls.Add(код_сотрудникаLabel8);
            this.groupBox16.Controls.Add(логинLabel);
            this.groupBox16.Controls.Add(this.примечаниеTextBox9);
            this.groupBox16.Controls.Add(this.код_сотрудникаTextBox8);
            this.groupBox16.Controls.Add(this.button10);
            this.groupBox16.Controls.Add(this.button30);
            this.groupBox16.Controls.Add(рольLabel);
            this.groupBox16.Controls.Add(примечаниеLabel9);
            this.groupBox16.Controls.Add(this.рольTextBox);
            this.groupBox16.Controls.Add(this.button31);
            this.groupBox16.Controls.Add(this.почтаTextBox);
            this.groupBox16.Controls.Add(почтаLabel);
            this.groupBox16.Controls.Add(this.логинTextBox);
            this.groupBox16.Controls.Add(this.телефонTextBox2);
            this.groupBox16.Controls.Add(парольLabel);
            this.groupBox16.Controls.Add(телефонLabel2);
            this.groupBox16.Controls.Add(this.парольTextBox);
            this.groupBox16.Controls.Add(this.фИОTextBox2);
            this.groupBox16.Controls.Add(фИОLabel2);
            this.groupBox16.Location = new System.Drawing.Point(6, 6);
            this.groupBox16.Name = "groupBox16";
            this.groupBox16.Size = new System.Drawing.Size(428, 266);
            this.groupBox16.TabIndex = 43;
            this.groupBox16.TabStop = false;
            this.groupBox16.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox9
            // 
            this.примечаниеTextBox9.Location = new System.Drawing.Point(99, 206);
            this.примечаниеTextBox9.Name = "примечаниеTextBox9";
            this.примечаниеTextBox9.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox9.TabIndex = 27;
            // 
            // код_сотрудникаTextBox8
            // 
            this.код_сотрудникаTextBox8.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.пользователиBindingSource, "Код сотрудника", true));
            this.код_сотрудникаTextBox8.Location = new System.Drawing.Point(99, 102);
            this.код_сотрудникаTextBox8.Name = "код_сотрудникаTextBox8";
            this.код_сотрудникаTextBox8.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox8.TabIndex = 44;
            // 
            // button10
            // 
            this.button10.Location = new System.Drawing.Point(290, 21);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(120, 23);
            this.button10.TabIndex = 14;
            this.button10.Text = "Добавить строку";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.insert_line);
            // 
            // button30
            // 
            this.button30.Location = new System.Drawing.Point(290, 79);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(120, 23);
            this.button30.TabIndex = 42;
            this.button30.Text = "Удалить строку";
            this.button30.UseVisualStyleBackColor = true;
            this.button30.Click += new System.EventHandler(this.delete_line);
            // 
            // рольTextBox
            // 
            this.рольTextBox.Location = new System.Drawing.Point(99, 76);
            this.рольTextBox.Name = "рольTextBox";
            this.рольTextBox.Size = new System.Drawing.Size(126, 20);
            this.рольTextBox.TabIndex = 43;
            // 
            // button31
            // 
            this.button31.Location = new System.Drawing.Point(290, 50);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(120, 23);
            this.button31.TabIndex = 41;
            this.button31.Text = "Изменить строку";
            this.button31.UseVisualStyleBackColor = true;
            this.button31.Click += new System.EventHandler(this.update_line);
            // 
            // почтаTextBox
            // 
            this.почтаTextBox.Location = new System.Drawing.Point(99, 180);
            this.почтаTextBox.Name = "почтаTextBox";
            this.почтаTextBox.Size = new System.Drawing.Size(126, 20);
            this.почтаTextBox.TabIndex = 25;
            // 
            // логинTextBox
            // 
            this.логинTextBox.Location = new System.Drawing.Point(99, 24);
            this.логинTextBox.Name = "логинTextBox";
            this.логинTextBox.Size = new System.Drawing.Size(126, 20);
            this.логинTextBox.TabIndex = 15;
            // 
            // телефонTextBox2
            // 
            this.телефонTextBox2.Location = new System.Drawing.Point(99, 154);
            this.телефонTextBox2.Name = "телефонTextBox2";
            this.телефонTextBox2.Size = new System.Drawing.Size(126, 20);
            this.телефонTextBox2.TabIndex = 23;
            // 
            // парольTextBox
            // 
            this.парольTextBox.Location = new System.Drawing.Point(99, 50);
            this.парольTextBox.Name = "парольTextBox";
            this.парольTextBox.Size = new System.Drawing.Size(126, 20);
            this.парольTextBox.TabIndex = 17;
            // 
            // фИОTextBox2
            // 
            this.фИОTextBox2.Location = new System.Drawing.Point(99, 128);
            this.фИОTextBox2.Name = "фИОTextBox2";
            this.фИОTextBox2.Size = new System.Drawing.Size(126, 20);
            this.фИОTextBox2.TabIndex = 21;
            // 
            // tabPage11
            // 
            this.tabPage11.AutoScroll = true;
            this.tabPage11.Controls.Add(this.button32);
            this.tabPage11.Controls.Add(this.оказанные_услугиDataGridView1);
            this.tabPage11.Controls.Add(this.номера_с_клиентамиDataGridView);
            this.tabPage11.Controls.Add(this.бронь_номеровDataGridView);
            this.tabPage11.Controls.Add(this.comboBox1);
            this.tabPage11.Location = new System.Drawing.Point(4, 22);
            this.tabPage11.Name = "tabPage11";
            this.tabPage11.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage11.Size = new System.Drawing.Size(955, 528);
            this.tabPage11.TabIndex = 10;
            this.tabPage11.Text = "tabPage11";
            this.tabPage11.UseVisualStyleBackColor = true;
            // 
            // button32
            // 
            this.button32.Location = new System.Drawing.Point(296, 319);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(181, 23);
            this.button32.TabIndex = 4;
            this.button32.Text = "Выгрузить данные в excel";
            this.button32.UseVisualStyleBackColor = true;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // оказанные_услугиDataGridView1
            // 
            this.оказанные_услугиDataGridView1.AutoGenerateColumns = false;
            this.оказанные_услугиDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.оказанные_услугиDataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn72,
            this.dataGridViewTextBoxColumn73,
            this.dataGridViewTextBoxColumn74,
            this.dataGridViewTextBoxColumn78,
            this.dataGridViewTextBoxColumn79,
            this.dataGridViewTextBoxColumn80,
            this.dataGridViewTextBoxColumn81});
            this.оказанные_услугиDataGridView1.DataSource = this.оказанные_услугиBindingSource1;
            this.оказанные_услугиDataGridView1.Location = new System.Drawing.Point(0, 0);
            this.оказанные_услугиDataGridView1.Name = "оказанные_услугиDataGridView1";
            this.оказанные_услугиDataGridView1.Size = new System.Drawing.Size(950, 310);
            this.оказанные_услугиDataGridView1.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn72
            // 
            this.dataGridViewTextBoxColumn72.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn72.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn72.Name = "dataGridViewTextBoxColumn72";
            // 
            // dataGridViewTextBoxColumn73
            // 
            this.dataGridViewTextBoxColumn73.DataPropertyName = "ФИО сотрудника";
            this.dataGridViewTextBoxColumn73.HeaderText = "ФИО сотрудника";
            this.dataGridViewTextBoxColumn73.Name = "dataGridViewTextBoxColumn73";
            // 
            // dataGridViewTextBoxColumn74
            // 
            this.dataGridViewTextBoxColumn74.DataPropertyName = "Код клиента";
            this.dataGridViewTextBoxColumn74.HeaderText = "Код клиента";
            this.dataGridViewTextBoxColumn74.Name = "dataGridViewTextBoxColumn74";
            // 
            // dataGridViewTextBoxColumn78
            // 
            this.dataGridViewTextBoxColumn78.DataPropertyName = "ФИО клиента";
            this.dataGridViewTextBoxColumn78.HeaderText = "ФИО клиента";
            this.dataGridViewTextBoxColumn78.Name = "dataGridViewTextBoxColumn78";
            // 
            // dataGridViewTextBoxColumn79
            // 
            this.dataGridViewTextBoxColumn79.DataPropertyName = "Код услуги";
            this.dataGridViewTextBoxColumn79.HeaderText = "Код услуги";
            this.dataGridViewTextBoxColumn79.Name = "dataGridViewTextBoxColumn79";
            // 
            // dataGridViewTextBoxColumn80
            // 
            this.dataGridViewTextBoxColumn80.DataPropertyName = "Наименование";
            this.dataGridViewTextBoxColumn80.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn80.Name = "dataGridViewTextBoxColumn80";
            // 
            // dataGridViewTextBoxColumn81
            // 
            this.dataGridViewTextBoxColumn81.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn81.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn81.Name = "dataGridViewTextBoxColumn81";
            // 
            // оказанные_услугиBindingSource1
            // 
            this.оказанные_услугиBindingSource1.DataMember = "Оказанные услуги";
            this.оказанные_услугиBindingSource1.DataSource = this.hotelDataSet1;
            // 
            // hotelDataSet1
            // 
            this.hotelDataSet1.DataSetName = "HotelDataSet1";
            this.hotelDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // номера_с_клиентамиDataGridView
            // 
            this.номера_с_клиентамиDataGridView.AutoGenerateColumns = false;
            this.номера_с_клиентамиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.номера_с_клиентамиDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn66,
            this.dataGridViewTextBoxColumn67,
            this.dataGridViewTextBoxColumn68,
            this.dataGridViewTextBoxColumn69,
            this.dataGridViewTextBoxColumn70,
            this.dataGridViewTextBoxColumn71});
            this.номера_с_клиентамиDataGridView.DataSource = this.номера_с_клиентамиBindingSource;
            this.номера_с_клиентамиDataGridView.Location = new System.Drawing.Point(0, 0);
            this.номера_с_клиентамиDataGridView.Name = "номера_с_клиентамиDataGridView";
            this.номера_с_клиентамиDataGridView.Size = new System.Drawing.Size(950, 310);
            this.номера_с_клиентамиDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn66
            // 
            this.dataGridViewTextBoxColumn66.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn66.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn66.Name = "dataGridViewTextBoxColumn66";
            // 
            // dataGridViewTextBoxColumn67
            // 
            this.dataGridViewTextBoxColumn67.DataPropertyName = "Вид номера";
            this.dataGridViewTextBoxColumn67.HeaderText = "Вид номера";
            this.dataGridViewTextBoxColumn67.Name = "dataGridViewTextBoxColumn67";
            // 
            // dataGridViewTextBoxColumn68
            // 
            this.dataGridViewTextBoxColumn68.DataPropertyName = "ФИО";
            this.dataGridViewTextBoxColumn68.HeaderText = "ФИО";
            this.dataGridViewTextBoxColumn68.Name = "dataGridViewTextBoxColumn68";
            // 
            // dataGridViewTextBoxColumn69
            // 
            this.dataGridViewTextBoxColumn69.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn69.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn69.Name = "dataGridViewTextBoxColumn69";
            // 
            // dataGridViewTextBoxColumn70
            // 
            this.dataGridViewTextBoxColumn70.DataPropertyName = "Дата прибытия";
            this.dataGridViewTextBoxColumn70.HeaderText = "Дата прибытия";
            this.dataGridViewTextBoxColumn70.Name = "dataGridViewTextBoxColumn70";
            // 
            // dataGridViewTextBoxColumn71
            // 
            this.dataGridViewTextBoxColumn71.DataPropertyName = "Дата отбытия";
            this.dataGridViewTextBoxColumn71.HeaderText = "Дата отбытия";
            this.dataGridViewTextBoxColumn71.Name = "dataGridViewTextBoxColumn71";
            // 
            // номера_с_клиентамиBindingSource
            // 
            this.номера_с_клиентамиBindingSource.DataMember = "Номера с клиентами";
            this.номера_с_клиентамиBindingSource.DataSource = this.hotelDataSet1;
            // 
            // бронь_номеровDataGridView
            // 
            this.бронь_номеровDataGridView.AutoGenerateColumns = false;
            this.бронь_номеровDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.бронь_номеровDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn59,
            this.dataGridViewTextBoxColumn60,
            this.dataGridViewTextBoxColumn61,
            this.dataGridViewTextBoxColumn62,
            this.dataGridViewTextBoxColumn63,
            this.dataGridViewTextBoxColumn64,
            this.dataGridViewTextBoxColumn65});
            this.бронь_номеровDataGridView.DataSource = this.бронь_номеровBindingSource;
            this.бронь_номеровDataGridView.Location = new System.Drawing.Point(0, 0);
            this.бронь_номеровDataGridView.Name = "бронь_номеровDataGridView";
            this.бронь_номеровDataGridView.Size = new System.Drawing.Size(950, 310);
            this.бронь_номеровDataGridView.TabIndex = 3;
            // 
            // dataGridViewTextBoxColumn59
            // 
            this.dataGridViewTextBoxColumn59.DataPropertyName = "ФИО клиента";
            this.dataGridViewTextBoxColumn59.HeaderText = "ФИО клиента";
            this.dataGridViewTextBoxColumn59.Name = "dataGridViewTextBoxColumn59";
            // 
            // dataGridViewTextBoxColumn60
            // 
            this.dataGridViewTextBoxColumn60.DataPropertyName = "Дата рождения";
            this.dataGridViewTextBoxColumn60.HeaderText = "Дата рождения";
            this.dataGridViewTextBoxColumn60.Name = "dataGridViewTextBoxColumn60";
            // 
            // dataGridViewTextBoxColumn61
            // 
            this.dataGridViewTextBoxColumn61.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn61.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn61.Name = "dataGridViewTextBoxColumn61";
            // 
            // dataGridViewTextBoxColumn62
            // 
            this.dataGridViewTextBoxColumn62.DataPropertyName = "Паспорт";
            this.dataGridViewTextBoxColumn62.HeaderText = "Паспорт";
            this.dataGridViewTextBoxColumn62.Name = "dataGridViewTextBoxColumn62";
            // 
            // dataGridViewTextBoxColumn63
            // 
            this.dataGridViewTextBoxColumn63.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn63.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn63.Name = "dataGridViewTextBoxColumn63";
            // 
            // dataGridViewTextBoxColumn64
            // 
            this.dataGridViewTextBoxColumn64.DataPropertyName = "Дата прибытия";
            this.dataGridViewTextBoxColumn64.HeaderText = "Дата прибытия";
            this.dataGridViewTextBoxColumn64.Name = "dataGridViewTextBoxColumn64";
            // 
            // dataGridViewTextBoxColumn65
            // 
            this.dataGridViewTextBoxColumn65.DataPropertyName = "Дата отбытия";
            this.dataGridViewTextBoxColumn65.HeaderText = "Дата отбытия";
            this.dataGridViewTextBoxColumn65.Name = "dataGridViewTextBoxColumn65";
            // 
            // бронь_номеровBindingSource
            // 
            this.бронь_номеровBindingSource.DataMember = "Бронь номеров";
            this.бронь_номеровBindingSource.DataSource = this.hotelDataSet1;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Оказанные услуги",
            "Номера с клиентами",
            "Бронь номеров"});
            this.comboBox1.Location = new System.Drawing.Point(9, 319);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(252, 21);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(269, 27);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 23);
            this.button8.TabIndex = 9;
            this.button8.Text = "Добавить строку";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.insert_line);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(269, 56);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(120, 23);
            this.button27.TabIndex = 22;
            this.button27.Text = "Изменить строку";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.update_line);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(269, 85);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(120, 23);
            this.button26.TabIndex = 23;
            this.button26.Text = "Удалить строку";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.delete_line);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.lb_form_window);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(970, 22);
            this.panel1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(301, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "label1";
            // 
            // button11
            // 
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button11.Location = new System.Drawing.Point(949, 1);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(19, 19);
            this.button11.TabIndex = 6;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.close_form);
            // 
            // lb_form_window
            // 
            this.lb_form_window.AutoSize = true;
            this.lb_form_window.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_form_window.Location = new System.Drawing.Point(2, 2);
            this.lb_form_window.Name = "lb_form_window";
            this.lb_form_window.Size = new System.Drawing.Size(131, 16);
            this.lb_form_window.TabIndex = 7;
            this.lb_form_window.Text = "База данных отеля";
            // 
            // броньTableAdapter
            // 
            this.броньTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.HotelDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.БроньTableAdapter = this.броньTableAdapter;
            this.tableAdapterManager.Доп_услугиTableAdapter = this.доп_услугиTableAdapter;
            this.tableAdapterManager.КлиентTableAdapter = this.клиентTableAdapter;
            this.tableAdapterManager.НомераTableAdapter = this.номераTableAdapter;
            this.tableAdapterManager.Оказанные_услугиTableAdapter = this.оказанные_услугиTableAdapter;
            this.tableAdapterManager.ПользователиTableAdapter = null;
            this.tableAdapterManager.ПропускTableAdapter = this.пропускTableAdapter;
            this.tableAdapterManager.СотрудникTableAdapter = this.сотрудникTableAdapter;
            this.tableAdapterManager.УборкаTableAdapter = this.уборкаTableAdapter;
            // 
            // доп_услугиTableAdapter
            // 
            this.доп_услугиTableAdapter.ClearBeforeFill = true;
            // 
            // клиентTableAdapter
            // 
            this.клиентTableAdapter.ClearBeforeFill = true;
            // 
            // номераTableAdapter
            // 
            this.номераTableAdapter.ClearBeforeFill = true;
            // 
            // оказанные_услугиTableAdapter
            // 
            this.оказанные_услугиTableAdapter.ClearBeforeFill = true;
            // 
            // пропускTableAdapter
            // 
            this.пропускTableAdapter.ClearBeforeFill = true;
            // 
            // сотрудникTableAdapter
            // 
            this.сотрудникTableAdapter.ClearBeforeFill = true;
            // 
            // уборкаTableAdapter
            // 
            this.уборкаTableAdapter.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter
            // 
            this.пользователиTableAdapter.ClearBeforeFill = true;
            // 
            // бронь_номеровTableAdapter
            // 
            this.бронь_номеровTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = WindowsFormsApp1.HotelDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // номера_с_клиентамиTableAdapter
            // 
            this.номера_с_клиентамиTableAdapter.ClearBeforeFill = true;
            // 
            // оказанные_услугиTableAdapter1
            // 
            this.оказанные_услугиTableAdapter1.ClearBeforeFill = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 584);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.броньDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.клиентDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.номераDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номераBindingSource)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пропускDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пропускBindingSource)).EndInit();
            this.tabPage7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникBindingSource)).EndInit();
            this.groupBox9.ResumeLayout(false);
            this.groupBox9.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            this.groupBox10.PerformLayout();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.уборкаDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уборкаBindingSource)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            this.tabPage10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.пользователиDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).EndInit();
            this.groupBox15.ResumeLayout(false);
            this.groupBox15.PerformLayout();
            this.groupBox16.ResumeLayout(false);
            this.groupBox16.PerformLayout();
            this.tabPage11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиDataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номера_с_клиентамиDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номера_с_клиентамиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.бронь_номеровDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.бронь_номеровBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage9;
        public HotelDataSet hotelDataSet;
        public System.Windows.Forms.BindingSource броньBindingSource;
        public HotelDataSetTableAdapters.БроньTableAdapter броньTableAdapter;
        private HotelDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        public HotelDataSetTableAdapters.Доп_услугиTableAdapter доп_услугиTableAdapter;
        public System.Windows.Forms.BindingSource доп_услугиBindingSource;
        public System.Windows.Forms.DataGridView броньDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        public HotelDataSetTableAdapters.КлиентTableAdapter клиентTableAdapter;
        public System.Windows.Forms.BindingSource клиентBindingSource;
        public HotelDataSetTableAdapters.НомераTableAdapter номераTableAdapter;
        public System.Windows.Forms.BindingSource номераBindingSource;
        public System.Windows.Forms.DataGridView номераDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        public HotelDataSetTableAdapters.Оказанные_услугиTableAdapter оказанные_услугиTableAdapter;
        public System.Windows.Forms.BindingSource оказанные_услугиBindingSource;
        public HotelDataSetTableAdapters.ПропускTableAdapter пропускTableAdapter;
        public System.Windows.Forms.BindingSource пропускBindingSource;
        public System.Windows.Forms.DataGridView пропускDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        public HotelDataSetTableAdapters.СотрудникTableAdapter сотрудникTableAdapter;
        public System.Windows.Forms.BindingSource сотрудникBindingSource;
        public System.Windows.Forms.BindingSource тарифBindingSource;
        public System.Windows.Forms.DataGridView тарифDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        public HotelDataSetTableAdapters.УборкаTableAdapter уборкаTableAdapter;
        public System.Windows.Forms.BindingSource уборкаBindingSource;
        private System.Windows.Forms.TextBox код_клиентаTextBox;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox;
        private System.Windows.Forms.TextBox номерTextBox;
        private System.Windows.Forms.TextBox код_пропускаTextBox;
        private System.Windows.Forms.DateTimePicker дата_прибытияDateTimePicker;
        private System.Windows.Forms.DateTimePicker дата_отбытияDateTimePicker;
        private System.Windows.Forms.TextBox стоимостьTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox;
        private System.Windows.Forms.TextBox код_услугиTextBox;
        private System.Windows.Forms.TextBox наименованиеTextBox;
        private System.Windows.Forms.TextBox стоимостьTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox1;
        private System.Windows.Forms.TextBox код_клиентаTextBox1;
        private System.Windows.Forms.TextBox фИОTextBox;
        private System.Windows.Forms.TextBox полTextBox;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker;
        private System.Windows.Forms.TextBox адресTextBox;
        private System.Windows.Forms.TextBox телефонTextBox;
        private System.Windows.Forms.TextBox паспортTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox2;
        private System.Windows.Forms.TextBox номерTextBox1;
        private System.Windows.Forms.TextBox вид_номераTextBox;
        private System.Windows.Forms.TextBox стоимостьTextBox2;
        private System.Windows.Forms.TextBox примечаниеTextBox3;
        private System.Windows.Forms.TextBox код_услугиTextBox1;
        private System.Windows.Forms.TextBox код_клиентаTextBox2;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox4;
        private System.Windows.Forms.TextBox код_пропускаTextBox1;
        private System.Windows.Forms.TextBox номерTextBox2;
        private System.Windows.Forms.TextBox примечаниеTextBox5;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox2;
        private System.Windows.Forms.TextBox должностьTextBox;
        private System.Windows.Forms.TextBox фИОTextBox1;
        private System.Windows.Forms.TextBox полTextBox1;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker1;
        private System.Windows.Forms.TextBox адресTextBox1;
        private System.Windows.Forms.TextBox телефонTextBox1;
        private System.Windows.Forms.TextBox паспортTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox6;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox3;
        private System.Windows.Forms.TextBox номерTextBox3;
        private System.Windows.Forms.TextBox день_неделиTextBox;
        private System.Windows.Forms.TextBox время_начала_уборкиTextBox;
        private System.Windows.Forms.TextBox длительностьTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.DataGridView доп_услугиDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.TabPage tabPage10;
        private System.Windows.Forms.BindingSource пользователиBindingSource;
        private HotelDataSetTableAdapters.ПользователиTableAdapter пользователиTableAdapter;
        private System.Windows.Forms.TextBox логинTextBox;
        private System.Windows.Forms.TextBox парольTextBox;
        private System.Windows.Forms.TextBox фИОTextBox2;
        private System.Windows.Forms.TextBox телефонTextBox2;
        private System.Windows.Forms.TextBox почтаTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.TextBox код_клиентаTextBox3;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox4;
        private System.Windows.Forms.TextBox номерTextBox4;
        private System.Windows.Forms.TextBox код_пропускаTextBox2;
        private System.Windows.Forms.DateTimePicker дата_прибытияDateTimePicker1;
        private System.Windows.Forms.DateTimePicker дата_отбытияDateTimePicker1;
        private System.Windows.Forms.TextBox стоимостьTextBox3;
        private System.Windows.Forms.TextBox примечаниеTextBox10;
        private System.Windows.Forms.TextBox код_услугиTextBox2;
        private System.Windows.Forms.TextBox наименованиеTextBox2;
        private System.Windows.Forms.TextBox стоимостьTextBox4;
        private System.Windows.Forms.TextBox примечаниеTextBox11;
        private System.Windows.Forms.TextBox номерTextBox5;
        private System.Windows.Forms.TextBox вид_номераTextBox1;
        private System.Windows.Forms.TextBox стоимостьTextBox5;
        private System.Windows.Forms.TextBox примечаниеTextBox13;
        private System.Windows.Forms.TextBox код_услугиTextBox3;
        private System.Windows.Forms.TextBox код_клиентаTextBox5;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox5;
        private System.Windows.Forms.TextBox примечаниеTextBox14;
        private System.Windows.Forms.TextBox код_пропускаTextBox3;
        private System.Windows.Forms.TextBox номерTextBox6;
        private System.Windows.Forms.TextBox примечаниеTextBox15;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox7;
        private System.Windows.Forms.TextBox номерTextBox7;
        private System.Windows.Forms.TextBox день_неделиTextBox1;
        private System.Windows.Forms.TextBox время_начала_уборкиTextBox1;
        private System.Windows.Forms.TextBox длительностьTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox18;
        private System.Windows.Forms.TextBox логинTextBox1;
        private System.Windows.Forms.TextBox парольTextBox1;
        private System.Windows.Forms.TextBox фИОTextBox5;
        private System.Windows.Forms.TextBox телефонTextBox5;
        private System.Windows.Forms.TextBox почтаTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox19;
        private System.Windows.Forms.TabPage tabPage11;
        private HotelDataSet1 hotelDataSet1;
        private System.Windows.Forms.BindingSource бронь_номеровBindingSource;
        private System.Windows.Forms.BindingSource номера_с_клиентамиBindingSource;
        private System.Windows.Forms.BindingSource оказанные_услугиBindingSource1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label lb_form_window;
        private System.Windows.Forms.DataGridView оказанные_услугиDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.GroupBox groupBox15;
        private System.Windows.Forms.GroupBox groupBox16;
        private System.Windows.Forms.TextBox рольTextBox1;
        private System.Windows.Forms.TextBox рольTextBox;
        private System.Windows.Forms.TextBox код_клиентаTextBox4;
        private System.Windows.Forms.TextBox фИОTextBox3;
        private System.Windows.Forms.TextBox полTextBox2;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker2;
        private System.Windows.Forms.TextBox адресTextBox2;
        private System.Windows.Forms.TextBox телефонTextBox3;
        private System.Windows.Forms.TextBox паспортTextBox2;
        private System.Windows.Forms.TextBox примечаниеTextBox12;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox6;
        private System.Windows.Forms.TextBox должностьTextBox2;
        private System.Windows.Forms.TextBox фИОTextBox4;
        private System.Windows.Forms.TextBox полTextBox3;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker3;
        private System.Windows.Forms.TextBox адресTextBox3;
        private System.Windows.Forms.TextBox телефонTextBox4;
        private System.Windows.Forms.TextBox паспортTextBox3;
        private System.Windows.Forms.TextBox примечаниеTextBox16;
        private System.Windows.Forms.DataGridView клиентDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn75;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn76;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn77;
        private System.Windows.Forms.DataGridView сотрудникDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn20;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn21;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn33;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn34;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn35;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn36;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn37;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn38;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn39;
        private System.Windows.Forms.DataGridView уборкаDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridView пользователиDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn40;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn41;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn52;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn53;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn54;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn55;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn56;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn57;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox9;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn82;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn84;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private System.Windows.Forms.DataGridView оказанные_услугиDataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn72;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn73;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn74;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn78;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn79;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn80;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn81;
        private System.Windows.Forms.DataGridView номера_с_клиентамиDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn66;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn67;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn68;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn69;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn70;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn71;
        private System.Windows.Forms.DataGridView бронь_номеровDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn59;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn60;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn61;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn62;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn63;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn64;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn65;
        private HotelDataSet1TableAdapters.Бронь_номеровTableAdapter бронь_номеровTableAdapter;
        private HotelDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private HotelDataSet1TableAdapters.Номера_с_клиентамиTableAdapter номера_с_клиентамиTableAdapter;
        private HotelDataSet1TableAdapters.Оказанные_услугиTableAdapter оказанные_услугиTableAdapter1;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button_data1;
        private System.Windows.Forms.Button button_data2;
        private System.Windows.Forms.Button button_data3;
        private System.Windows.Forms.Button button_data4;
        private System.Windows.Forms.Button button_data5;
        private System.Windows.Forms.Button button_data6;
        private System.Windows.Forms.Button button_data7;
        private System.Windows.Forms.Button button_data8;
        private System.Windows.Forms.Button button_data9;
    }
}

