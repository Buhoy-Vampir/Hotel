﻿namespace WindowsFormsApp1
{
    partial class Form7
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.Label код_клиентаLabel;
            System.Windows.Forms.Label код_сотрудникаLabel;
            System.Windows.Forms.Label номерLabel;
            System.Windows.Forms.Label код_пропускаLabel;
            System.Windows.Forms.Label дата_прибытияLabel;
            System.Windows.Forms.Label дата_отбытияLabel;
            System.Windows.Forms.Label стоимостьLabel;
            System.Windows.Forms.Label примечаниеLabel;
            System.Windows.Forms.Label код_услугиLabel;
            System.Windows.Forms.Label наименованиеLabel;
            System.Windows.Forms.Label стоимостьLabel1;
            System.Windows.Forms.Label примечаниеLabel1;
            System.Windows.Forms.Label код_клиентаLabel1;
            System.Windows.Forms.Label фИОLabel;
            System.Windows.Forms.Label полLabel;
            System.Windows.Forms.Label дата_рожденияLabel;
            System.Windows.Forms.Label адресLabel;
            System.Windows.Forms.Label телефонLabel;
            System.Windows.Forms.Label паспортLabel;
            System.Windows.Forms.Label примечаниеLabel2;
            System.Windows.Forms.Label номерLabel1;
            System.Windows.Forms.Label вид_номераLabel;
            System.Windows.Forms.Label стоимостьLabel2;
            System.Windows.Forms.Label примечаниеLabel3;
            System.Windows.Forms.Label код_услугиLabel1;
            System.Windows.Forms.Label код_клиентаLabel2;
            System.Windows.Forms.Label код_сотрудникаLabel1;
            System.Windows.Forms.Label примечаниеLabel4;
            System.Windows.Forms.Label код_пропускаLabel1;
            System.Windows.Forms.Label номерLabel2;
            System.Windows.Forms.Label примечаниеLabel5;
            System.Windows.Forms.Label код_сотрудникаLabel3;
            System.Windows.Forms.Label номерLabel3;
            System.Windows.Forms.Label день_неделиLabel;
            System.Windows.Forms.Label время_начала_уборкиLabel;
            System.Windows.Forms.Label длительностьLabel;
            System.Windows.Forms.Label примечаниеLabel8;
            System.Windows.Forms.Label код_клиентаLabel3;
            System.Windows.Forms.Label код_сотрудникаLabel4;
            System.Windows.Forms.Label номерLabel4;
            System.Windows.Forms.Label код_пропускаLabel2;
            System.Windows.Forms.Label дата_прибытияLabel1;
            System.Windows.Forms.Label дата_отбытияLabel1;
            System.Windows.Forms.Label стоимостьLabel3;
            System.Windows.Forms.Label примечаниеLabel10;
            System.Windows.Forms.Label код_услугиLabel2;
            System.Windows.Forms.Label наименованиеLabel2;
            System.Windows.Forms.Label стоимостьLabel4;
            System.Windows.Forms.Label примечаниеLabel11;
            System.Windows.Forms.Label номерLabel5;
            System.Windows.Forms.Label вид_номераLabel1;
            System.Windows.Forms.Label стоимостьLabel5;
            System.Windows.Forms.Label примечаниеLabel13;
            System.Windows.Forms.Label код_услугиLabel3;
            System.Windows.Forms.Label код_клиентаLabel5;
            System.Windows.Forms.Label код_сотрудникаLabel5;
            System.Windows.Forms.Label примечаниеLabel14;
            System.Windows.Forms.Label код_пропускаLabel3;
            System.Windows.Forms.Label номерLabel6;
            System.Windows.Forms.Label примечаниеLabel15;
            System.Windows.Forms.Label код_сотрудникаLabel7;
            System.Windows.Forms.Label номерLabel7;
            System.Windows.Forms.Label день_неделиLabel1;
            System.Windows.Forms.Label время_начала_уборкиLabel1;
            System.Windows.Forms.Label длительностьLabel1;
            System.Windows.Forms.Label примечаниеLabel18;
            System.Windows.Forms.Label код_клиентаLabel4;
            System.Windows.Forms.Label фИОLabel3;
            System.Windows.Forms.Label полLabel2;
            System.Windows.Forms.Label дата_рожденияLabel2;
            System.Windows.Forms.Label адресLabel2;
            System.Windows.Forms.Label телефонLabel3;
            System.Windows.Forms.Label паспортLabel2;
            System.Windows.Forms.Label примечаниеLabel12;
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form7));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.button_data1 = new System.Windows.Forms.Button();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox10 = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox3 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox3 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox4 = new System.Windows.Forms.TextBox();
            this.дата_отбытияDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.номерTextBox4 = new System.Windows.Forms.TextBox();
            this.дата_прибытияDateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.код_пропускаTextBox2 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.button13 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.примечаниеTextBox = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox = new System.Windows.Forms.TextBox();
            this.дата_отбытияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.дата_прибытияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.код_пропускаTextBox = new System.Windows.Forms.TextBox();
            this.номерTextBox = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.броньDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.броньBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.hotelDataSet = new WindowsFormsApp1.HotelDataSet();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.button_data2 = new System.Windows.Forms.Button();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox11 = new System.Windows.Forms.TextBox();
            this.код_услугиTextBox2 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox4 = new System.Windows.Forms.TextBox();
            this.наименованиеTextBox2 = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.примечаниеTextBox1 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox1 = new System.Windows.Forms.TextBox();
            this.наименованиеTextBox = new System.Windows.Forms.TextBox();
            this.код_услугиTextBox = new System.Windows.Forms.TextBox();
            this.button2 = new System.Windows.Forms.Button();
            this.доп_услугиDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.доп_услугиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.button_data3 = new System.Windows.Forms.Button();
            this.клиентDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn47 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn48 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn49 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn50 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn51 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn75 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn76 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn77 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.код_клиентаTextBox4 = new System.Windows.Forms.TextBox();
            this.фИОTextBox3 = new System.Windows.Forms.TextBox();
            this.полTextBox2 = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker2 = new System.Windows.Forms.DateTimePicker();
            this.адресTextBox2 = new System.Windows.Forms.TextBox();
            this.телефонTextBox3 = new System.Windows.Forms.TextBox();
            this.паспортTextBox2 = new System.Windows.Forms.TextBox();
            this.примечаниеTextBox12 = new System.Windows.Forms.TextBox();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox2 = new System.Windows.Forms.TextBox();
            this.button16 = new System.Windows.Forms.Button();
            this.паспортTextBox = new System.Windows.Forms.TextBox();
            this.button17 = new System.Windows.Forms.Button();
            this.телефонTextBox = new System.Windows.Forms.TextBox();
            this.адресTextBox = new System.Windows.Forms.TextBox();
            this.дата_рожденияDateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.полTextBox = new System.Windows.Forms.TextBox();
            this.фИОTextBox = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox1 = new System.Windows.Forms.TextBox();
            this.button3 = new System.Windows.Forms.Button();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.button_data4 = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox13 = new System.Windows.Forms.TextBox();
            this.стоимостьTextBox5 = new System.Windows.Forms.TextBox();
            this.номерTextBox5 = new System.Windows.Forms.TextBox();
            this.вид_номераTextBox1 = new System.Windows.Forms.TextBox();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox3 = new System.Windows.Forms.TextBox();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.стоимостьTextBox2 = new System.Windows.Forms.TextBox();
            this.вид_номераTextBox = new System.Windows.Forms.TextBox();
            this.номерTextBox1 = new System.Windows.Forms.TextBox();
            this.номераDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn22 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn23 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn24 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn25 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номераBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button_data5 = new System.Windows.Forms.Button();
            this.groupBox19 = new System.Windows.Forms.GroupBox();
            this.код_услугиTextBox3 = new System.Windows.Forms.TextBox();
            this.примечаниеTextBox14 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox5 = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox5 = new System.Windows.Forms.TextBox();
            this.groupBox20 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox4 = new System.Windows.Forms.TextBox();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.код_сотрудникаTextBox1 = new System.Windows.Forms.TextBox();
            this.код_клиентаTextBox2 = new System.Windows.Forms.TextBox();
            this.код_услугиTextBox1 = new System.Windows.Forms.TextBox();
            this.button5 = new System.Windows.Forms.Button();
            this.оказанные_услугиDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn26 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn27 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn28 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn29 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.оказанные_услугиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.button_data6 = new System.Windows.Forms.Button();
            this.groupBox17 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox15 = new System.Windows.Forms.TextBox();
            this.код_пропускаTextBox3 = new System.Windows.Forms.TextBox();
            this.номерTextBox6 = new System.Windows.Forms.TextBox();
            this.groupBox18 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox5 = new System.Windows.Forms.TextBox();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.номерTextBox2 = new System.Windows.Forms.TextBox();
            this.код_пропускаTextBox1 = new System.Windows.Forms.TextBox();
            this.button6 = new System.Windows.Forms.Button();
            this.пропускDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn30 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn31 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn32 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.пропускBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.сотрудникBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.tabPage9 = new System.Windows.Forms.TabPage();
            this.button_data8 = new System.Windows.Forms.Button();
            this.уборкаDataGridView = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.уборкаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.примечаниеTextBox18 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox7 = new System.Windows.Forms.TextBox();
            this.длительностьTextBox1 = new System.Windows.Forms.TextBox();
            this.номерTextBox7 = new System.Windows.Forms.TextBox();
            this.время_начала_уборкиTextBox1 = new System.Windows.Forms.TextBox();
            this.день_неделиTextBox1 = new System.Windows.Forms.TextBox();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.button29 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.примечаниеTextBox8 = new System.Windows.Forms.TextBox();
            this.длительностьTextBox = new System.Windows.Forms.TextBox();
            this.время_начала_уборкиTextBox = new System.Windows.Forms.TextBox();
            this.день_неделиTextBox = new System.Windows.Forms.TextBox();
            this.номерTextBox3 = new System.Windows.Forms.TextBox();
            this.код_сотрудникаTextBox3 = new System.Windows.Forms.TextBox();
            this.пользователиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.оказанные_услугиBindingSource1 = new System.Windows.Forms.BindingSource(this.components);
            this.hotelDataSet1 = new WindowsFormsApp1.HotelDataSet1();
            this.номера_с_клиентамиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.бронь_номеровBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.button8 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.button11 = new System.Windows.Forms.Button();
            this.lb_form_window = new System.Windows.Forms.Label();
            this.броньTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.БроньTableAdapter();
            this.tableAdapterManager = new WindowsFormsApp1.HotelDataSetTableAdapters.TableAdapterManager();
            this.доп_услугиTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.Доп_услугиTableAdapter();
            this.клиентTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.КлиентTableAdapter();
            this.номераTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.НомераTableAdapter();
            this.оказанные_услугиTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.Оказанные_услугиTableAdapter();
            this.пропускTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.ПропускTableAdapter();
            this.сотрудникTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.СотрудникTableAdapter();
            this.уборкаTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.УборкаTableAdapter();
            this.пользователиTableAdapter = new WindowsFormsApp1.HotelDataSetTableAdapters.ПользователиTableAdapter();
            this.бронь_номеровTableAdapter = new WindowsFormsApp1.HotelDataSet1TableAdapters.Бронь_номеровTableAdapter();
            this.tableAdapterManager1 = new WindowsFormsApp1.HotelDataSet1TableAdapters.TableAdapterManager();
            this.номера_с_клиентамиTableAdapter = new WindowsFormsApp1.HotelDataSet1TableAdapters.Номера_с_клиентамиTableAdapter();
            this.оказанные_услугиTableAdapter1 = new WindowsFormsApp1.HotelDataSet1TableAdapters.Оказанные_услугиTableAdapter();
            код_клиентаLabel = new System.Windows.Forms.Label();
            код_сотрудникаLabel = new System.Windows.Forms.Label();
            номерLabel = new System.Windows.Forms.Label();
            код_пропускаLabel = new System.Windows.Forms.Label();
            дата_прибытияLabel = new System.Windows.Forms.Label();
            дата_отбытияLabel = new System.Windows.Forms.Label();
            стоимостьLabel = new System.Windows.Forms.Label();
            примечаниеLabel = new System.Windows.Forms.Label();
            код_услугиLabel = new System.Windows.Forms.Label();
            наименованиеLabel = new System.Windows.Forms.Label();
            стоимостьLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel1 = new System.Windows.Forms.Label();
            код_клиентаLabel1 = new System.Windows.Forms.Label();
            фИОLabel = new System.Windows.Forms.Label();
            полLabel = new System.Windows.Forms.Label();
            дата_рожденияLabel = new System.Windows.Forms.Label();
            адресLabel = new System.Windows.Forms.Label();
            телефонLabel = new System.Windows.Forms.Label();
            паспортLabel = new System.Windows.Forms.Label();
            примечаниеLabel2 = new System.Windows.Forms.Label();
            номерLabel1 = new System.Windows.Forms.Label();
            вид_номераLabel = new System.Windows.Forms.Label();
            стоимостьLabel2 = new System.Windows.Forms.Label();
            примечаниеLabel3 = new System.Windows.Forms.Label();
            код_услугиLabel1 = new System.Windows.Forms.Label();
            код_клиентаLabel2 = new System.Windows.Forms.Label();
            код_сотрудникаLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel4 = new System.Windows.Forms.Label();
            код_пропускаLabel1 = new System.Windows.Forms.Label();
            номерLabel2 = new System.Windows.Forms.Label();
            примечаниеLabel5 = new System.Windows.Forms.Label();
            код_сотрудникаLabel3 = new System.Windows.Forms.Label();
            номерLabel3 = new System.Windows.Forms.Label();
            день_неделиLabel = new System.Windows.Forms.Label();
            время_начала_уборкиLabel = new System.Windows.Forms.Label();
            длительностьLabel = new System.Windows.Forms.Label();
            примечаниеLabel8 = new System.Windows.Forms.Label();
            код_клиентаLabel3 = new System.Windows.Forms.Label();
            код_сотрудникаLabel4 = new System.Windows.Forms.Label();
            номерLabel4 = new System.Windows.Forms.Label();
            код_пропускаLabel2 = new System.Windows.Forms.Label();
            дата_прибытияLabel1 = new System.Windows.Forms.Label();
            дата_отбытияLabel1 = new System.Windows.Forms.Label();
            стоимостьLabel3 = new System.Windows.Forms.Label();
            примечаниеLabel10 = new System.Windows.Forms.Label();
            код_услугиLabel2 = new System.Windows.Forms.Label();
            наименованиеLabel2 = new System.Windows.Forms.Label();
            стоимостьLabel4 = new System.Windows.Forms.Label();
            примечаниеLabel11 = new System.Windows.Forms.Label();
            номерLabel5 = new System.Windows.Forms.Label();
            вид_номераLabel1 = new System.Windows.Forms.Label();
            стоимостьLabel5 = new System.Windows.Forms.Label();
            примечаниеLabel13 = new System.Windows.Forms.Label();
            код_услугиLabel3 = new System.Windows.Forms.Label();
            код_клиентаLabel5 = new System.Windows.Forms.Label();
            код_сотрудникаLabel5 = new System.Windows.Forms.Label();
            примечаниеLabel14 = new System.Windows.Forms.Label();
            код_пропускаLabel3 = new System.Windows.Forms.Label();
            номерLabel6 = new System.Windows.Forms.Label();
            примечаниеLabel15 = new System.Windows.Forms.Label();
            код_сотрудникаLabel7 = new System.Windows.Forms.Label();
            номерLabel7 = new System.Windows.Forms.Label();
            день_неделиLabel1 = new System.Windows.Forms.Label();
            время_начала_уборкиLabel1 = new System.Windows.Forms.Label();
            длительностьLabel1 = new System.Windows.Forms.Label();
            примечаниеLabel18 = new System.Windows.Forms.Label();
            код_клиентаLabel4 = new System.Windows.Forms.Label();
            фИОLabel3 = new System.Windows.Forms.Label();
            полLabel2 = new System.Windows.Forms.Label();
            дата_рожденияLabel2 = new System.Windows.Forms.Label();
            адресLabel2 = new System.Windows.Forms.Label();
            телефонLabel3 = new System.Windows.Forms.Label();
            паспортLabel2 = new System.Windows.Forms.Label();
            примечаниеLabel12 = new System.Windows.Forms.Label();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.броньDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet)).BeginInit();
            this.tabPage2.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиBindingSource)).BeginInit();
            this.tabPage3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.клиентDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).BeginInit();
            this.groupBox6.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox7.SuspendLayout();
            this.groupBox8.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.номераDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номераBindingSource)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox19.SuspendLayout();
            this.groupBox20.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource)).BeginInit();
            this.tabPage6.SuspendLayout();
            this.groupBox17.SuspendLayout();
            this.groupBox18.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пропускDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.пропускBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникBindingSource)).BeginInit();
            this.tabPage9.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.уборкаDataGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.уборкаBindingSource)).BeginInit();
            this.groupBox13.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.номера_с_клиентамиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.бронь_номеровBindingSource)).BeginInit();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // код_клиентаLabel
            // 
            код_клиентаLabel.AutoSize = true;
            код_клиентаLabel.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel.Name = "код_клиентаLabel";
            код_клиентаLabel.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel.TabIndex = 1;
            код_клиентаLabel.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel
            // 
            код_сотрудникаLabel.AutoSize = true;
            код_сотрудникаLabel.Location = new System.Drawing.Point(6, 53);
            код_сотрудникаLabel.Name = "код_сотрудникаLabel";
            код_сотрудникаLabel.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel.TabIndex = 3;
            код_сотрудникаLabel.Text = "Код сотрудника:";
            // 
            // номерLabel
            // 
            номерLabel.AutoSize = true;
            номерLabel.Location = new System.Drawing.Point(6, 79);
            номерLabel.Name = "номерLabel";
            номерLabel.Size = new System.Drawing.Size(44, 13);
            номерLabel.TabIndex = 5;
            номерLabel.Text = "Номер:";
            // 
            // код_пропускаLabel
            // 
            код_пропускаLabel.AutoSize = true;
            код_пропускаLabel.Location = new System.Drawing.Point(6, 105);
            код_пропускаLabel.Name = "код_пропускаLabel";
            код_пропускаLabel.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel.TabIndex = 9;
            код_пропускаLabel.Text = "Код пропуска:";
            // 
            // дата_прибытияLabel
            // 
            дата_прибытияLabel.AutoSize = true;
            дата_прибытияLabel.Location = new System.Drawing.Point(6, 132);
            дата_прибытияLabel.Name = "дата_прибытияLabel";
            дата_прибытияLabel.Size = new System.Drawing.Size(88, 13);
            дата_прибытияLabel.TabIndex = 11;
            дата_прибытияLabel.Text = "Дата прибытия:";
            // 
            // дата_отбытияLabel
            // 
            дата_отбытияLabel.AutoSize = true;
            дата_отбытияLabel.Location = new System.Drawing.Point(6, 158);
            дата_отбытияLabel.Name = "дата_отбытияLabel";
            дата_отбытияLabel.Size = new System.Drawing.Size(81, 13);
            дата_отбытияLabel.TabIndex = 13;
            дата_отбытияLabel.Text = "Дата отбытия:";
            // 
            // стоимостьLabel
            // 
            стоимостьLabel.AutoSize = true;
            стоимостьLabel.Location = new System.Drawing.Point(6, 183);
            стоимостьLabel.Name = "стоимостьLabel";
            стоимостьLabel.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel.TabIndex = 15;
            стоимостьLabel.Text = "Стоимость:";
            // 
            // примечаниеLabel
            // 
            примечаниеLabel.AutoSize = true;
            примечаниеLabel.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel.Name = "примечаниеLabel";
            примечаниеLabel.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel.TabIndex = 17;
            примечаниеLabel.Text = "Примечание:";
            // 
            // код_услугиLabel
            // 
            код_услугиLabel.AutoSize = true;
            код_услугиLabel.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel.Name = "код_услугиLabel";
            код_услугиLabel.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel.TabIndex = 1;
            код_услугиLabel.Text = "Код услуги:";
            // 
            // наименованиеLabel
            // 
            наименованиеLabel.AutoSize = true;
            наименованиеLabel.Location = new System.Drawing.Point(6, 53);
            наименованиеLabel.Name = "наименованиеLabel";
            наименованиеLabel.Size = new System.Drawing.Size(86, 13);
            наименованиеLabel.TabIndex = 3;
            наименованиеLabel.Text = "Наименование:";
            // 
            // стоимостьLabel1
            // 
            стоимостьLabel1.AutoSize = true;
            стоимостьLabel1.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel1.Name = "стоимостьLabel1";
            стоимостьLabel1.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel1.TabIndex = 5;
            стоимостьLabel1.Text = "Стоимость:";
            // 
            // примечаниеLabel1
            // 
            примечаниеLabel1.AutoSize = true;
            примечаниеLabel1.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel1.Name = "примечаниеLabel1";
            примечаниеLabel1.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel1.TabIndex = 7;
            примечаниеLabel1.Text = "Примечание:";
            // 
            // код_клиентаLabel1
            // 
            код_клиентаLabel1.AutoSize = true;
            код_клиентаLabel1.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel1.Name = "код_клиентаLabel1";
            код_клиентаLabel1.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel1.TabIndex = 1;
            код_клиентаLabel1.Text = "Код клиента:";
            // 
            // фИОLabel
            // 
            фИОLabel.AutoSize = true;
            фИОLabel.Location = new System.Drawing.Point(6, 53);
            фИОLabel.Name = "фИОLabel";
            фИОLabel.Size = new System.Drawing.Size(37, 13);
            фИОLabel.TabIndex = 3;
            фИОLabel.Text = "ФИО:";
            // 
            // полLabel
            // 
            полLabel.AutoSize = true;
            полLabel.Location = new System.Drawing.Point(6, 79);
            полLabel.Name = "полLabel";
            полLabel.Size = new System.Drawing.Size(30, 13);
            полLabel.TabIndex = 5;
            полLabel.Text = "Пол:";
            // 
            // дата_рожденияLabel
            // 
            дата_рожденияLabel.AutoSize = true;
            дата_рожденияLabel.Location = new System.Drawing.Point(6, 106);
            дата_рожденияLabel.Name = "дата_рожденияLabel";
            дата_рожденияLabel.Size = new System.Drawing.Size(89, 13);
            дата_рожденияLabel.TabIndex = 7;
            дата_рожденияLabel.Text = "Дата рождения:";
            // 
            // адресLabel
            // 
            адресLabel.AutoSize = true;
            адресLabel.Location = new System.Drawing.Point(6, 131);
            адресLabel.Name = "адресLabel";
            адресLabel.Size = new System.Drawing.Size(41, 13);
            адресLabel.TabIndex = 9;
            адресLabel.Text = "Адрес:";
            // 
            // телефонLabel
            // 
            телефонLabel.AutoSize = true;
            телефонLabel.Location = new System.Drawing.Point(6, 157);
            телефонLabel.Name = "телефонLabel";
            телефонLabel.Size = new System.Drawing.Size(55, 13);
            телефонLabel.TabIndex = 11;
            телефонLabel.Text = "Телефон:";
            // 
            // паспортLabel
            // 
            паспортLabel.AutoSize = true;
            паспортLabel.Location = new System.Drawing.Point(6, 183);
            паспортLabel.Name = "паспортLabel";
            паспортLabel.Size = new System.Drawing.Size(53, 13);
            паспортLabel.TabIndex = 13;
            паспортLabel.Text = "Паспорт:";
            // 
            // примечаниеLabel2
            // 
            примечаниеLabel2.AutoSize = true;
            примечаниеLabel2.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel2.Name = "примечаниеLabel2";
            примечаниеLabel2.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel2.TabIndex = 15;
            примечаниеLabel2.Text = "Примечание:";
            // 
            // номерLabel1
            // 
            номерLabel1.AutoSize = true;
            номерLabel1.Location = new System.Drawing.Point(6, 27);
            номерLabel1.Name = "номерLabel1";
            номерLabel1.Size = new System.Drawing.Size(44, 13);
            номерLabel1.TabIndex = 1;
            номерLabel1.Text = "Номер:";
            // 
            // вид_номераLabel
            // 
            вид_номераLabel.AutoSize = true;
            вид_номераLabel.Location = new System.Drawing.Point(6, 53);
            вид_номераLabel.Name = "вид_номераLabel";
            вид_номераLabel.Size = new System.Drawing.Size(70, 13);
            вид_номераLabel.TabIndex = 3;
            вид_номераLabel.Text = "Вид номера:";
            // 
            // стоимостьLabel2
            // 
            стоимостьLabel2.AutoSize = true;
            стоимостьLabel2.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel2.Name = "стоимостьLabel2";
            стоимостьLabel2.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel2.TabIndex = 5;
            стоимостьLabel2.Text = "Стоимость:";
            // 
            // примечаниеLabel3
            // 
            примечаниеLabel3.AutoSize = true;
            примечаниеLabel3.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel3.Name = "примечаниеLabel3";
            примечаниеLabel3.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel3.TabIndex = 7;
            примечаниеLabel3.Text = "Примечание:";
            // 
            // код_услугиLabel1
            // 
            код_услугиLabel1.AutoSize = true;
            код_услугиLabel1.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel1.Name = "код_услугиLabel1";
            код_услугиLabel1.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel1.TabIndex = 1;
            код_услугиLabel1.Text = "Код услуги:";
            // 
            // код_клиентаLabel2
            // 
            код_клиентаLabel2.AutoSize = true;
            код_клиентаLabel2.Location = new System.Drawing.Point(6, 53);
            код_клиентаLabel2.Name = "код_клиентаLabel2";
            код_клиентаLabel2.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel2.TabIndex = 3;
            код_клиентаLabel2.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel1
            // 
            код_сотрудникаLabel1.AutoSize = true;
            код_сотрудникаLabel1.Location = new System.Drawing.Point(6, 79);
            код_сотрудникаLabel1.Name = "код_сотрудникаLabel1";
            код_сотрудникаLabel1.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel1.TabIndex = 5;
            код_сотрудникаLabel1.Text = "Код сотрудника:";
            // 
            // примечаниеLabel4
            // 
            примечаниеLabel4.AutoSize = true;
            примечаниеLabel4.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel4.Name = "примечаниеLabel4";
            примечаниеLabel4.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel4.TabIndex = 7;
            примечаниеLabel4.Text = "Примечание:";
            // 
            // код_пропускаLabel1
            // 
            код_пропускаLabel1.AutoSize = true;
            код_пропускаLabel1.Location = new System.Drawing.Point(6, 27);
            код_пропускаLabel1.Name = "код_пропускаLabel1";
            код_пропускаLabel1.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel1.TabIndex = 1;
            код_пропускаLabel1.Text = "Код пропуска:";
            // 
            // номерLabel2
            // 
            номерLabel2.AutoSize = true;
            номерLabel2.Location = new System.Drawing.Point(6, 53);
            номерLabel2.Name = "номерLabel2";
            номерLabel2.Size = new System.Drawing.Size(44, 13);
            номерLabel2.TabIndex = 3;
            номерLabel2.Text = "Номер:";
            // 
            // примечаниеLabel5
            // 
            примечаниеLabel5.AutoSize = true;
            примечаниеLabel5.Location = new System.Drawing.Point(6, 79);
            примечаниеLabel5.Name = "примечаниеLabel5";
            примечаниеLabel5.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel5.TabIndex = 5;
            примечаниеLabel5.Text = "Примечание:";
            // 
            // код_сотрудникаLabel3
            // 
            код_сотрудникаLabel3.AutoSize = true;
            код_сотрудникаLabel3.Location = new System.Drawing.Point(6, 27);
            код_сотрудникаLabel3.Name = "код_сотрудникаLabel3";
            код_сотрудникаLabel3.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel3.TabIndex = 1;
            код_сотрудникаLabel3.Text = "Код сотрудника:";
            // 
            // номерLabel3
            // 
            номерLabel3.AutoSize = true;
            номерLabel3.Location = new System.Drawing.Point(6, 53);
            номерLabel3.Name = "номерLabel3";
            номерLabel3.Size = new System.Drawing.Size(44, 13);
            номерLabel3.TabIndex = 3;
            номерLabel3.Text = "Номер:";
            // 
            // день_неделиLabel
            // 
            день_неделиLabel.AutoSize = true;
            день_неделиLabel.Location = new System.Drawing.Point(6, 79);
            день_неделиLabel.Name = "день_неделиLabel";
            день_неделиLabel.Size = new System.Drawing.Size(76, 13);
            день_неделиLabel.TabIndex = 5;
            день_неделиLabel.Text = "День недели:";
            // 
            // время_начала_уборкиLabel
            // 
            время_начала_уборкиLabel.AutoSize = true;
            время_начала_уборкиLabel.Location = new System.Drawing.Point(6, 105);
            время_начала_уборкиLabel.Name = "время_начала_уборкиLabel";
            время_начала_уборкиLabel.Size = new System.Drawing.Size(119, 13);
            время_начала_уборкиLabel.TabIndex = 7;
            время_начала_уборкиLabel.Text = "Время начала уборки:";
            // 
            // длительностьLabel
            // 
            длительностьLabel.AutoSize = true;
            длительностьLabel.Location = new System.Drawing.Point(6, 131);
            длительностьLabel.Name = "длительностьLabel";
            длительностьLabel.Size = new System.Drawing.Size(83, 13);
            длительностьLabel.TabIndex = 9;
            длительностьLabel.Text = "Длительность:";
            // 
            // примечаниеLabel8
            // 
            примечаниеLabel8.AutoSize = true;
            примечаниеLabel8.Location = new System.Drawing.Point(6, 157);
            примечаниеLabel8.Name = "примечаниеLabel8";
            примечаниеLabel8.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel8.TabIndex = 11;
            примечаниеLabel8.Text = "Примечание:";
            // 
            // код_клиентаLabel3
            // 
            код_клиентаLabel3.AutoSize = true;
            код_клиентаLabel3.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel3.Name = "код_клиентаLabel3";
            код_клиентаLabel3.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel3.TabIndex = 20;
            код_клиентаLabel3.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel4
            // 
            код_сотрудникаLabel4.AutoSize = true;
            код_сотрудникаLabel4.Location = new System.Drawing.Point(6, 53);
            код_сотрудникаLabel4.Name = "код_сотрудникаLabel4";
            код_сотрудникаLabel4.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel4.TabIndex = 22;
            код_сотрудникаLabel4.Text = "Код сотрудника:";
            // 
            // номерLabel4
            // 
            номерLabel4.AutoSize = true;
            номерLabel4.Location = new System.Drawing.Point(6, 79);
            номерLabel4.Name = "номерLabel4";
            номерLabel4.Size = new System.Drawing.Size(44, 13);
            номерLabel4.TabIndex = 24;
            номерLabel4.Text = "Номер:";
            // 
            // код_пропускаLabel2
            // 
            код_пропускаLabel2.AutoSize = true;
            код_пропускаLabel2.Location = new System.Drawing.Point(6, 105);
            код_пропускаLabel2.Name = "код_пропускаLabel2";
            код_пропускаLabel2.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel2.TabIndex = 28;
            код_пропускаLabel2.Text = "Код пропуска:";
            // 
            // дата_прибытияLabel1
            // 
            дата_прибытияLabel1.AutoSize = true;
            дата_прибытияLabel1.Location = new System.Drawing.Point(6, 132);
            дата_прибытияLabel1.Name = "дата_прибытияLabel1";
            дата_прибытияLabel1.Size = new System.Drawing.Size(88, 13);
            дата_прибытияLabel1.TabIndex = 30;
            дата_прибытияLabel1.Text = "Дата прибытия:";
            // 
            // дата_отбытияLabel1
            // 
            дата_отбытияLabel1.AutoSize = true;
            дата_отбытияLabel1.Location = new System.Drawing.Point(6, 158);
            дата_отбытияLabel1.Name = "дата_отбытияLabel1";
            дата_отбытияLabel1.Size = new System.Drawing.Size(81, 13);
            дата_отбытияLabel1.TabIndex = 32;
            дата_отбытияLabel1.Text = "Дата отбытия:";
            // 
            // стоимостьLabel3
            // 
            стоимостьLabel3.AutoSize = true;
            стоимостьLabel3.Location = new System.Drawing.Point(6, 183);
            стоимостьLabel3.Name = "стоимостьLabel3";
            стоимостьLabel3.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel3.TabIndex = 34;
            стоимостьLabel3.Text = "Стоимость:";
            // 
            // примечаниеLabel10
            // 
            примечаниеLabel10.AutoSize = true;
            примечаниеLabel10.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel10.Name = "примечаниеLabel10";
            примечаниеLabel10.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel10.TabIndex = 36;
            примечаниеLabel10.Text = "Примечание:";
            // 
            // код_услугиLabel2
            // 
            код_услугиLabel2.AutoSize = true;
            код_услугиLabel2.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel2.Name = "код_услугиLabel2";
            код_услугиLabel2.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel2.TabIndex = 10;
            код_услугиLabel2.Text = "Код услуги:";
            // 
            // наименованиеLabel2
            // 
            наименованиеLabel2.AutoSize = true;
            наименованиеLabel2.Location = new System.Drawing.Point(6, 53);
            наименованиеLabel2.Name = "наименованиеLabel2";
            наименованиеLabel2.Size = new System.Drawing.Size(86, 13);
            наименованиеLabel2.TabIndex = 12;
            наименованиеLabel2.Text = "Наименование:";
            // 
            // стоимостьLabel4
            // 
            стоимостьLabel4.AutoSize = true;
            стоимостьLabel4.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel4.Name = "стоимостьLabel4";
            стоимостьLabel4.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel4.TabIndex = 14;
            стоимостьLabel4.Text = "Стоимость:";
            // 
            // примечаниеLabel11
            // 
            примечаниеLabel11.AutoSize = true;
            примечаниеLabel11.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel11.Name = "примечаниеLabel11";
            примечаниеLabel11.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel11.TabIndex = 16;
            примечаниеLabel11.Text = "Примечание:";
            // 
            // номерLabel5
            // 
            номерLabel5.AutoSize = true;
            номерLabel5.Location = new System.Drawing.Point(6, 27);
            номерLabel5.Name = "номерLabel5";
            номерLabel5.Size = new System.Drawing.Size(44, 13);
            номерLabel5.TabIndex = 10;
            номерLabel5.Text = "Номер:";
            // 
            // вид_номераLabel1
            // 
            вид_номераLabel1.AutoSize = true;
            вид_номераLabel1.Location = new System.Drawing.Point(6, 53);
            вид_номераLabel1.Name = "вид_номераLabel1";
            вид_номераLabel1.Size = new System.Drawing.Size(70, 13);
            вид_номераLabel1.TabIndex = 12;
            вид_номераLabel1.Text = "Вид номера:";
            // 
            // стоимостьLabel5
            // 
            стоимостьLabel5.AutoSize = true;
            стоимостьLabel5.Location = new System.Drawing.Point(6, 79);
            стоимостьLabel5.Name = "стоимостьLabel5";
            стоимостьLabel5.Size = new System.Drawing.Size(65, 13);
            стоимостьLabel5.TabIndex = 14;
            стоимостьLabel5.Text = "Стоимость:";
            // 
            // примечаниеLabel13
            // 
            примечаниеLabel13.AutoSize = true;
            примечаниеLabel13.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel13.Name = "примечаниеLabel13";
            примечаниеLabel13.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel13.TabIndex = 16;
            примечаниеLabel13.Text = "Примечание:";
            // 
            // код_услугиLabel3
            // 
            код_услугиLabel3.AutoSize = true;
            код_услугиLabel3.Location = new System.Drawing.Point(6, 27);
            код_услугиLabel3.Name = "код_услугиLabel3";
            код_услугиLabel3.Size = new System.Drawing.Size(65, 13);
            код_услугиLabel3.TabIndex = 10;
            код_услугиLabel3.Text = "Код услуги:";
            // 
            // код_клиентаLabel5
            // 
            код_клиентаLabel5.AutoSize = true;
            код_клиентаLabel5.Location = new System.Drawing.Point(6, 53);
            код_клиентаLabel5.Name = "код_клиентаLabel5";
            код_клиентаLabel5.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel5.TabIndex = 12;
            код_клиентаLabel5.Text = "Код клиента:";
            // 
            // код_сотрудникаLabel5
            // 
            код_сотрудникаLabel5.AutoSize = true;
            код_сотрудникаLabel5.Location = new System.Drawing.Point(6, 79);
            код_сотрудникаLabel5.Name = "код_сотрудникаLabel5";
            код_сотрудникаLabel5.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel5.TabIndex = 14;
            код_сотрудникаLabel5.Text = "Код сотрудника:";
            // 
            // примечаниеLabel14
            // 
            примечаниеLabel14.AutoSize = true;
            примечаниеLabel14.Location = new System.Drawing.Point(6, 105);
            примечаниеLabel14.Name = "примечаниеLabel14";
            примечаниеLabel14.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel14.TabIndex = 16;
            примечаниеLabel14.Text = "Примечание:";
            // 
            // код_пропускаLabel3
            // 
            код_пропускаLabel3.AutoSize = true;
            код_пропускаLabel3.Location = new System.Drawing.Point(6, 27);
            код_пропускаLabel3.Name = "код_пропускаLabel3";
            код_пропускаLabel3.Size = new System.Drawing.Size(79, 13);
            код_пропускаLabel3.TabIndex = 8;
            код_пропускаLabel3.Text = "Код пропуска:";
            // 
            // номерLabel6
            // 
            номерLabel6.AutoSize = true;
            номерLabel6.Location = new System.Drawing.Point(6, 53);
            номерLabel6.Name = "номерLabel6";
            номерLabel6.Size = new System.Drawing.Size(44, 13);
            номерLabel6.TabIndex = 10;
            номерLabel6.Text = "Номер:";
            // 
            // примечаниеLabel15
            // 
            примечаниеLabel15.AutoSize = true;
            примечаниеLabel15.Location = new System.Drawing.Point(6, 79);
            примечаниеLabel15.Name = "примечаниеLabel15";
            примечаниеLabel15.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel15.TabIndex = 12;
            примечаниеLabel15.Text = "Примечание:";
            // 
            // код_сотрудникаLabel7
            // 
            код_сотрудникаLabel7.AutoSize = true;
            код_сотрудникаLabel7.Location = new System.Drawing.Point(6, 27);
            код_сотрудникаLabel7.Name = "код_сотрудникаLabel7";
            код_сотрудникаLabel7.Size = new System.Drawing.Size(90, 13);
            код_сотрудникаLabel7.TabIndex = 14;
            код_сотрудникаLabel7.Text = "Код сотрудника:";
            // 
            // номерLabel7
            // 
            номерLabel7.AutoSize = true;
            номерLabel7.Location = new System.Drawing.Point(6, 53);
            номерLabel7.Name = "номерLabel7";
            номерLabel7.Size = new System.Drawing.Size(44, 13);
            номерLabel7.TabIndex = 16;
            номерLabel7.Text = "Номер:";
            // 
            // день_неделиLabel1
            // 
            день_неделиLabel1.AutoSize = true;
            день_неделиLabel1.Location = new System.Drawing.Point(6, 79);
            день_неделиLabel1.Name = "день_неделиLabel1";
            день_неделиLabel1.Size = new System.Drawing.Size(76, 13);
            день_неделиLabel1.TabIndex = 18;
            день_неделиLabel1.Text = "День недели:";
            // 
            // время_начала_уборкиLabel1
            // 
            время_начала_уборкиLabel1.AutoSize = true;
            время_начала_уборкиLabel1.Location = new System.Drawing.Point(6, 105);
            время_начала_уборкиLabel1.Name = "время_начала_уборкиLabel1";
            время_начала_уборкиLabel1.Size = new System.Drawing.Size(119, 13);
            время_начала_уборкиLabel1.TabIndex = 20;
            время_начала_уборкиLabel1.Text = "Время начала уборки:";
            // 
            // длительностьLabel1
            // 
            длительностьLabel1.AutoSize = true;
            длительностьLabel1.Location = new System.Drawing.Point(6, 131);
            длительностьLabel1.Name = "длительностьLabel1";
            длительностьLabel1.Size = new System.Drawing.Size(83, 13);
            длительностьLabel1.TabIndex = 22;
            длительностьLabel1.Text = "Длительность:";
            // 
            // примечаниеLabel18
            // 
            примечаниеLabel18.AutoSize = true;
            примечаниеLabel18.Location = new System.Drawing.Point(6, 157);
            примечаниеLabel18.Name = "примечаниеLabel18";
            примечаниеLabel18.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel18.TabIndex = 24;
            примечаниеLabel18.Text = "Примечание:";
            // 
            // код_клиентаLabel4
            // 
            код_клиентаLabel4.AutoSize = true;
            код_клиентаLabel4.Location = new System.Drawing.Point(6, 27);
            код_клиентаLabel4.Name = "код_клиентаLabel4";
            код_клиентаLabel4.Size = new System.Drawing.Size(73, 13);
            код_клиентаLabel4.TabIndex = 0;
            код_клиентаLabel4.Text = "Код клиента:";
            // 
            // фИОLabel3
            // 
            фИОLabel3.AutoSize = true;
            фИОLabel3.Location = new System.Drawing.Point(6, 53);
            фИОLabel3.Name = "фИОLabel3";
            фИОLabel3.Size = new System.Drawing.Size(37, 13);
            фИОLabel3.TabIndex = 2;
            фИОLabel3.Text = "ФИО:";
            // 
            // полLabel2
            // 
            полLabel2.AutoSize = true;
            полLabel2.Location = new System.Drawing.Point(6, 79);
            полLabel2.Name = "полLabel2";
            полLabel2.Size = new System.Drawing.Size(30, 13);
            полLabel2.TabIndex = 4;
            полLabel2.Text = "Пол:";
            // 
            // дата_рожденияLabel2
            // 
            дата_рожденияLabel2.AutoSize = true;
            дата_рожденияLabel2.Location = new System.Drawing.Point(6, 106);
            дата_рожденияLabel2.Name = "дата_рожденияLabel2";
            дата_рожденияLabel2.Size = new System.Drawing.Size(89, 13);
            дата_рожденияLabel2.TabIndex = 6;
            дата_рожденияLabel2.Text = "Дата рождения:";
            // 
            // адресLabel2
            // 
            адресLabel2.AutoSize = true;
            адресLabel2.Location = new System.Drawing.Point(6, 131);
            адресLabel2.Name = "адресLabel2";
            адресLabel2.Size = new System.Drawing.Size(41, 13);
            адресLabel2.TabIndex = 8;
            адресLabel2.Text = "Адрес:";
            // 
            // телефонLabel3
            // 
            телефонLabel3.AutoSize = true;
            телефонLabel3.Location = new System.Drawing.Point(6, 157);
            телефонLabel3.Name = "телефонLabel3";
            телефонLabel3.Size = new System.Drawing.Size(55, 13);
            телефонLabel3.TabIndex = 10;
            телефонLabel3.Text = "Телефон:";
            // 
            // паспортLabel2
            // 
            паспортLabel2.AutoSize = true;
            паспортLabel2.Location = new System.Drawing.Point(6, 183);
            паспортLabel2.Name = "паспортLabel2";
            паспортLabel2.Size = new System.Drawing.Size(53, 13);
            паспортLabel2.TabIndex = 12;
            паспортLabel2.Text = "Паспорт:";
            // 
            // примечаниеLabel12
            // 
            примечаниеLabel12.AutoSize = true;
            примечаниеLabel12.Location = new System.Drawing.Point(6, 209);
            примечаниеLabel12.Name = "примечаниеLabel12";
            примечаниеLabel12.Size = new System.Drawing.Size(73, 13);
            примечаниеLabel12.TabIndex = 14;
            примечаниеLabel12.Text = "Примечание:";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Controls.Add(this.tabPage9);
            this.tabControl1.Location = new System.Drawing.Point(4, 30);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(963, 554);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.AutoScroll = true;
            this.tabPage1.Controls.Add(this.button_data1);
            this.tabPage1.Controls.Add(this.groupBox2);
            this.tabPage1.Controls.Add(this.groupBox1);
            this.tabPage1.Controls.Add(this.броньDataGridView);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(955, 528);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Бронь";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // button_data1
            // 
            this.button_data1.Location = new System.Drawing.Point(535, 28);
            this.button_data1.Name = "button_data1";
            this.button_data1.Size = new System.Drawing.Size(95, 23);
            this.button_data1.TabIndex = 38;
            this.button_data1.Text = "<<Перенести<<";
            this.button_data1.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(код_клиентаLabel3);
            this.groupBox2.Controls.Add(this.примечаниеTextBox10);
            this.groupBox2.Controls.Add(this.код_клиентаTextBox3);
            this.groupBox2.Controls.Add(примечаниеLabel10);
            this.groupBox2.Controls.Add(код_сотрудникаLabel4);
            this.groupBox2.Controls.Add(this.стоимостьTextBox3);
            this.groupBox2.Controls.Add(this.код_сотрудникаTextBox4);
            this.groupBox2.Controls.Add(стоимостьLabel3);
            this.groupBox2.Controls.Add(номерLabel4);
            this.groupBox2.Controls.Add(this.дата_отбытияDateTimePicker1);
            this.groupBox2.Controls.Add(this.номерTextBox4);
            this.groupBox2.Controls.Add(дата_отбытияLabel1);
            this.groupBox2.Controls.Add(this.дата_прибытияDateTimePicker1);
            this.groupBox2.Controls.Add(дата_прибытияLabel1);
            this.groupBox2.Controls.Add(код_пропускаLabel2);
            this.groupBox2.Controls.Add(this.код_пропускаTextBox2);
            this.groupBox2.Location = new System.Drawing.Point(636, 6);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(313, 266);
            this.groupBox2.TabIndex = 39;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox10
            // 
            this.примечаниеTextBox10.Location = new System.Drawing.Point(102, 206);
            this.примечаниеTextBox10.Name = "примечаниеTextBox10";
            this.примечаниеTextBox10.ReadOnly = true;
            this.примечаниеTextBox10.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox10.TabIndex = 37;
            // 
            // код_клиентаTextBox3
            // 
            this.код_клиентаTextBox3.Location = new System.Drawing.Point(102, 24);
            this.код_клиентаTextBox3.Name = "код_клиентаTextBox3";
            this.код_клиентаTextBox3.ReadOnly = true;
            this.код_клиентаTextBox3.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox3.TabIndex = 21;
            // 
            // стоимостьTextBox3
            // 
            this.стоимостьTextBox3.Location = new System.Drawing.Point(102, 180);
            this.стоимостьTextBox3.Name = "стоимостьTextBox3";
            this.стоимостьTextBox3.ReadOnly = true;
            this.стоимостьTextBox3.Size = new System.Drawing.Size(200, 20);
            this.стоимостьTextBox3.TabIndex = 35;
            // 
            // код_сотрудникаTextBox4
            // 
            this.код_сотрудникаTextBox4.Location = new System.Drawing.Point(102, 50);
            this.код_сотрудникаTextBox4.Name = "код_сотрудникаTextBox4";
            this.код_сотрудникаTextBox4.ReadOnly = true;
            this.код_сотрудникаTextBox4.Size = new System.Drawing.Size(200, 20);
            this.код_сотрудникаTextBox4.TabIndex = 23;
            // 
            // дата_отбытияDateTimePicker1
            // 
            this.дата_отбытияDateTimePicker1.Location = new System.Drawing.Point(102, 154);
            this.дата_отбытияDateTimePicker1.Name = "дата_отбытияDateTimePicker1";
            this.дата_отбытияDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.дата_отбытияDateTimePicker1.TabIndex = 33;
            // 
            // номерTextBox4
            // 
            this.номерTextBox4.Location = new System.Drawing.Point(102, 76);
            this.номерTextBox4.Name = "номерTextBox4";
            this.номерTextBox4.ReadOnly = true;
            this.номерTextBox4.Size = new System.Drawing.Size(200, 20);
            this.номерTextBox4.TabIndex = 25;
            // 
            // дата_прибытияDateTimePicker1
            // 
            this.дата_прибытияDateTimePicker1.Location = new System.Drawing.Point(102, 128);
            this.дата_прибытияDateTimePicker1.Name = "дата_прибытияDateTimePicker1";
            this.дата_прибытияDateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.дата_прибытияDateTimePicker1.TabIndex = 31;
            // 
            // код_пропускаTextBox2
            // 
            this.код_пропускаTextBox2.Location = new System.Drawing.Point(102, 102);
            this.код_пропускаTextBox2.Name = "код_пропускаTextBox2";
            this.код_пропускаTextBox2.ReadOnly = true;
            this.код_пропускаTextBox2.Size = new System.Drawing.Size(200, 20);
            this.код_пропускаTextBox2.TabIndex = 29;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.button13);
            this.groupBox1.Controls.Add(this.button12);
            this.groupBox1.Controls.Add(код_клиентаLabel);
            this.groupBox1.Controls.Add(this.примечаниеTextBox);
            this.groupBox1.Controls.Add(примечаниеLabel);
            this.groupBox1.Controls.Add(this.стоимостьTextBox);
            this.groupBox1.Controls.Add(стоимостьLabel);
            this.groupBox1.Controls.Add(this.дата_отбытияDateTimePicker);
            this.groupBox1.Controls.Add(дата_отбытияLabel);
            this.groupBox1.Controls.Add(this.дата_прибытияDateTimePicker);
            this.groupBox1.Controls.Add(дата_прибытияLabel);
            this.groupBox1.Controls.Add(this.код_пропускаTextBox);
            this.groupBox1.Controls.Add(код_пропускаLabel);
            this.groupBox1.Controls.Add(this.номерTextBox);
            this.groupBox1.Controls.Add(номерLabel);
            this.groupBox1.Controls.Add(this.код_сотрудникаTextBox);
            this.groupBox1.Controls.Add(код_сотрудникаLabel);
            this.groupBox1.Controls.Add(this.код_клиентаTextBox);
            this.groupBox1.Controls.Add(this.button1);
            this.groupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.groupBox1.Location = new System.Drawing.Point(6, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(448, 266);
            this.groupBox1.TabIndex = 38;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Окно ввода данных";
            // 
            // button13
            // 
            this.button13.Location = new System.Drawing.Point(322, 85);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(120, 23);
            this.button13.TabIndex = 21;
            this.button13.Text = "Удалить строку";
            this.button13.UseVisualStyleBackColor = true;
            this.button13.Click += new System.EventHandler(this.delete_line);
            // 
            // button12
            // 
            this.button12.Location = new System.Drawing.Point(322, 56);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(120, 23);
            this.button12.TabIndex = 20;
            this.button12.Text = "Изменить строку";
            this.button12.UseVisualStyleBackColor = true;
            this.button12.Click += new System.EventHandler(this.update_line);
            // 
            // примечаниеTextBox
            // 
            this.примечаниеTextBox.Location = new System.Drawing.Point(102, 206);
            this.примечаниеTextBox.Name = "примечаниеTextBox";
            this.примечаниеTextBox.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox.TabIndex = 18;
            // 
            // стоимостьTextBox
            // 
            this.стоимостьTextBox.Location = new System.Drawing.Point(102, 180);
            this.стоимостьTextBox.Name = "стоимостьTextBox";
            this.стоимостьTextBox.Size = new System.Drawing.Size(200, 20);
            this.стоимостьTextBox.TabIndex = 16;
            // 
            // дата_отбытияDateTimePicker
            // 
            this.дата_отбытияDateTimePicker.Location = new System.Drawing.Point(102, 154);
            this.дата_отбытияDateTimePicker.Name = "дата_отбытияDateTimePicker";
            this.дата_отбытияDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_отбытияDateTimePicker.TabIndex = 14;
            // 
            // дата_прибытияDateTimePicker
            // 
            this.дата_прибытияDateTimePicker.Location = new System.Drawing.Point(102, 128);
            this.дата_прибытияDateTimePicker.Name = "дата_прибытияDateTimePicker";
            this.дата_прибытияDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_прибытияDateTimePicker.TabIndex = 12;
            // 
            // код_пропускаTextBox
            // 
            this.код_пропускаTextBox.Location = new System.Drawing.Point(102, 102);
            this.код_пропускаTextBox.Name = "код_пропускаTextBox";
            this.код_пропускаTextBox.Size = new System.Drawing.Size(200, 20);
            this.код_пропускаTextBox.TabIndex = 10;
            // 
            // номерTextBox
            // 
            this.номерTextBox.Location = new System.Drawing.Point(102, 76);
            this.номерTextBox.Name = "номерTextBox";
            this.номерTextBox.Size = new System.Drawing.Size(200, 20);
            this.номерTextBox.TabIndex = 6;
            // 
            // код_сотрудникаTextBox
            // 
            this.код_сотрудникаTextBox.Location = new System.Drawing.Point(102, 50);
            this.код_сотрудникаTextBox.Name = "код_сотрудникаTextBox";
            this.код_сотрудникаTextBox.Size = new System.Drawing.Size(200, 20);
            this.код_сотрудникаTextBox.TabIndex = 4;
            // 
            // код_клиентаTextBox
            // 
            this.код_клиентаTextBox.Location = new System.Drawing.Point(102, 24);
            this.код_клиентаTextBox.Name = "код_клиентаTextBox";
            this.код_клиентаTextBox.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox.TabIndex = 2;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(322, 27);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(120, 23);
            this.button1.TabIndex = 19;
            this.button1.Text = "Добавить строку";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.insert_line);
            // 
            // броньDataGridView
            // 
            this.броньDataGridView.AutoGenerateColumns = false;
            this.броньDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.броньDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.dataGridViewTextBoxColumn2,
            this.dataGridViewTextBoxColumn3,
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewTextBoxColumn9});
            this.броньDataGridView.DataSource = this.броньBindingSource;
            this.броньDataGridView.Location = new System.Drawing.Point(3, 278);
            this.броньDataGridView.Name = "броньDataGridView";
            this.броньDataGridView.Size = new System.Drawing.Size(949, 246);
            this.броньDataGridView.TabIndex = 0;
            this.броньDataGridView.SelectionChanged += new System.EventHandler(this.броньDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "Код клиента";
            this.dataGridViewTextBoxColumn1.HeaderText = "Код клиента";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn2.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn3.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.DataPropertyName = "Код пропуска";
            this.dataGridViewTextBoxColumn5.HeaderText = "Код пропуска";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.DataPropertyName = "Дата прибытия";
            this.dataGridViewTextBoxColumn6.HeaderText = "Дата прибытия";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.DataPropertyName = "Дата отбытия";
            this.dataGridViewTextBoxColumn7.HeaderText = "Дата отбытия";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn8.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn9.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            // 
            // броньBindingSource
            // 
            this.броньBindingSource.DataMember = "Бронь";
            this.броньBindingSource.DataSource = this.hotelDataSet;
            // 
            // hotelDataSet
            // 
            this.hotelDataSet.DataSetName = "HotelDataSet";
            this.hotelDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // tabPage2
            // 
            this.tabPage2.AutoScroll = true;
            this.tabPage2.Controls.Add(this.button_data2);
            this.tabPage2.Controls.Add(this.groupBox4);
            this.tabPage2.Controls.Add(this.groupBox3);
            this.tabPage2.Controls.Add(this.доп_услугиDataGridView);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(955, 528);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "tabPage2";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // button_data2
            // 
            this.button_data2.Location = new System.Drawing.Point(607, 28);
            this.button_data2.Name = "button_data2";
            this.button_data2.Size = new System.Drawing.Size(95, 23);
            this.button_data2.TabIndex = 39;
            this.button_data2.Text = "<<Перенести<<";
            this.button_data2.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(код_услугиLabel2);
            this.groupBox4.Controls.Add(this.примечаниеTextBox11);
            this.groupBox4.Controls.Add(this.код_услугиTextBox2);
            this.groupBox4.Controls.Add(примечаниеLabel11);
            this.groupBox4.Controls.Add(this.стоимостьTextBox4);
            this.groupBox4.Controls.Add(наименованиеLabel2);
            this.groupBox4.Controls.Add(стоимостьLabel4);
            this.groupBox4.Controls.Add(this.наименованиеTextBox2);
            this.groupBox4.Location = new System.Drawing.Point(708, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(241, 266);
            this.groupBox4.TabIndex = 25;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox11
            // 
            this.примечаниеTextBox11.Location = new System.Drawing.Point(98, 102);
            this.примечаниеTextBox11.Name = "примечаниеTextBox11";
            this.примечаниеTextBox11.ReadOnly = true;
            this.примечаниеTextBox11.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox11.TabIndex = 17;
            // 
            // код_услугиTextBox2
            // 
            this.код_услугиTextBox2.Location = new System.Drawing.Point(98, 24);
            this.код_услугиTextBox2.Name = "код_услугиTextBox2";
            this.код_услугиTextBox2.ReadOnly = true;
            this.код_услугиTextBox2.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox2.TabIndex = 11;
            // 
            // стоимостьTextBox4
            // 
            this.стоимостьTextBox4.Location = new System.Drawing.Point(98, 76);
            this.стоимостьTextBox4.Name = "стоимостьTextBox4";
            this.стоимостьTextBox4.ReadOnly = true;
            this.стоимостьTextBox4.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox4.TabIndex = 15;
            // 
            // наименованиеTextBox2
            // 
            this.наименованиеTextBox2.Location = new System.Drawing.Point(98, 50);
            this.наименованиеTextBox2.Name = "наименованиеTextBox2";
            this.наименованиеTextBox2.ReadOnly = true;
            this.наименованиеTextBox2.Size = new System.Drawing.Size(126, 20);
            this.наименованиеTextBox2.TabIndex = 13;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(код_услугиLabel);
            this.groupBox3.Controls.Add(this.button14);
            this.groupBox3.Controls.Add(this.button15);
            this.groupBox3.Controls.Add(this.примечаниеTextBox1);
            this.groupBox3.Controls.Add(примечаниеLabel1);
            this.groupBox3.Controls.Add(this.стоимостьTextBox1);
            this.groupBox3.Controls.Add(стоимостьLabel1);
            this.groupBox3.Controls.Add(this.наименованиеTextBox);
            this.groupBox3.Controls.Add(наименованиеLabel);
            this.groupBox3.Controls.Add(this.код_услугиTextBox);
            this.groupBox3.Controls.Add(this.button2);
            this.groupBox3.Location = new System.Drawing.Point(6, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(394, 266);
            this.groupBox3.TabIndex = 24;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "Окно ввода данных";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(265, 85);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(120, 23);
            this.button14.TabIndex = 23;
            this.button14.Text = "Удалить строку";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.delete_line);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(265, 56);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(120, 23);
            this.button15.TabIndex = 22;
            this.button15.Text = "Изменить строку";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.update_line);
            // 
            // примечаниеTextBox1
            // 
            this.примечаниеTextBox1.Location = new System.Drawing.Point(98, 102);
            this.примечаниеTextBox1.Name = "примечаниеTextBox1";
            this.примечаниеTextBox1.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox1.TabIndex = 8;
            // 
            // стоимостьTextBox1
            // 
            this.стоимостьTextBox1.Location = new System.Drawing.Point(98, 76);
            this.стоимостьTextBox1.Name = "стоимостьTextBox1";
            this.стоимостьTextBox1.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox1.TabIndex = 6;
            // 
            // наименованиеTextBox
            // 
            this.наименованиеTextBox.Location = new System.Drawing.Point(98, 50);
            this.наименованиеTextBox.Name = "наименованиеTextBox";
            this.наименованиеTextBox.Size = new System.Drawing.Size(126, 20);
            this.наименованиеTextBox.TabIndex = 4;
            // 
            // код_услугиTextBox
            // 
            this.код_услугиTextBox.Location = new System.Drawing.Point(98, 24);
            this.код_услугиTextBox.Name = "код_услугиTextBox";
            this.код_услугиTextBox.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox.TabIndex = 2;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(265, 27);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(120, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "Добавить строку";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.insert_line);
            // 
            // доп_услугиDataGridView
            // 
            this.доп_услугиDataGridView.AutoGenerateColumns = false;
            this.доп_услугиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.доп_услугиDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn10,
            this.dataGridViewTextBoxColumn11,
            this.dataGridViewTextBoxColumn12,
            this.dataGridViewTextBoxColumn13});
            this.доп_услугиDataGridView.DataSource = this.доп_услугиBindingSource;
            this.доп_услугиDataGridView.Location = new System.Drawing.Point(3, 278);
            this.доп_услугиDataGridView.Name = "доп_услугиDataGridView";
            this.доп_услугиDataGridView.Size = new System.Drawing.Size(949, 246);
            this.доп_услугиDataGridView.TabIndex = 0;
            this.доп_услугиDataGridView.SelectionChanged += new System.EventHandler(this.доп_услугиDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "Код услуги";
            this.dataGridViewTextBoxColumn10.HeaderText = "Код услуги";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "Наименование";
            this.dataGridViewTextBoxColumn11.HeaderText = "Наименование";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn12.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn13.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            // 
            // доп_услугиBindingSource
            // 
            this.доп_услугиBindingSource.DataMember = "Доп_услуги";
            this.доп_услугиBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage3
            // 
            this.tabPage3.AutoScroll = true;
            this.tabPage3.Controls.Add(this.button_data3);
            this.tabPage3.Controls.Add(this.клиентDataGridView);
            this.tabPage3.Controls.Add(this.groupBox6);
            this.tabPage3.Controls.Add(this.groupBox5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(955, 528);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "tabPage3";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // button_data3
            // 
            this.button_data3.Location = new System.Drawing.Point(535, 28);
            this.button_data3.Name = "button_data3";
            this.button_data3.Size = new System.Drawing.Size(95, 23);
            this.button_data3.TabIndex = 39;
            this.button_data3.Text = "<<Перенести<<";
            this.button_data3.UseVisualStyleBackColor = true;
            // 
            // клиентDataGridView
            // 
            this.клиентDataGridView.AutoGenerateColumns = false;
            this.клиентDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.клиентDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn47,
            this.dataGridViewTextBoxColumn48,
            this.dataGridViewTextBoxColumn49,
            this.dataGridViewTextBoxColumn50,
            this.dataGridViewTextBoxColumn51,
            this.dataGridViewTextBoxColumn75,
            this.dataGridViewTextBoxColumn76,
            this.dataGridViewTextBoxColumn77});
            this.клиентDataGridView.DataSource = this.клиентBindingSource;
            this.клиентDataGridView.Location = new System.Drawing.Point(3, 278);
            this.клиентDataGridView.Name = "клиентDataGridView";
            this.клиентDataGridView.Size = new System.Drawing.Size(949, 246);
            this.клиентDataGridView.TabIndex = 37;
            this.клиентDataGridView.SelectionChanged += new System.EventHandler(this.клиентDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn47
            // 
            this.dataGridViewTextBoxColumn47.DataPropertyName = "Код_клиента";
            this.dataGridViewTextBoxColumn47.HeaderText = "Код_клиента";
            this.dataGridViewTextBoxColumn47.Name = "dataGridViewTextBoxColumn47";
            // 
            // dataGridViewTextBoxColumn48
            // 
            this.dataGridViewTextBoxColumn48.DataPropertyName = "ФИО";
            this.dataGridViewTextBoxColumn48.HeaderText = "ФИО";
            this.dataGridViewTextBoxColumn48.Name = "dataGridViewTextBoxColumn48";
            // 
            // dataGridViewTextBoxColumn49
            // 
            this.dataGridViewTextBoxColumn49.DataPropertyName = "Пол";
            this.dataGridViewTextBoxColumn49.HeaderText = "Пол";
            this.dataGridViewTextBoxColumn49.Name = "dataGridViewTextBoxColumn49";
            // 
            // dataGridViewTextBoxColumn50
            // 
            this.dataGridViewTextBoxColumn50.DataPropertyName = "Дата рождения";
            this.dataGridViewTextBoxColumn50.HeaderText = "Дата рождения";
            this.dataGridViewTextBoxColumn50.Name = "dataGridViewTextBoxColumn50";
            // 
            // dataGridViewTextBoxColumn51
            // 
            this.dataGridViewTextBoxColumn51.DataPropertyName = "Адрес";
            this.dataGridViewTextBoxColumn51.HeaderText = "Адрес";
            this.dataGridViewTextBoxColumn51.Name = "dataGridViewTextBoxColumn51";
            // 
            // dataGridViewTextBoxColumn75
            // 
            this.dataGridViewTextBoxColumn75.DataPropertyName = "Телефон";
            this.dataGridViewTextBoxColumn75.HeaderText = "Телефон";
            this.dataGridViewTextBoxColumn75.Name = "dataGridViewTextBoxColumn75";
            // 
            // dataGridViewTextBoxColumn76
            // 
            this.dataGridViewTextBoxColumn76.DataPropertyName = "Паспорт";
            this.dataGridViewTextBoxColumn76.HeaderText = "Паспорт";
            this.dataGridViewTextBoxColumn76.Name = "dataGridViewTextBoxColumn76";
            // 
            // dataGridViewTextBoxColumn77
            // 
            this.dataGridViewTextBoxColumn77.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn77.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn77.Name = "dataGridViewTextBoxColumn77";
            // 
            // клиентBindingSource
            // 
            this.клиентBindingSource.DataMember = "Клиент";
            this.клиентBindingSource.DataSource = this.hotelDataSet;
            // 
            // groupBox6
            // 
            this.groupBox6.Controls.Add(код_клиентаLabel4);
            this.groupBox6.Controls.Add(this.код_клиентаTextBox4);
            this.groupBox6.Controls.Add(фИОLabel3);
            this.groupBox6.Controls.Add(this.фИОTextBox3);
            this.groupBox6.Controls.Add(полLabel2);
            this.groupBox6.Controls.Add(this.полTextBox2);
            this.groupBox6.Controls.Add(дата_рожденияLabel2);
            this.groupBox6.Controls.Add(this.дата_рожденияDateTimePicker2);
            this.groupBox6.Controls.Add(адресLabel2);
            this.groupBox6.Controls.Add(this.адресTextBox2);
            this.groupBox6.Controls.Add(телефонLabel3);
            this.groupBox6.Controls.Add(this.телефонTextBox3);
            this.groupBox6.Controls.Add(паспортLabel2);
            this.groupBox6.Controls.Add(this.паспортTextBox2);
            this.groupBox6.Controls.Add(примечаниеLabel12);
            this.groupBox6.Controls.Add(this.примечаниеTextBox12);
            this.groupBox6.Location = new System.Drawing.Point(636, 6);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(313, 266);
            this.groupBox6.TabIndex = 37;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "Окно вывода данных";
            // 
            // код_клиентаTextBox4
            // 
            this.код_клиентаTextBox4.Location = new System.Drawing.Point(101, 24);
            this.код_клиентаTextBox4.Name = "код_клиентаTextBox4";
            this.код_клиентаTextBox4.ReadOnly = true;
            this.код_клиентаTextBox4.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox4.TabIndex = 1;
            // 
            // фИОTextBox3
            // 
            this.фИОTextBox3.Location = new System.Drawing.Point(101, 50);
            this.фИОTextBox3.Name = "фИОTextBox3";
            this.фИОTextBox3.ReadOnly = true;
            this.фИОTextBox3.Size = new System.Drawing.Size(200, 20);
            this.фИОTextBox3.TabIndex = 3;
            // 
            // полTextBox2
            // 
            this.полTextBox2.Location = new System.Drawing.Point(101, 76);
            this.полTextBox2.Name = "полTextBox2";
            this.полTextBox2.ReadOnly = true;
            this.полTextBox2.Size = new System.Drawing.Size(200, 20);
            this.полTextBox2.TabIndex = 5;
            // 
            // дата_рожденияDateTimePicker2
            // 
            this.дата_рожденияDateTimePicker2.Location = new System.Drawing.Point(101, 102);
            this.дата_рожденияDateTimePicker2.Name = "дата_рожденияDateTimePicker2";
            this.дата_рожденияDateTimePicker2.Size = new System.Drawing.Size(200, 20);
            this.дата_рожденияDateTimePicker2.TabIndex = 7;
            // 
            // адресTextBox2
            // 
            this.адресTextBox2.Location = new System.Drawing.Point(101, 128);
            this.адресTextBox2.Name = "адресTextBox2";
            this.адресTextBox2.ReadOnly = true;
            this.адресTextBox2.Size = new System.Drawing.Size(200, 20);
            this.адресTextBox2.TabIndex = 9;
            // 
            // телефонTextBox3
            // 
            this.телефонTextBox3.Location = new System.Drawing.Point(101, 154);
            this.телефонTextBox3.Name = "телефонTextBox3";
            this.телефонTextBox3.ReadOnly = true;
            this.телефонTextBox3.Size = new System.Drawing.Size(200, 20);
            this.телефонTextBox3.TabIndex = 11;
            // 
            // паспортTextBox2
            // 
            this.паспортTextBox2.Location = new System.Drawing.Point(101, 180);
            this.паспортTextBox2.Name = "паспортTextBox2";
            this.паспортTextBox2.ReadOnly = true;
            this.паспортTextBox2.Size = new System.Drawing.Size(200, 20);
            this.паспортTextBox2.TabIndex = 13;
            // 
            // примечаниеTextBox12
            // 
            this.примечаниеTextBox12.Location = new System.Drawing.Point(101, 206);
            this.примечаниеTextBox12.Name = "примечаниеTextBox12";
            this.примечаниеTextBox12.ReadOnly = true;
            this.примечаниеTextBox12.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox12.TabIndex = 15;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(код_клиентаLabel1);
            this.groupBox5.Controls.Add(this.примечаниеTextBox2);
            this.groupBox5.Controls.Add(this.button16);
            this.groupBox5.Controls.Add(примечаниеLabel2);
            this.groupBox5.Controls.Add(this.паспортTextBox);
            this.groupBox5.Controls.Add(this.button17);
            this.groupBox5.Controls.Add(паспортLabel);
            this.groupBox5.Controls.Add(this.телефонTextBox);
            this.groupBox5.Controls.Add(телефонLabel);
            this.groupBox5.Controls.Add(this.адресTextBox);
            this.groupBox5.Controls.Add(адресLabel);
            this.groupBox5.Controls.Add(this.дата_рожденияDateTimePicker);
            this.groupBox5.Controls.Add(дата_рожденияLabel);
            this.groupBox5.Controls.Add(this.полTextBox);
            this.groupBox5.Controls.Add(полLabel);
            this.groupBox5.Controls.Add(this.фИОTextBox);
            this.groupBox5.Controls.Add(фИОLabel);
            this.groupBox5.Controls.Add(this.код_клиентаTextBox1);
            this.groupBox5.Controls.Add(this.button3);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(451, 266);
            this.groupBox5.TabIndex = 36;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox2
            // 
            this.примечаниеTextBox2.Location = new System.Drawing.Point(101, 206);
            this.примечаниеTextBox2.Name = "примечаниеTextBox2";
            this.примечаниеTextBox2.Size = new System.Drawing.Size(200, 20);
            this.примечаниеTextBox2.TabIndex = 16;
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(322, 85);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(120, 23);
            this.button16.TabIndex = 35;
            this.button16.Text = "Удалить строку";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.delete_line);
            // 
            // паспортTextBox
            // 
            this.паспортTextBox.Location = new System.Drawing.Point(101, 180);
            this.паспортTextBox.Name = "паспортTextBox";
            this.паспортTextBox.Size = new System.Drawing.Size(200, 20);
            this.паспортTextBox.TabIndex = 14;
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(322, 56);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(120, 23);
            this.button17.TabIndex = 34;
            this.button17.Text = "Изменить строку";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.update_line);
            // 
            // телефонTextBox
            // 
            this.телефонTextBox.Location = new System.Drawing.Point(101, 154);
            this.телефонTextBox.Name = "телефонTextBox";
            this.телефонTextBox.Size = new System.Drawing.Size(200, 20);
            this.телефонTextBox.TabIndex = 12;
            // 
            // адресTextBox
            // 
            this.адресTextBox.Location = new System.Drawing.Point(101, 128);
            this.адресTextBox.Name = "адресTextBox";
            this.адресTextBox.Size = new System.Drawing.Size(200, 20);
            this.адресTextBox.TabIndex = 10;
            // 
            // дата_рожденияDateTimePicker
            // 
            this.дата_рожденияDateTimePicker.Location = new System.Drawing.Point(101, 102);
            this.дата_рожденияDateTimePicker.Name = "дата_рожденияDateTimePicker";
            this.дата_рожденияDateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.дата_рожденияDateTimePicker.TabIndex = 8;
            // 
            // полTextBox
            // 
            this.полTextBox.Location = new System.Drawing.Point(101, 76);
            this.полTextBox.Name = "полTextBox";
            this.полTextBox.Size = new System.Drawing.Size(200, 20);
            this.полTextBox.TabIndex = 6;
            // 
            // фИОTextBox
            // 
            this.фИОTextBox.Location = new System.Drawing.Point(101, 50);
            this.фИОTextBox.Name = "фИОTextBox";
            this.фИОTextBox.Size = new System.Drawing.Size(200, 20);
            this.фИОTextBox.TabIndex = 4;
            // 
            // код_клиентаTextBox1
            // 
            this.код_клиентаTextBox1.Location = new System.Drawing.Point(101, 24);
            this.код_клиентаTextBox1.Name = "код_клиентаTextBox1";
            this.код_клиентаTextBox1.Size = new System.Drawing.Size(200, 20);
            this.код_клиентаTextBox1.TabIndex = 2;
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(322, 27);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(120, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "Добавить строку";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.insert_line);
            // 
            // tabPage4
            // 
            this.tabPage4.AutoScroll = true;
            this.tabPage4.Controls.Add(this.button_data4);
            this.tabPage4.Controls.Add(this.groupBox7);
            this.tabPage4.Controls.Add(this.groupBox8);
            this.tabPage4.Controls.Add(this.номераDataGridView);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(955, 528);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "tabPage4";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // button_data4
            // 
            this.button_data4.Location = new System.Drawing.Point(627, 28);
            this.button_data4.Name = "button_data4";
            this.button_data4.Size = new System.Drawing.Size(95, 23);
            this.button_data4.TabIndex = 40;
            this.button_data4.Text = "<<Перенести<<";
            this.button_data4.UseVisualStyleBackColor = true;
            // 
            // groupBox7
            // 
            this.groupBox7.Controls.Add(номерLabel5);
            this.groupBox7.Controls.Add(this.примечаниеTextBox13);
            this.groupBox7.Controls.Add(примечаниеLabel13);
            this.groupBox7.Controls.Add(this.стоимостьTextBox5);
            this.groupBox7.Controls.Add(стоимостьLabel5);
            this.groupBox7.Controls.Add(this.номерTextBox5);
            this.groupBox7.Controls.Add(this.вид_номераTextBox1);
            this.groupBox7.Controls.Add(вид_номераLabel1);
            this.groupBox7.Location = new System.Drawing.Point(728, 6);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(221, 266);
            this.groupBox7.TabIndex = 39;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox13
            // 
            this.примечаниеTextBox13.Location = new System.Drawing.Point(85, 102);
            this.примечаниеTextBox13.Name = "примечаниеTextBox13";
            this.примечаниеTextBox13.ReadOnly = true;
            this.примечаниеTextBox13.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox13.TabIndex = 17;
            // 
            // стоимостьTextBox5
            // 
            this.стоимостьTextBox5.Location = new System.Drawing.Point(85, 76);
            this.стоимостьTextBox5.Name = "стоимостьTextBox5";
            this.стоимостьTextBox5.ReadOnly = true;
            this.стоимостьTextBox5.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox5.TabIndex = 15;
            // 
            // номерTextBox5
            // 
            this.номерTextBox5.Location = new System.Drawing.Point(85, 24);
            this.номерTextBox5.Name = "номерTextBox5";
            this.номерTextBox5.ReadOnly = true;
            this.номерTextBox5.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox5.TabIndex = 11;
            // 
            // вид_номераTextBox1
            // 
            this.вид_номераTextBox1.Location = new System.Drawing.Point(85, 50);
            this.вид_номераTextBox1.Name = "вид_номераTextBox1";
            this.вид_номераTextBox1.ReadOnly = true;
            this.вид_номераTextBox1.Size = new System.Drawing.Size(126, 20);
            this.вид_номераTextBox1.TabIndex = 13;
            // 
            // groupBox8
            // 
            this.groupBox8.Controls.Add(номерLabel1);
            this.groupBox8.Controls.Add(this.примечаниеTextBox3);
            this.groupBox8.Controls.Add(this.button18);
            this.groupBox8.Controls.Add(примечаниеLabel3);
            this.groupBox8.Controls.Add(this.button19);
            this.groupBox8.Controls.Add(this.button4);
            this.groupBox8.Controls.Add(this.стоимостьTextBox2);
            this.groupBox8.Controls.Add(стоимостьLabel2);
            this.groupBox8.Controls.Add(this.вид_номераTextBox);
            this.groupBox8.Controls.Add(вид_номераLabel);
            this.groupBox8.Controls.Add(this.номерTextBox1);
            this.groupBox8.Location = new System.Drawing.Point(6, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(395, 266);
            this.groupBox8.TabIndex = 38;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox3
            // 
            this.примечаниеTextBox3.Location = new System.Drawing.Point(85, 102);
            this.примечаниеTextBox3.Name = "примечаниеTextBox3";
            this.примечаниеTextBox3.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox3.TabIndex = 8;
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(260, 85);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(120, 23);
            this.button18.TabIndex = 23;
            this.button18.Text = "Удалить строку";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.delete_line);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(260, 56);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(120, 23);
            this.button19.TabIndex = 22;
            this.button19.Text = "Изменить строку";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.update_line);
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(260, 27);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(120, 23);
            this.button4.TabIndex = 9;
            this.button4.Text = "Добавить строку";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.insert_line);
            // 
            // стоимостьTextBox2
            // 
            this.стоимостьTextBox2.Location = new System.Drawing.Point(85, 76);
            this.стоимостьTextBox2.Name = "стоимостьTextBox2";
            this.стоимостьTextBox2.Size = new System.Drawing.Size(126, 20);
            this.стоимостьTextBox2.TabIndex = 6;
            // 
            // вид_номераTextBox
            // 
            this.вид_номераTextBox.Location = new System.Drawing.Point(85, 50);
            this.вид_номераTextBox.Name = "вид_номераTextBox";
            this.вид_номераTextBox.Size = new System.Drawing.Size(126, 20);
            this.вид_номераTextBox.TabIndex = 4;
            // 
            // номерTextBox1
            // 
            this.номерTextBox1.Location = new System.Drawing.Point(85, 24);
            this.номерTextBox1.Name = "номерTextBox1";
            this.номерTextBox1.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox1.TabIndex = 2;
            // 
            // номераDataGridView
            // 
            this.номераDataGridView.AutoGenerateColumns = false;
            this.номераDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.номераDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn22,
            this.dataGridViewTextBoxColumn23,
            this.dataGridViewTextBoxColumn24,
            this.dataGridViewTextBoxColumn25});
            this.номераDataGridView.DataSource = this.номераBindingSource;
            this.номераDataGridView.Location = new System.Drawing.Point(3, 278);
            this.номераDataGridView.Name = "номераDataGridView";
            this.номераDataGridView.Size = new System.Drawing.Size(949, 246);
            this.номераDataGridView.TabIndex = 0;
            this.номераDataGridView.SelectionChanged += new System.EventHandler(this.номераDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn22
            // 
            this.dataGridViewTextBoxColumn22.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn22.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn22.Name = "dataGridViewTextBoxColumn22";
            // 
            // dataGridViewTextBoxColumn23
            // 
            this.dataGridViewTextBoxColumn23.DataPropertyName = "Вид номера";
            this.dataGridViewTextBoxColumn23.HeaderText = "Вид номера";
            this.dataGridViewTextBoxColumn23.Name = "dataGridViewTextBoxColumn23";
            // 
            // dataGridViewTextBoxColumn24
            // 
            this.dataGridViewTextBoxColumn24.DataPropertyName = "Стоимость";
            this.dataGridViewTextBoxColumn24.HeaderText = "Стоимость";
            this.dataGridViewTextBoxColumn24.Name = "dataGridViewTextBoxColumn24";
            // 
            // dataGridViewTextBoxColumn25
            // 
            this.dataGridViewTextBoxColumn25.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn25.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn25.Name = "dataGridViewTextBoxColumn25";
            // 
            // номераBindingSource
            // 
            this.номераBindingSource.DataMember = "Номера";
            this.номераBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage5
            // 
            this.tabPage5.AutoScroll = true;
            this.tabPage5.Controls.Add(this.button_data5);
            this.tabPage5.Controls.Add(this.groupBox19);
            this.tabPage5.Controls.Add(this.groupBox20);
            this.tabPage5.Controls.Add(this.оказанные_услугиDataGridView);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(955, 528);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "tabPage5";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button_data5
            // 
            this.button_data5.Location = new System.Drawing.Point(606, 28);
            this.button_data5.Name = "button_data5";
            this.button_data5.Size = new System.Drawing.Size(95, 23);
            this.button_data5.TabIndex = 47;
            this.button_data5.Text = "<<Перенести<<";
            this.button_data5.UseVisualStyleBackColor = true;
            // 
            // groupBox19
            // 
            this.groupBox19.Controls.Add(this.код_услугиTextBox3);
            this.groupBox19.Controls.Add(this.примечаниеTextBox14);
            this.groupBox19.Controls.Add(примечаниеLabel14);
            this.groupBox19.Controls.Add(код_услугиLabel3);
            this.groupBox19.Controls.Add(this.код_сотрудникаTextBox5);
            this.groupBox19.Controls.Add(код_сотрудникаLabel5);
            this.groupBox19.Controls.Add(код_клиентаLabel5);
            this.groupBox19.Controls.Add(this.код_клиентаTextBox5);
            this.groupBox19.Location = new System.Drawing.Point(707, 6);
            this.groupBox19.Name = "groupBox19";
            this.groupBox19.Size = new System.Drawing.Size(242, 266);
            this.groupBox19.TabIndex = 46;
            this.groupBox19.TabStop = false;
            this.groupBox19.Text = "Окно вывода данных";
            // 
            // код_услугиTextBox3
            // 
            this.код_услугиTextBox3.Location = new System.Drawing.Point(102, 24);
            this.код_услугиTextBox3.Name = "код_услугиTextBox3";
            this.код_услугиTextBox3.ReadOnly = true;
            this.код_услугиTextBox3.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox3.TabIndex = 11;
            // 
            // примечаниеTextBox14
            // 
            this.примечаниеTextBox14.Location = new System.Drawing.Point(102, 102);
            this.примечаниеTextBox14.Name = "примечаниеTextBox14";
            this.примечаниеTextBox14.ReadOnly = true;
            this.примечаниеTextBox14.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox14.TabIndex = 17;
            // 
            // код_сотрудникаTextBox5
            // 
            this.код_сотрудникаTextBox5.Location = new System.Drawing.Point(102, 76);
            this.код_сотрудникаTextBox5.Name = "код_сотрудникаTextBox5";
            this.код_сотрудникаTextBox5.ReadOnly = true;
            this.код_сотрудникаTextBox5.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox5.TabIndex = 15;
            // 
            // код_клиентаTextBox5
            // 
            this.код_клиентаTextBox5.Location = new System.Drawing.Point(102, 50);
            this.код_клиентаTextBox5.Name = "код_клиентаTextBox5";
            this.код_клиентаTextBox5.ReadOnly = true;
            this.код_клиентаTextBox5.Size = new System.Drawing.Size(126, 20);
            this.код_клиентаTextBox5.TabIndex = 13;
            // 
            // groupBox20
            // 
            this.groupBox20.Controls.Add(код_услугиLabel1);
            this.groupBox20.Controls.Add(this.примечаниеTextBox4);
            this.groupBox20.Controls.Add(this.button20);
            this.groupBox20.Controls.Add(примечаниеLabel4);
            this.groupBox20.Controls.Add(this.button21);
            this.groupBox20.Controls.Add(this.код_сотрудникаTextBox1);
            this.groupBox20.Controls.Add(код_сотрудникаLabel1);
            this.groupBox20.Controls.Add(this.код_клиентаTextBox2);
            this.groupBox20.Controls.Add(код_клиентаLabel2);
            this.groupBox20.Controls.Add(this.код_услугиTextBox1);
            this.groupBox20.Controls.Add(this.button5);
            this.groupBox20.Location = new System.Drawing.Point(6, 6);
            this.groupBox20.Name = "groupBox20";
            this.groupBox20.Size = new System.Drawing.Size(402, 266);
            this.groupBox20.TabIndex = 45;
            this.groupBox20.TabStop = false;
            this.groupBox20.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox4
            // 
            this.примечаниеTextBox4.Location = new System.Drawing.Point(102, 102);
            this.примечаниеTextBox4.Name = "примечаниеTextBox4";
            this.примечаниеTextBox4.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox4.TabIndex = 8;
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(270, 85);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(120, 23);
            this.button20.TabIndex = 23;
            this.button20.Text = "Удалить строку";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.delete_line);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(270, 56);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(120, 23);
            this.button21.TabIndex = 22;
            this.button21.Text = "Изменить строку";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.update_line);
            // 
            // код_сотрудникаTextBox1
            // 
            this.код_сотрудникаTextBox1.Location = new System.Drawing.Point(102, 76);
            this.код_сотрудникаTextBox1.Name = "код_сотрудникаTextBox1";
            this.код_сотрудникаTextBox1.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox1.TabIndex = 6;
            // 
            // код_клиентаTextBox2
            // 
            this.код_клиентаTextBox2.Location = new System.Drawing.Point(102, 50);
            this.код_клиентаTextBox2.Name = "код_клиентаTextBox2";
            this.код_клиентаTextBox2.Size = new System.Drawing.Size(126, 20);
            this.код_клиентаTextBox2.TabIndex = 4;
            // 
            // код_услугиTextBox1
            // 
            this.код_услугиTextBox1.Location = new System.Drawing.Point(102, 24);
            this.код_услугиTextBox1.Name = "код_услугиTextBox1";
            this.код_услугиTextBox1.Size = new System.Drawing.Size(126, 20);
            this.код_услугиTextBox1.TabIndex = 2;
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(270, 27);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(120, 23);
            this.button5.TabIndex = 9;
            this.button5.Text = "Добавить строку";
            this.button5.UseVisualStyleBackColor = true;
            this.button5.Click += new System.EventHandler(this.insert_line);
            // 
            // оказанные_услугиDataGridView
            // 
            this.оказанные_услугиDataGridView.AutoGenerateColumns = false;
            this.оказанные_услугиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.оказанные_услугиDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn26,
            this.dataGridViewTextBoxColumn27,
            this.dataGridViewTextBoxColumn28,
            this.dataGridViewTextBoxColumn29});
            this.оказанные_услугиDataGridView.DataSource = this.оказанные_услугиBindingSource;
            this.оказанные_услугиDataGridView.Location = new System.Drawing.Point(3, 278);
            this.оказанные_услугиDataGridView.Name = "оказанные_услугиDataGridView";
            this.оказанные_услугиDataGridView.Size = new System.Drawing.Size(949, 246);
            this.оказанные_услугиDataGridView.TabIndex = 17;
            this.оказанные_услугиDataGridView.SelectionChanged += new System.EventHandler(this.оказанные_услугиDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn26
            // 
            this.dataGridViewTextBoxColumn26.DataPropertyName = "Код услуги";
            this.dataGridViewTextBoxColumn26.HeaderText = "Код услуги";
            this.dataGridViewTextBoxColumn26.Name = "dataGridViewTextBoxColumn26";
            // 
            // dataGridViewTextBoxColumn27
            // 
            this.dataGridViewTextBoxColumn27.DataPropertyName = "Код клиента";
            this.dataGridViewTextBoxColumn27.HeaderText = "Код клиента";
            this.dataGridViewTextBoxColumn27.Name = "dataGridViewTextBoxColumn27";
            // 
            // dataGridViewTextBoxColumn28
            // 
            this.dataGridViewTextBoxColumn28.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn28.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn28.Name = "dataGridViewTextBoxColumn28";
            // 
            // dataGridViewTextBoxColumn29
            // 
            this.dataGridViewTextBoxColumn29.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn29.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn29.Name = "dataGridViewTextBoxColumn29";
            // 
            // оказанные_услугиBindingSource
            // 
            this.оказанные_услугиBindingSource.DataMember = "Оказанные_услуги";
            this.оказанные_услугиBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage6
            // 
            this.tabPage6.AutoScroll = true;
            this.tabPage6.Controls.Add(this.button_data6);
            this.tabPage6.Controls.Add(this.groupBox17);
            this.tabPage6.Controls.Add(this.groupBox18);
            this.tabPage6.Controls.Add(this.пропускDataGridView);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(955, 528);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "tabPage6";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // button_data6
            // 
            this.button_data6.Location = new System.Drawing.Point(617, 28);
            this.button_data6.Name = "button_data6";
            this.button_data6.Size = new System.Drawing.Size(95, 23);
            this.button_data6.TabIndex = 47;
            this.button_data6.Text = "<<Перенести<<";
            this.button_data6.UseVisualStyleBackColor = true;
            // 
            // groupBox17
            // 
            this.groupBox17.Controls.Add(код_пропускаLabel3);
            this.groupBox17.Controls.Add(this.примечаниеTextBox15);
            this.groupBox17.Controls.Add(примечаниеLabel15);
            this.groupBox17.Controls.Add(this.код_пропускаTextBox3);
            this.groupBox17.Controls.Add(this.номерTextBox6);
            this.groupBox17.Controls.Add(номерLabel6);
            this.groupBox17.Location = new System.Drawing.Point(718, 6);
            this.groupBox17.Name = "groupBox17";
            this.groupBox17.Size = new System.Drawing.Size(231, 266);
            this.groupBox17.TabIndex = 46;
            this.groupBox17.TabStop = false;
            this.groupBox17.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox15
            // 
            this.примечаниеTextBox15.Location = new System.Drawing.Point(91, 76);
            this.примечаниеTextBox15.Name = "примечаниеTextBox15";
            this.примечаниеTextBox15.ReadOnly = true;
            this.примечаниеTextBox15.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox15.TabIndex = 13;
            // 
            // код_пропускаTextBox3
            // 
            this.код_пропускаTextBox3.Location = new System.Drawing.Point(91, 24);
            this.код_пропускаTextBox3.Name = "код_пропускаTextBox3";
            this.код_пропускаTextBox3.ReadOnly = true;
            this.код_пропускаTextBox3.Size = new System.Drawing.Size(126, 20);
            this.код_пропускаTextBox3.TabIndex = 9;
            // 
            // номерTextBox6
            // 
            this.номерTextBox6.Location = new System.Drawing.Point(91, 50);
            this.номерTextBox6.Name = "номерTextBox6";
            this.номерTextBox6.ReadOnly = true;
            this.номерTextBox6.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox6.TabIndex = 11;
            // 
            // groupBox18
            // 
            this.groupBox18.Controls.Add(код_пропускаLabel1);
            this.groupBox18.Controls.Add(this.примечаниеTextBox5);
            this.groupBox18.Controls.Add(this.button22);
            this.groupBox18.Controls.Add(this.button23);
            this.groupBox18.Controls.Add(примечаниеLabel5);
            this.groupBox18.Controls.Add(this.номерTextBox2);
            this.groupBox18.Controls.Add(номерLabel2);
            this.groupBox18.Controls.Add(this.код_пропускаTextBox1);
            this.groupBox18.Controls.Add(this.button6);
            this.groupBox18.Location = new System.Drawing.Point(6, 6);
            this.groupBox18.Name = "groupBox18";
            this.groupBox18.Size = new System.Drawing.Size(377, 266);
            this.groupBox18.TabIndex = 45;
            this.groupBox18.TabStop = false;
            this.groupBox18.Text = "Окно ввода данных";
            // 
            // примечаниеTextBox5
            // 
            this.примечаниеTextBox5.Location = new System.Drawing.Point(91, 76);
            this.примечаниеTextBox5.Name = "примечаниеTextBox5";
            this.примечаниеTextBox5.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox5.TabIndex = 6;
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(242, 85);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(120, 23);
            this.button22.TabIndex = 23;
            this.button22.Text = "Удалить строку";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.delete_line);
            // 
            // button23
            // 
            this.button23.Location = new System.Drawing.Point(242, 56);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(120, 23);
            this.button23.TabIndex = 22;
            this.button23.Text = "Изменить строку";
            this.button23.UseVisualStyleBackColor = true;
            this.button23.Click += new System.EventHandler(this.update_line);
            // 
            // номерTextBox2
            // 
            this.номерTextBox2.Location = new System.Drawing.Point(91, 50);
            this.номерTextBox2.Name = "номерTextBox2";
            this.номерTextBox2.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox2.TabIndex = 4;
            // 
            // код_пропускаTextBox1
            // 
            this.код_пропускаTextBox1.Location = new System.Drawing.Point(91, 24);
            this.код_пропускаTextBox1.Name = "код_пропускаTextBox1";
            this.код_пропускаTextBox1.Size = new System.Drawing.Size(126, 20);
            this.код_пропускаTextBox1.TabIndex = 2;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(242, 27);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(120, 23);
            this.button6.TabIndex = 7;
            this.button6.Text = "Добавить строку";
            this.button6.UseVisualStyleBackColor = true;
            this.button6.Click += new System.EventHandler(this.insert_line);
            // 
            // пропускDataGridView
            // 
            this.пропускDataGridView.AutoGenerateColumns = false;
            this.пропускDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.пропускDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn30,
            this.dataGridViewTextBoxColumn31,
            this.dataGridViewTextBoxColumn32});
            this.пропускDataGridView.DataSource = this.пропускBindingSource;
            this.пропускDataGridView.Location = new System.Drawing.Point(3, 278);
            this.пропускDataGridView.Name = "пропускDataGridView";
            this.пропускDataGridView.Size = new System.Drawing.Size(949, 246);
            this.пропускDataGridView.TabIndex = 0;
            this.пропускDataGridView.SelectionChanged += new System.EventHandler(this.пропускDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn30
            // 
            this.dataGridViewTextBoxColumn30.DataPropertyName = "Код пропуска";
            this.dataGridViewTextBoxColumn30.HeaderText = "Код пропуска";
            this.dataGridViewTextBoxColumn30.Name = "dataGridViewTextBoxColumn30";
            // 
            // dataGridViewTextBoxColumn31
            // 
            this.dataGridViewTextBoxColumn31.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn31.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn31.Name = "dataGridViewTextBoxColumn31";
            // 
            // dataGridViewTextBoxColumn32
            // 
            this.dataGridViewTextBoxColumn32.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn32.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn32.Name = "dataGridViewTextBoxColumn32";
            // 
            // пропускBindingSource
            // 
            this.пропускBindingSource.DataMember = "Пропуск";
            this.пропускBindingSource.DataSource = this.hotelDataSet;
            // 
            // сотрудникBindingSource
            // 
            this.сотрудникBindingSource.DataMember = "Сотрудник";
            this.сотрудникBindingSource.DataSource = this.hotelDataSet;
            // 
            // tabPage9
            // 
            this.tabPage9.AutoScroll = true;
            this.tabPage9.Controls.Add(this.button_data8);
            this.tabPage9.Controls.Add(this.уборкаDataGridView);
            this.tabPage9.Controls.Add(this.groupBox13);
            this.tabPage9.Controls.Add(this.groupBox14);
            this.tabPage9.Location = new System.Drawing.Point(4, 22);
            this.tabPage9.Name = "tabPage9";
            this.tabPage9.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage9.Size = new System.Drawing.Size(955, 528);
            this.tabPage9.TabIndex = 8;
            this.tabPage9.Text = "tabPage9";
            this.tabPage9.UseVisualStyleBackColor = true;
            // 
            // button_data8
            // 
            this.button_data8.Location = new System.Drawing.Point(580, 28);
            this.button_data8.Name = "button_data8";
            this.button_data8.Size = new System.Drawing.Size(95, 23);
            this.button_data8.TabIndex = 40;
            this.button_data8.Text = "<<Перенести<<";
            this.button_data8.UseVisualStyleBackColor = true;
            // 
            // уборкаDataGridView
            // 
            this.уборкаDataGridView.AutoGenerateColumns = false;
            this.уборкаDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.уборкаDataGridView.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn15,
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn18,
            this.dataGridViewTextBoxColumn19});
            this.уборкаDataGridView.DataSource = this.уборкаBindingSource;
            this.уборкаDataGridView.Location = new System.Drawing.Point(3, 278);
            this.уборкаDataGridView.Name = "уборкаDataGridView";
            this.уборкаDataGridView.Size = new System.Drawing.Size(949, 246);
            this.уборкаDataGridView.TabIndex = 39;
            this.уборкаDataGridView.SelectionChanged += new System.EventHandler(this.уборкаDataGridView_SelectionChanged);
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "Код сотрудника";
            this.dataGridViewTextBoxColumn14.HeaderText = "Код сотрудника";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "Номер";
            this.dataGridViewTextBoxColumn15.HeaderText = "Номер";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "День недели";
            this.dataGridViewTextBoxColumn16.HeaderText = "День недели";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "Время начала уборки";
            this.dataGridViewTextBoxColumn17.HeaderText = "Время начала уборки";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Длительность";
            this.dataGridViewTextBoxColumn18.HeaderText = "Длительность";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "Примечание";
            this.dataGridViewTextBoxColumn19.HeaderText = "Примечание";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            // 
            // уборкаBindingSource
            // 
            this.уборкаBindingSource.DataMember = "Уборка";
            this.уборкаBindingSource.DataSource = this.hotelDataSet;
            // 
            // groupBox13
            // 
            this.groupBox13.Controls.Add(код_сотрудникаLabel7);
            this.groupBox13.Controls.Add(this.примечаниеTextBox18);
            this.groupBox13.Controls.Add(this.код_сотрудникаTextBox7);
            this.groupBox13.Controls.Add(примечаниеLabel18);
            this.groupBox13.Controls.Add(номерLabel7);
            this.groupBox13.Controls.Add(this.длительностьTextBox1);
            this.groupBox13.Controls.Add(this.номерTextBox7);
            this.groupBox13.Controls.Add(длительностьLabel1);
            this.groupBox13.Controls.Add(день_неделиLabel1);
            this.groupBox13.Controls.Add(this.время_начала_уборкиTextBox1);
            this.groupBox13.Controls.Add(this.день_неделиTextBox1);
            this.groupBox13.Controls.Add(время_начала_уборкиLabel1);
            this.groupBox13.Location = new System.Drawing.Point(681, 6);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(268, 266);
            this.groupBox13.TabIndex = 39;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "Окно вывода данных";
            // 
            // примечаниеTextBox18
            // 
            this.примечаниеTextBox18.Location = new System.Drawing.Point(131, 154);
            this.примечаниеTextBox18.Name = "примечаниеTextBox18";
            this.примечаниеTextBox18.ReadOnly = true;
            this.примечаниеTextBox18.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox18.TabIndex = 25;
            // 
            // код_сотрудникаTextBox7
            // 
            this.код_сотрудникаTextBox7.Location = new System.Drawing.Point(131, 24);
            this.код_сотрудникаTextBox7.Name = "код_сотрудникаTextBox7";
            this.код_сотрудникаTextBox7.ReadOnly = true;
            this.код_сотрудникаTextBox7.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox7.TabIndex = 15;
            // 
            // длительностьTextBox1
            // 
            this.длительностьTextBox1.Location = new System.Drawing.Point(131, 128);
            this.длительностьTextBox1.Name = "длительностьTextBox1";
            this.длительностьTextBox1.ReadOnly = true;
            this.длительностьTextBox1.Size = new System.Drawing.Size(126, 20);
            this.длительностьTextBox1.TabIndex = 23;
            // 
            // номерTextBox7
            // 
            this.номерTextBox7.Location = new System.Drawing.Point(131, 50);
            this.номерTextBox7.Name = "номерTextBox7";
            this.номерTextBox7.ReadOnly = true;
            this.номерTextBox7.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox7.TabIndex = 17;
            // 
            // время_начала_уборкиTextBox1
            // 
            this.время_начала_уборкиTextBox1.Location = new System.Drawing.Point(131, 102);
            this.время_начала_уборкиTextBox1.Name = "время_начала_уборкиTextBox1";
            this.время_начала_уборкиTextBox1.ReadOnly = true;
            this.время_начала_уборкиTextBox1.Size = new System.Drawing.Size(126, 20);
            this.время_начала_уборкиTextBox1.TabIndex = 21;
            // 
            // день_неделиTextBox1
            // 
            this.день_неделиTextBox1.Location = new System.Drawing.Point(131, 76);
            this.день_неделиTextBox1.Name = "день_неделиTextBox1";
            this.день_неделиTextBox1.ReadOnly = true;
            this.день_неделиTextBox1.Size = new System.Drawing.Size(126, 20);
            this.день_неделиTextBox1.TabIndex = 19;
            // 
            // groupBox14
            // 
            this.groupBox14.Controls.Add(this.button29);
            this.groupBox14.Controls.Add(this.button9);
            this.groupBox14.Controls.Add(this.button28);
            this.groupBox14.Controls.Add(код_сотрудникаLabel3);
            this.groupBox14.Controls.Add(this.примечаниеTextBox8);
            this.groupBox14.Controls.Add(примечаниеLabel8);
            this.groupBox14.Controls.Add(this.длительностьTextBox);
            this.groupBox14.Controls.Add(длительностьLabel);
            this.groupBox14.Controls.Add(this.время_начала_уборкиTextBox);
            this.groupBox14.Controls.Add(время_начала_уборкиLabel);
            this.groupBox14.Controls.Add(this.день_неделиTextBox);
            this.groupBox14.Controls.Add(день_неделиLabel);
            this.groupBox14.Controls.Add(this.номерTextBox3);
            this.groupBox14.Controls.Add(номерLabel3);
            this.groupBox14.Controls.Add(this.код_сотрудникаTextBox3);
            this.groupBox14.Location = new System.Drawing.Point(6, 6);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(440, 266);
            this.groupBox14.TabIndex = 38;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "Окно ввода данных";
            // 
            // button29
            // 
            this.button29.Location = new System.Drawing.Point(303, 56);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(120, 23);
            this.button29.TabIndex = 26;
            this.button29.Text = "Изменить строку";
            this.button29.UseVisualStyleBackColor = true;
            this.button29.Click += new System.EventHandler(this.update_line);
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(303, 27);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(120, 23);
            this.button9.TabIndex = 13;
            this.button9.Text = "Добавить строку";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.insert_line);
            // 
            // button28
            // 
            this.button28.Location = new System.Drawing.Point(303, 85);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(120, 23);
            this.button28.TabIndex = 27;
            this.button28.Text = "Удалить строку";
            this.button28.UseVisualStyleBackColor = true;
            this.button28.Click += new System.EventHandler(this.delete_line);
            // 
            // примечаниеTextBox8
            // 
            this.примечаниеTextBox8.Location = new System.Drawing.Point(131, 154);
            this.примечаниеTextBox8.Name = "примечаниеTextBox8";
            this.примечаниеTextBox8.Size = new System.Drawing.Size(126, 20);
            this.примечаниеTextBox8.TabIndex = 12;
            // 
            // длительностьTextBox
            // 
            this.длительностьTextBox.Location = new System.Drawing.Point(131, 128);
            this.длительностьTextBox.Name = "длительностьTextBox";
            this.длительностьTextBox.Size = new System.Drawing.Size(126, 20);
            this.длительностьTextBox.TabIndex = 10;
            // 
            // время_начала_уборкиTextBox
            // 
            this.время_начала_уборкиTextBox.Location = new System.Drawing.Point(131, 102);
            this.время_начала_уборкиTextBox.Name = "время_начала_уборкиTextBox";
            this.время_начала_уборкиTextBox.Size = new System.Drawing.Size(126, 20);
            this.время_начала_уборкиTextBox.TabIndex = 8;
            // 
            // день_неделиTextBox
            // 
            this.день_неделиTextBox.Location = new System.Drawing.Point(131, 76);
            this.день_неделиTextBox.Name = "день_неделиTextBox";
            this.день_неделиTextBox.Size = new System.Drawing.Size(126, 20);
            this.день_неделиTextBox.TabIndex = 6;
            // 
            // номерTextBox3
            // 
            this.номерTextBox3.Location = new System.Drawing.Point(131, 50);
            this.номерTextBox3.Name = "номерTextBox3";
            this.номерTextBox3.Size = new System.Drawing.Size(126, 20);
            this.номерTextBox3.TabIndex = 4;
            // 
            // код_сотрудникаTextBox3
            // 
            this.код_сотрудникаTextBox3.Location = new System.Drawing.Point(131, 24);
            this.код_сотрудникаTextBox3.Name = "код_сотрудникаTextBox3";
            this.код_сотрудникаTextBox3.Size = new System.Drawing.Size(126, 20);
            this.код_сотрудникаTextBox3.TabIndex = 2;
            // 
            // пользователиBindingSource
            // 
            this.пользователиBindingSource.DataMember = "Пользователи";
            this.пользователиBindingSource.DataSource = this.hotelDataSet;
            // 
            // оказанные_услугиBindingSource1
            // 
            this.оказанные_услугиBindingSource1.DataMember = "Оказанные услуги";
            this.оказанные_услугиBindingSource1.DataSource = this.hotelDataSet1;
            // 
            // hotelDataSet1
            // 
            this.hotelDataSet1.DataSetName = "HotelDataSet1";
            this.hotelDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // номера_с_клиентамиBindingSource
            // 
            this.номера_с_клиентамиBindingSource.DataMember = "Номера с клиентами";
            this.номера_с_клиентамиBindingSource.DataSource = this.hotelDataSet1;
            // 
            // бронь_номеровBindingSource
            // 
            this.бронь_номеровBindingSource.DataMember = "Бронь номеров";
            this.бронь_номеровBindingSource.DataSource = this.hotelDataSet1;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(269, 27);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(120, 23);
            this.button8.TabIndex = 9;
            this.button8.Text = "Добавить строку";
            this.button8.UseVisualStyleBackColor = true;
            this.button8.Click += new System.EventHandler(this.insert_line);
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(269, 56);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(120, 23);
            this.button27.TabIndex = 22;
            this.button27.Text = "Изменить строку";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.update_line);
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(269, 85);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(120, 23);
            this.button26.TabIndex = 23;
            this.button26.Text = "Удалить строку";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.delete_line);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.button11);
            this.panel1.Controls.Add(this.lb_form_window);
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(970, 22);
            this.panel1.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(301, 5);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(35, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "label1";
            // 
            // button11
            // 
            this.button11.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("button11.BackgroundImage")));
            this.button11.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.button11.FlatAppearance.BorderSize = 0;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button11.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button11.Location = new System.Drawing.Point(949, 1);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(19, 19);
            this.button11.TabIndex = 6;
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.close_form);
            // 
            // lb_form_window
            // 
            this.lb_form_window.AutoSize = true;
            this.lb_form_window.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lb_form_window.Location = new System.Drawing.Point(2, 2);
            this.lb_form_window.Name = "lb_form_window";
            this.lb_form_window.Size = new System.Drawing.Size(131, 16);
            this.lb_form_window.TabIndex = 7;
            this.lb_form_window.Text = "База данных отеля";
            // 
            // броньTableAdapter
            // 
            this.броньTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.UpdateOrder = WindowsFormsApp1.HotelDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            this.tableAdapterManager.БроньTableAdapter = this.броньTableAdapter;
            this.tableAdapterManager.Доп_услугиTableAdapter = this.доп_услугиTableAdapter;
            this.tableAdapterManager.КлиентTableAdapter = this.клиентTableAdapter;
            this.tableAdapterManager.НомераTableAdapter = this.номераTableAdapter;
            this.tableAdapterManager.Оказанные_услугиTableAdapter = this.оказанные_услугиTableAdapter;
            this.tableAdapterManager.ПользователиTableAdapter = null;
            this.tableAdapterManager.ПропускTableAdapter = this.пропускTableAdapter;
            this.tableAdapterManager.СотрудникTableAdapter = this.сотрудникTableAdapter;
            this.tableAdapterManager.УборкаTableAdapter = this.уборкаTableAdapter;
            // 
            // доп_услугиTableAdapter
            // 
            this.доп_услугиTableAdapter.ClearBeforeFill = true;
            // 
            // клиентTableAdapter
            // 
            this.клиентTableAdapter.ClearBeforeFill = true;
            // 
            // номераTableAdapter
            // 
            this.номераTableAdapter.ClearBeforeFill = true;
            // 
            // оказанные_услугиTableAdapter
            // 
            this.оказанные_услугиTableAdapter.ClearBeforeFill = true;
            // 
            // пропускTableAdapter
            // 
            this.пропускTableAdapter.ClearBeforeFill = true;
            // 
            // сотрудникTableAdapter
            // 
            this.сотрудникTableAdapter.ClearBeforeFill = true;
            // 
            // уборкаTableAdapter
            // 
            this.уборкаTableAdapter.ClearBeforeFill = true;
            // 
            // пользователиTableAdapter
            // 
            this.пользователиTableAdapter.ClearBeforeFill = true;
            // 
            // бронь_номеровTableAdapter
            // 
            this.бронь_номеровTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager1
            // 
            this.tableAdapterManager1.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager1.Connection = null;
            this.tableAdapterManager1.UpdateOrder = WindowsFormsApp1.HotelDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // номера_с_клиентамиTableAdapter
            // 
            this.номера_с_клиентамиTableAdapter.ClearBeforeFill = true;
            // 
            // оказанные_услугиTableAdapter1
            // 
            this.оказанные_услугиTableAdapter1.ClearBeforeFill = true;
            // 
            // Form7
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(970, 584);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form7";
            this.Text = "Form7";
            this.Load += new System.EventHandler(this.Form7_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.броньDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.броньBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet)).EndInit();
            this.tabPage2.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.доп_услугиBindingSource)).EndInit();
            this.tabPage3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.клиентDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентBindingSource)).EndInit();
            this.groupBox6.ResumeLayout(false);
            this.groupBox6.PerformLayout();
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.groupBox7.ResumeLayout(false);
            this.groupBox7.PerformLayout();
            this.groupBox8.ResumeLayout(false);
            this.groupBox8.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.номераDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номераBindingSource)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.groupBox19.ResumeLayout(false);
            this.groupBox19.PerformLayout();
            this.groupBox20.ResumeLayout(false);
            this.groupBox20.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource)).EndInit();
            this.tabPage6.ResumeLayout(false);
            this.groupBox17.ResumeLayout(false);
            this.groupBox17.PerformLayout();
            this.groupBox18.ResumeLayout(false);
            this.groupBox18.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пропускDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.пропускBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникBindingSource)).EndInit();
            this.tabPage9.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.уборкаDataGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.уборкаBindingSource)).EndInit();
            this.groupBox13.ResumeLayout(false);
            this.groupBox13.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            this.groupBox14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.пользователиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.оказанные_услугиBindingSource1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.hotelDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.номера_с_клиентамиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.бронь_номеровBindingSource)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.TabPage tabPage9;
        public HotelDataSet hotelDataSet;
        public System.Windows.Forms.BindingSource броньBindingSource;
        public HotelDataSetTableAdapters.БроньTableAdapter броньTableAdapter;
        private HotelDataSetTableAdapters.TableAdapterManager tableAdapterManager;
        public HotelDataSetTableAdapters.Доп_услугиTableAdapter доп_услугиTableAdapter;
        public System.Windows.Forms.BindingSource доп_услугиBindingSource;
        public System.Windows.Forms.DataGridView броньDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        public HotelDataSetTableAdapters.КлиентTableAdapter клиентTableAdapter;
        public System.Windows.Forms.BindingSource клиентBindingSource;
        public HotelDataSetTableAdapters.НомераTableAdapter номераTableAdapter;
        public System.Windows.Forms.BindingSource номераBindingSource;
        public System.Windows.Forms.DataGridView номераDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn22;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn23;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn24;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn25;
        public HotelDataSetTableAdapters.Оказанные_услугиTableAdapter оказанные_услугиTableAdapter;
        public System.Windows.Forms.BindingSource оказанные_услугиBindingSource;
        public HotelDataSetTableAdapters.ПропускTableAdapter пропускTableAdapter;
        public System.Windows.Forms.BindingSource пропускBindingSource;
        public System.Windows.Forms.DataGridView пропускDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn30;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn31;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn32;
        public HotelDataSetTableAdapters.СотрудникTableAdapter сотрудникTableAdapter;
        public System.Windows.Forms.BindingSource сотрудникBindingSource;
        public System.Windows.Forms.BindingSource тарифBindingSource;
        public System.Windows.Forms.DataGridView тарифDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn42;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn43;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn44;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn45;
        public HotelDataSetTableAdapters.УборкаTableAdapter уборкаTableAdapter;
        public System.Windows.Forms.BindingSource уборкаBindingSource;
        private System.Windows.Forms.TextBox код_клиентаTextBox;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox;
        private System.Windows.Forms.TextBox номерTextBox;
        private System.Windows.Forms.TextBox код_пропускаTextBox;
        private System.Windows.Forms.DateTimePicker дата_прибытияDateTimePicker;
        private System.Windows.Forms.DateTimePicker дата_отбытияDateTimePicker;
        private System.Windows.Forms.TextBox стоимостьTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox;
        private System.Windows.Forms.TextBox код_услугиTextBox;
        private System.Windows.Forms.TextBox наименованиеTextBox;
        private System.Windows.Forms.TextBox стоимостьTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox1;
        private System.Windows.Forms.TextBox код_клиентаTextBox1;
        private System.Windows.Forms.TextBox фИОTextBox;
        private System.Windows.Forms.TextBox полTextBox;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker;
        private System.Windows.Forms.TextBox адресTextBox;
        private System.Windows.Forms.TextBox телефонTextBox;
        private System.Windows.Forms.TextBox паспортTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox2;
        private System.Windows.Forms.TextBox номерTextBox1;
        private System.Windows.Forms.TextBox вид_номераTextBox;
        private System.Windows.Forms.TextBox стоимостьTextBox2;
        private System.Windows.Forms.TextBox примечаниеTextBox3;
        private System.Windows.Forms.TextBox код_услугиTextBox1;
        private System.Windows.Forms.TextBox код_клиентаTextBox2;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox4;
        private System.Windows.Forms.TextBox код_пропускаTextBox1;
        private System.Windows.Forms.TextBox номерTextBox2;
        private System.Windows.Forms.TextBox примечаниеTextBox5;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox3;
        private System.Windows.Forms.TextBox номерTextBox3;
        private System.Windows.Forms.TextBox день_неделиTextBox;
        private System.Windows.Forms.TextBox время_начала_уборкиTextBox;
        private System.Windows.Forms.TextBox длительностьTextBox;
        private System.Windows.Forms.TextBox примечаниеTextBox8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        public System.Windows.Forms.DataGridView доп_услугиDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.BindingSource пользователиBindingSource;
        private HotelDataSetTableAdapters.ПользователиTableAdapter пользователиTableAdapter;
        private System.Windows.Forms.TextBox код_клиентаTextBox3;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox4;
        private System.Windows.Forms.TextBox номерTextBox4;
        private System.Windows.Forms.TextBox код_пропускаTextBox2;
        private System.Windows.Forms.DateTimePicker дата_прибытияDateTimePicker1;
        private System.Windows.Forms.DateTimePicker дата_отбытияDateTimePicker1;
        private System.Windows.Forms.TextBox стоимостьTextBox3;
        private System.Windows.Forms.TextBox примечаниеTextBox10;
        private System.Windows.Forms.TextBox код_услугиTextBox2;
        private System.Windows.Forms.TextBox наименованиеTextBox2;
        private System.Windows.Forms.TextBox стоимостьTextBox4;
        private System.Windows.Forms.TextBox примечаниеTextBox11;
        private System.Windows.Forms.TextBox номерTextBox5;
        private System.Windows.Forms.TextBox вид_номераTextBox1;
        private System.Windows.Forms.TextBox стоимостьTextBox5;
        private System.Windows.Forms.TextBox примечаниеTextBox13;
        private System.Windows.Forms.TextBox код_услугиTextBox3;
        private System.Windows.Forms.TextBox код_клиентаTextBox5;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox5;
        private System.Windows.Forms.TextBox примечаниеTextBox14;
        private System.Windows.Forms.TextBox код_пропускаTextBox3;
        private System.Windows.Forms.TextBox номерTextBox6;
        private System.Windows.Forms.TextBox примечаниеTextBox15;
        private System.Windows.Forms.TextBox код_сотрудникаTextBox7;
        private System.Windows.Forms.TextBox номерTextBox7;
        private System.Windows.Forms.TextBox день_неделиTextBox1;
        private System.Windows.Forms.TextBox время_начала_уборкиTextBox1;
        private System.Windows.Forms.TextBox длительностьTextBox1;
        private System.Windows.Forms.TextBox примечаниеTextBox18;
        private HotelDataSet1 hotelDataSet1;
        private System.Windows.Forms.BindingSource бронь_номеровBindingSource;
        private System.Windows.Forms.BindingSource номера_с_клиентамиBindingSource;
        private System.Windows.Forms.BindingSource оказанные_услугиBindingSource1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Label lb_form_window;
        private System.Windows.Forms.DataGridView оказанные_услугиDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn26;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn27;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn28;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn29;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.GroupBox groupBox19;
        private System.Windows.Forms.GroupBox groupBox20;
        private System.Windows.Forms.GroupBox groupBox17;
        private System.Windows.Forms.GroupBox groupBox18;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.TextBox код_клиентаTextBox4;
        private System.Windows.Forms.TextBox фИОTextBox3;
        private System.Windows.Forms.TextBox полTextBox2;
        private System.Windows.Forms.DateTimePicker дата_рожденияDateTimePicker2;
        private System.Windows.Forms.TextBox адресTextBox2;
        private System.Windows.Forms.TextBox телефонTextBox3;
        private System.Windows.Forms.TextBox паспортTextBox2;
        private System.Windows.Forms.TextBox примечаниеTextBox12;
        private System.Windows.Forms.DataGridView клиентDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn47;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn48;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn49;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn50;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn51;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn75;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn76;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn77;
        private System.Windows.Forms.DataGridView уборкаDataGridView;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn46;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn82;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn84;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn58;
        private HotelDataSet1TableAdapters.Бронь_номеровTableAdapter бронь_номеровTableAdapter;
        private HotelDataSet1TableAdapters.TableAdapterManager tableAdapterManager1;
        private HotelDataSet1TableAdapters.Номера_с_клиентамиTableAdapter номера_с_клиентамиTableAdapter;
        private HotelDataSet1TableAdapters.Оказанные_услугиTableAdapter оказанные_услугиTableAdapter1;
        private System.Windows.Forms.Button button_data1;
        private System.Windows.Forms.Button button_data2;
        private System.Windows.Forms.Button button_data3;
        private System.Windows.Forms.Button button_data4;
        private System.Windows.Forms.Button button_data5;
        private System.Windows.Forms.Button button_data6;
        private System.Windows.Forms.Button button_data8;
    }
}

