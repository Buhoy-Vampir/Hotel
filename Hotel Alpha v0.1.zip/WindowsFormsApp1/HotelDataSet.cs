﻿namespace WindowsFormsApp1
{


    partial class HotelDataSet
    {
        partial class СотрудникDataTable
        {
        }

        partial class ПользователиDataTable
        {
        }

        partial class Доп_услугиDataTable
        {
        }
    }
}

